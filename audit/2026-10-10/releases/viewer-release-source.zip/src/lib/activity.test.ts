import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  categoryForAction,
  detailHasSensitiveKeys,
  extractSafeDetailFields,
  filterEventsByGroup,
  groupNeedsPostFilter,
  isValidDateInput,
  localDateToIsoBound,
  mapActivityEvent,
  mapActivityList,
  parseActivityQuery,
  rpcActionForGroup,
} from "./activity";
import { translateAuditEvent } from "./activity-translate";

const STAFF_ID = "11111111-1111-4111-8111-111111111111";
const SHOP_ID = "22222222-2222-4222-8222-222222222222";

describe("translateAuditEvent (C0.5)", () => {
  it("covers every known action", () => {
    assert.equal(
      translateAuditEvent({
        action: "create",
        target_username: "ali",
        detail: { display_name: "Ali" },
      }),
      "Account created: Ali",
    );
    assert.equal(
      translateAuditEvent({ action: "disable", target_username: "ali" }),
      "ali disabled",
    );
    assert.equal(
      translateAuditEvent({ action: "enable", target_username: "ali" }),
      "ali enabled",
    );
    assert.equal(
      translateAuditEvent({
        action: "set_role",
        target_username: "ali",
        detail: { from: "cashier", to: "manager" },
      }),
      "Role changed for ali: Cashier → Manager",
    );
    assert.equal(
      translateAuditEvent({
        action: "assign_shop",
        target_username: "ali",
        detail: { shop: "Shop 1" },
      }),
      "Shop 1 assigned to ali",
    );
    assert.equal(
      translateAuditEvent({
        action: "unassign_shop",
        target_username: "ali",
        detail: { shop: "Shop 1" },
      }),
      "ali removed from Shop 1",
    );
    assert.equal(
      translateAuditEvent({ action: "terminate", target_username: "ali" }),
      "ali terminated",
    );
    assert.equal(
      translateAuditEvent({
        action: "reset_server_credential",
        target_username: "ali",
      }),
      "Server credential reset for ali",
    );
    assert.equal(
      translateAuditEvent({ action: "add_shop", detail: { name: "Shop 2" } }),
      "Shop added: Shop 2",
    );
    assert.equal(
      translateAuditEvent({
        action: "recover_identity",
        detail: { staff_restored: 3 },
      }),
      "Identity recovery performed",
    );
  });

  it("uses safe fallback for unknown actions and missing optional detail", () => {
    assert.equal(translateAuditEvent({ action: "mystery_thing" }), "Mystery thing");
    assert.equal(translateAuditEvent({ action: "set_role" }), "Role changed");
    assert.equal(translateAuditEvent({ action: "assign_shop" }), "Shop assigned");
    assert.equal(translateAuditEvent({}), "Account activity recorded");
  });

  it("keeps HTML/script-like values as plain text (no crash)", () => {
    const summary = translateAuditEvent({
      action: "create",
      target_username: "<script>alert(1)</script>",
      detail: { display_name: "<b>Ali</b>" },
    });
    assert.equal(summary, "Account created: <b>Ali</b>");
    assert.ok(summary.includes("<b>Ali</b>"));
  });

  it("credential reset never embeds credential material in summary", () => {
    const summary = translateAuditEvent({
      action: "reset_server_credential",
      target_username: "ali",
      detail: {
        staff_id: STAFF_ID,
        new_credential: "123456789012345",
        password: "secret",
      },
    });
    assert.equal(summary, "Server credential reset for ali");
    assert.ok(!summary.includes("123456789012345"));
    assert.ok(!summary.includes("secret"));
  });
});

describe("extractSafeDetailFields", () => {
  it("renders only whitelisted safe fields", () => {
    const { fields, suppressed_sensitive } = extractSafeDetailFields({
      from: "cashier",
      to: "manager",
      staff_id: STAFF_ID,
      shop_id: SHOP_ID,
      shop: "Shop 1",
      unknown_future_key: "should-drop",
      business_id: "should-drop",
    });
    const keys = fields.map((f) => f.key).sort();
    assert.deepEqual(keys, ["from", "shop", "shop_id", "staff_id", "to"]);
    assert.equal(suppressed_sensitive, false);
    assert.equal(fields.find((f) => f.key === "from")?.value, "Cashier");
    assert.equal(fields.find((f) => f.key === "to")?.value, "Manager");
  });

  it("suppresses credential-like keys and flags them", () => {
    const { fields, suppressed_sensitive } = extractSafeDetailFields({
      staff_id: STAFF_ID,
      new_credential: "999999999999999",
      password: "x",
      token: "abc",
    });
    assert.equal(suppressed_sensitive, true);
    assert.ok(fields.every((f) => f.key === "staff_id"));
    assert.ok(!fields.some((f) => f.value.includes("999")));
  });

  it("detailHasSensitiveKeys detects nested-looking key names", () => {
    assert.equal(detailHasSensitiveKeys({ server_credential: "x" }), true);
    assert.equal(detailHasSensitiveKeys({ staff_id: STAFF_ID }), false);
  });

  it("shows safe recovery counts", () => {
    const { fields } = extractSafeDetailFields({
      from_export: true,
      staff_restored: 4,
      shops_restored: 2,
      auth_recreated: 4,
      audit_events_restored: 10,
    });
    assert.equal(fields.find((f) => f.key === "staff_restored")?.value, "4");
    assert.equal(fields.find((f) => f.key === "from_export")?.value, "Yes");
  });
});

describe("mapActivityList / mapActivityEvent", () => {
  it("maps a valid list newest-first preserving order", () => {
    const mapped = mapActivityList([
      {
        id: 2,
        at: "2026-09-20T14:00:00Z",
        action: "enable",
        target_username: "ali",
        detail: {},
      },
      {
        id: 1,
        at: "2026-09-20T13:00:00Z",
        action: "disable",
        target_username: "ali",
        detail: {},
      },
    ]);
    assert.ok(mapped);
    assert.equal(mapped.length, 2);
    assert.equal(mapped[0].id, 2);
    assert.equal(mapped[0].summary, "ali enabled");
    assert.equal(mapped[1].summary, "ali disabled");
    assert.equal(mapped[0].category, "Accounts");
  });

  it("links shop/staff only when UUIDs are valid", () => {
    const withIds = mapActivityEvent({
      id: 5,
      at: "2026-09-20T12:00:00Z",
      action: "assign_shop",
      target_username: "ali",
      detail: { shop_id: SHOP_ID, staff_id: STAFF_ID, shop: "Shop 1" },
    });
    assert.ok(withIds);
    assert.equal(withIds.shop_id, SHOP_ID);
    assert.equal(withIds.staff_id, STAFF_ID);

    const bad = mapActivityEvent({
      id: 6,
      at: "2026-09-20T12:00:00Z",
      action: "assign_shop",
      target_username: "ali",
      detail: { shop_id: "not-a-uuid", shop: "Shop 1" },
    });
    assert.ok(bad);
    assert.equal(bad.shop_id, null);
  });

  it("marks recover_identity as important", () => {
    const ev = mapActivityEvent({
      id: 7,
      at: "2026-09-20T12:00:00Z",
      action: "recover_identity",
      target_username: null,
      detail: { staff_restored: 3 },
    });
    assert.ok(ev);
    assert.equal(ev.important, true);
    assert.equal(ev.summary, "Identity recovery performed");
  });

  it("returns null on malformed list payload", () => {
    assert.equal(mapActivityList(null), null);
    assert.equal(mapActivityList({}), null);
    assert.equal(
      mapActivityList([{ id: 1, at: "x" /* missing action */ }]),
      null,
    );
  });

  it("maps empty list", () => {
    const mapped = mapActivityList([]);
    assert.ok(mapped);
    assert.equal(mapped.length, 0);
  });
});

describe("filters / query parsing", () => {
  it("parses group, target, dates, and paging", () => {
    const url = new URL(
      "https://x.test/api/activity?group=accounts&target=ali&from=2026-09-01&to=2026-09-20&limit=25&offset=25",
    );
    const parsed = parseActivityQuery(url);
    assert.equal(parsed.ok, true);
    if (!parsed.ok) return;
    assert.equal(parsed.group, "accounts");
    assert.equal(parsed.target, "ali");
    assert.equal(parsed.from, "2026-09-01");
    assert.equal(parsed.to, "2026-09-20");
    assert.equal(parsed.limit, 25);
    assert.equal(parsed.offset, 25);
    assert.ok(parsed.fromIso);
    assert.ok(parsed.toIso);
  });

  it("rejects invalid dates, inverted range, long target, bad group", () => {
    assert.equal(
      parseActivityQuery(new URL("https://x.test/a?from=20-09-2026")).ok,
      false,
    );
    assert.equal(
      parseActivityQuery(
        new URL("https://x.test/a?from=2026-09-20&to=2026-09-01"),
      ).ok,
      false,
    );
    assert.equal(
      parseActivityQuery(new URL(`https://x.test/a?target=${"a".repeat(65)}`)).ok,
      false,
    );
    assert.equal(
      parseActivityQuery(new URL("https://x.test/a?group=hackers")).ok,
      false,
    );
    assert.equal(
      parseActivityQuery(new URL("https://x.test/a?offset=-1")).ok,
      false,
    );
  });

  it("maps single-action groups to rpc action; multi-action needs post-filter", () => {
    assert.equal(rpcActionForGroup("roles"), "set_role");
    assert.equal(rpcActionForGroup("credentials"), "reset_server_credential");
    assert.equal(rpcActionForGroup("recovery"), "recover_identity");
    assert.equal(rpcActionForGroup("accounts"), null);
    assert.equal(rpcActionForGroup("shops"), null);
    assert.equal(rpcActionForGroup("all"), null);
    assert.equal(groupNeedsPostFilter("accounts"), true);
    assert.equal(groupNeedsPostFilter("roles"), false);
  });

  it("filters events by group", () => {
    const events = mapActivityList([
      {
        id: 1,
        at: "2026-09-20T12:00:00Z",
        action: "create",
        target_username: "a",
        detail: {},
      },
      {
        id: 2,
        at: "2026-09-20T12:01:00Z",
        action: "set_role",
        target_username: "a",
        detail: {},
      },
      {
        id: 3,
        at: "2026-09-20T12:02:00Z",
        action: "add_shop",
        detail: { name: "N" },
      },
    ]);
    assert.ok(events);
    assert.equal(filterEventsByGroup(events, "accounts").length, 1);
    assert.equal(filterEventsByGroup(events, "roles").length, 1);
    assert.equal(filterEventsByGroup(events, "shops").length, 1);
    assert.equal(filterEventsByGroup(events, "all").length, 3);
  });

  it("validates date helpers", () => {
    assert.equal(isValidDateInput("2026-09-20"), true);
    assert.equal(isValidDateInput("2026-13-01"), false);
    assert.equal(isValidDateInput("not-a-date"), false);
    const start = localDateToIsoBound("2026-09-20", "start");
    const end = localDateToIsoBound("2026-09-20", "end");
    assert.ok(start);
    assert.ok(end);
    assert.ok(start < end);
  });

  it("categoryForAction covers groups", () => {
    assert.equal(categoryForAction("create"), "Accounts");
    assert.equal(categoryForAction("set_role"), "Roles");
    assert.equal(categoryForAction("add_shop"), "Shops");
    assert.equal(categoryForAction("reset_server_credential"), "Credentials");
    assert.equal(categoryForAction("recover_identity"), "Recovery");
    assert.equal(categoryForAction("mystery"), "Other");
  });
});
