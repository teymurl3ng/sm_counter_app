import Link from "next/link";
import { redirect } from "next/navigation";
import { readViewerSession } from "@/lib/session";
import { getAccountServerConfig } from "@/lib/config";
import { ThemeToggle } from "./theme-toggle";

export default async function HomePage() {
  const session = await readViewerSession();
  if (session) {
    redirect("/overview");
  }

  let envLabel = "DEV";
  try {
    const cfg = getAccountServerConfig();
    envLabel = cfg.env.toUpperCase();
  } catch {
    /* keep default */
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center px-6">
      <div className="absolute right-4 top-4 sm:right-6 sm:top-6">
        <ThemeToggle />
      </div>
      <div className="w-full max-w-md text-center">
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--accent)] shadow-lg">
              <span className="text-2xl font-bold text-white">S</span>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-[var(--ink)]">
              Saaf Milk
            </h1>
            <p className="text-lg text-[var(--muted)]">Admin Viewer</p>
          </div>

          <p className="text-sm leading-relaxed text-[var(--muted)]">
            Administrative dashboard for identity, staff, shops,
            and activity monitoring.
          </p>

          <div className="flex flex-col items-center gap-3 pt-4">
            <Link
              href="/login"
              className="inline-flex w-full items-center justify-center rounded-lg bg-[var(--accent)] px-6 py-3 text-sm font-semibold text-white shadow-sm transition-all duration-150 hover:bg-[var(--accent)]/80 hover:shadow-md active:scale-[0.98]"
            >
              Continue to Login
            </Link>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
              {envLabel} Environment
            </span>
          </div>

          <p className="pt-4 text-xs text-[var(--muted)]">
            Access restricted to owners and admins.
          </p>
        </div>
      </div>
    </main>
  );
}
