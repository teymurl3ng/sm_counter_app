"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  classifyStaffEmpty,
  formatStaffDate,
  STAFF_PAGE_SIZE_DEFAULT,
  type StaffListApiResponse,
  type StaffListItem,
} from "@/lib/staff";
import { STAFF_ROLES, type StaffStatus } from "@/lib/staff-status";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek } from "@/lib/viewer-cache";

type LoadState = "loading" | "ready" | "error";

function StatusText({ status }: { status: StaffStatus }) {
  const color =
    status === "Active"
      ? "text-[var(--success)]"
      : status === "Disabled"
        ? "text-[var(--warn)]"
        : "text-[var(--muted)]";
  return <span className={`text-sm font-medium ${color}`}>{status}</span>;
}

function ListSkeleton() {
  return (
    <div className="space-y-3" aria-busy="true" aria-label="Loading staff">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="h-14 animate-pulse rounded-xl border border-[var(--line)] bg-[var(--card)]" />
      ))}
    </div>
  );
}

function buildQueryString(opts: {
  search: string;
  role: string;
  status: string;
  shopId: string;
  offset: number;
  limit: number;
}): string {
  const p = new URLSearchParams();
  if (opts.search.trim()) p.set("search", opts.search.trim());
  if (opts.role && opts.role !== "all") p.set("role", opts.role);
  if (opts.status && opts.status !== "all") p.set("status", opts.status);
  if (opts.shopId) p.set("shop_id", opts.shopId);
  if (opts.offset > 0) p.set("offset", String(opts.offset));
  if (opts.limit !== STAFF_PAGE_SIZE_DEFAULT) p.set("limit", String(opts.limit));
  const s = p.toString();
  return s ? `?${s}` : "";
}

export function StaffListPanel() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const urlSearch = searchParams.get("search") || "";
  const urlRole = (searchParams.get("role") || "all").toLowerCase();
  const urlStatus = (searchParams.get("status") || "all").toLowerCase();
  const urlShop = searchParams.get("shop_id") || "";
  const urlOffset = Math.max(0, Number.parseInt(searchParams.get("offset") || "0", 10) || 0);

  const [searchInput, setSearchInput] = useState(urlSearch);
  const initialQs = buildQueryString({
    search: urlSearch,
    role: urlRole,
    status: urlStatus,
    shopId: urlShop,
    offset: urlOffset,
    limit: STAFF_PAGE_SIZE_DEFAULT,
  });
  const peeked = viewerCachePeek(`staff${initialQs}`) as StaffListApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok && peeked.staff ? "ready" : "loading");
  const [data, setData] = useState<StaffListApiResponse | null>(peeked);

  const [previousSearch, setPreviousSearch] = useState(urlSearch);
  if (previousSearch !== urlSearch) {
    setPreviousSearch(urlSearch);
    setSearchInput(urlSearch);
  }

  const syncUrl = useCallback(
    (next: {
      search?: string;
      role?: string;
      status?: string;
      shopId?: string;
      offset?: number;
    }) => {
      const qs = buildQueryString({
        search: next.search ?? urlSearch,
        role: next.role ?? urlRole,
        status: next.status ?? urlStatus,
        shopId: next.shopId ?? urlShop,
        offset: next.offset ?? 0,
        limit: STAFF_PAGE_SIZE_DEFAULT,
      });
      router.replace(`${pathname}${qs}`);
    },
    [pathname, router, urlRole, urlSearch, urlShop, urlStatus],
  );

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    const qs = buildQueryString({
      search: urlSearch,
      role: urlRole,
      status: urlStatus,
      shopId: urlShop,
      offset: urlOffset,
      limit: STAFF_PAGE_SIZE_DEFAULT,
    });
    const apply = (status: number, json: StaffListApiResponse) => {
      if (!isCurrent()) return;
      if (
        status === 401 ||
        json.error?.code === "UNAUTHENTICATED" ||
        json.error?.code === "UNAUTHORIZED"
      ) {
        router.replace("/login?error=session");
        return;
      }
      setData(json);
      if (json.ok && json.staff) setState("ready");
      else setState("error");
    };
    try {
      const result = await viewerCachedGet({
        key: `staff${qs}`,
        url: `/api/staff${qs}`,
        ttlMs: VIEWER_TTL.staffList,
        onRevalidated: ({ status, body }) => apply(status, body as StaffListApiResponse),
      });
      apply(result.status, result.body as StaffListApiResponse);
    } catch {
      if (!isCurrent()) return;
      setData({
        ok: false,
        env: "unknown",
        contract: "v1.1.0-read-admin",
        staff: null,
        shopOptions: [],
        page: { limit: STAFF_PAGE_SIZE_DEFAULT, offset: 0, hasMore: false, count: 0 },
        query: {
          search: urlSearch || null,
          role: urlRole === "all" ? null : urlRole,
          status: urlStatus === "all" ? null : urlStatus,
          shopId: urlShop || null,
          limit: STAFF_PAGE_SIZE_DEFAULT,
          offset: urlOffset,
        },
        error: {
          code: "SERVER_UNAVAILABLE",
          message: "Account Server could not be reached.",
        },
      });
      setState("error");
    }
  }, [router, urlOffset, urlRole, urlSearch, urlShop, urlStatus]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (searchInput.trim() === urlSearch.trim()) return;
      syncUrl({ search: searchInput, offset: 0 });
    }, 400);
    return () => clearTimeout(t);
  }, [searchInput, syncUrl, urlSearch]);

  const hasActiveFilters = useMemo(() => {
    return Boolean(
      urlSearch.trim() ||
        (urlRole && urlRole !== "all") ||
        (urlStatus && urlStatus !== "all") ||
        urlShop,
    );
  }, [urlRole, urlSearch, urlShop, urlStatus]);

  const emptyKind =
    state === "ready" && data?.staff && data.staff.length === 0
      ? classifyStaffEmpty({
          search: urlSearch.trim() || null,
          role: urlRole === "all" ? null : urlRole,
          status: urlStatus === "all" ? null : urlStatus,
          shopId: urlShop || null,
          limit: STAFF_PAGE_SIZE_DEFAULT,
          offset: urlOffset,
        })
      : null;

  const emptyMessage =
    emptyKind === "search"
      ? "No staff match your search."
      : emptyKind === "filters"
        ? "No staff match these filters."
        : emptyKind === "none"
          ? "No staff accounts yet."
          : null;

  function detailHref(item: StaffListItem) {
    return `/staff/${item.staff_id}`;
  }

  const envLabel = (data?.env || "unknown").toUpperCase();

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Unified header */}
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">Staff</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Who has access, their role and status, and which shops apply.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
            <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
            {envLabel}
          </span>
          <Link
            href="/staff/create"
            className="rounded-lg bg-[var(--ink)] px-3 py-1.5 text-sm font-medium text-[var(--bg)] hover:opacity-90"
          >
            + Create Staff
          </Link>
        </div>
      </header>

      {/* Filters */}
      <section
        className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm"
        aria-label="Search and filters"
      >
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="block flex-1 text-sm">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Search</span>
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  syncUrl({ search: searchInput, offset: 0 });
                }
              }}
              placeholder="Name or username"
              maxLength={64}
              className="mt-1.5 w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-[var(--ink)] placeholder:text-[var(--muted)]/60"
            />
          </label>
          <label className="block text-sm sm:w-36">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Status</span>
            <select
              value={urlStatus}
              onChange={(e) => syncUrl({ status: e.target.value, offset: 0 })}
              className="mt-1.5 w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-2.5 py-2 text-[var(--ink)]"
            >
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="disabled">Disabled</option>
              <option value="terminated">Terminated</option>
            </select>
          </label>
          <label className="block text-sm sm:w-36">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Role</span>
            <select
              value={urlRole}
              onChange={(e) => syncUrl({ role: e.target.value, offset: 0 })}
              className="mt-1.5 w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-2.5 py-2 text-[var(--ink)]"
            >
              <option value="all">All</option>
              {STAFF_ROLES.map((r) => (
                <option key={r} value={r}>
                  {r.charAt(0).toUpperCase() + r.slice(1)}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm sm:min-w-40 sm:flex-1">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Shop</span>
            <select
              value={urlShop}
              onChange={(e) => syncUrl({ shopId: e.target.value, offset: 0 })}
              className="mt-1.5 w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-2.5 py-2 text-[var(--ink)]"
            >
              <option value="">All shops</option>
              {(data?.shopOptions || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                  {!s.active ? " (inactive)" : ""}
                </option>
              ))}
            </select>
          </label>
        </div>
        {hasActiveFilters ? (
          <button
            type="button"
            onClick={() => {
              setSearchInput("");
              router.replace(pathname);
            }}
            className="mt-3 text-sm font-medium text-[var(--accent)] underline-offset-2 hover:underline"
          >
            Clear filters
          </button>
        ) : null}
      </section>

      {state === "loading" ? <ListSkeleton /> : null}

      {state === "error" ? (
        <section className="space-y-3 rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4" role="alert">
          <p className="text-sm text-[var(--danger)]">
            {data?.error?.message || "Staff list is unavailable."}
          </p>
          <p className="text-sm text-[var(--muted)]">
            Staff are not shown while data cannot be loaded.
          </p>
          <button
            type="button"
            onClick={() => void load()}
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium hover:bg-[var(--bg)]"
          >
            Retry
          </button>
        </section>
      ) : null}

      {state === "ready" && data?.staff ? (
        <>
          {emptyMessage ? (
            <p className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-6 text-center text-sm text-[var(--muted)]">{emptyMessage}</p>
          ) : (
            <>
              {/* Desktop table */}
              <div className="hidden overflow-hidden rounded-xl border border-[var(--line)] bg-[var(--card)] shadow-sm md:block">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[var(--line)] bg-[var(--bg)] text-xs tracking-wide text-[var(--muted)] uppercase">
                    <tr>
                      <th className="px-4 py-3 font-medium">Person</th>
                      <th className="px-4 py-3 font-medium">Role</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium">Shop(s)</th>
                      <th className="px-4 py-3 font-medium">Created</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--line)]">
                    {data.staff.map((row) => (
                      <tr key={row.staff_id} className="transition-colors duration-100 hover:bg-[var(--bg)]">
                        <td className="px-4 py-3">
                          <Link href={detailHref(row)} className="block">
                            <span className="font-medium text-[var(--ink)]">{row.display_name}</span>
                            <span className="mt-0.5 block text-xs text-[var(--muted)]">
                              {row.username}
                            </span>
                          </Link>
                        </td>
                        <td className="px-4 py-3">
                          <Link href={detailHref(row)} className="text-[var(--ink)]">{row.role_label}</Link>
                        </td>
                        <td className="px-4 py-3">
                          <Link href={detailHref(row)}>
                            <StatusText status={row.status} />
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-[var(--muted)]">
                          <Link href={detailHref(row)}>{row.shops_label}</Link>
                        </td>
                        <td className="px-4 py-3 tabular-nums text-[var(--muted)]">
                          <Link href={detailHref(row)}>
                            {formatStaffDate(row.created_at)}
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile cards */}
              <ul className="space-y-2 md:hidden">
                {data.staff.map((row) => (
                  <li key={row.staff_id}>
                    <Link
                      href={detailHref(row)}
                      className="block rounded-xl border border-[var(--line)] bg-[var(--card)] p-3.5 shadow-sm transition-colors duration-100 hover:border-[var(--accent)]/30"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-medium text-[var(--ink)]">{row.display_name}</p>
                          <p className="text-sm text-[var(--muted)]">{row.username}</p>
                        </div>
                        <StatusText status={row.status} />
                      </div>
                      <p className="mt-2 text-sm">
                        <span className="text-[var(--ink)]">{row.role_label}</span>
                        <span className="text-[var(--muted)]"> · {row.shops_label}</span>
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
            </>
          )}

          {/* Pagination */}
          <div className="flex items-center justify-between gap-3 pt-2">
            <button
              type="button"
              disabled={urlOffset <= 0}
              onClick={() =>
                syncUrl({
                  offset: Math.max(0, urlOffset - STAFF_PAGE_SIZE_DEFAULT),
                })
              }
              className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
            >
              Previous
            </button>
            <p className="text-xs text-[var(--muted)]">
              {data.staff.length === 0
                ? "No results"
                : `Showing ${urlOffset + 1}–${urlOffset + data.staff.length}`}
              {data.page.hasMore ? "+" : ""}
            </p>
            <button
              type="button"
              disabled={!data.page.hasMore}
              onClick={() => syncUrl({ offset: urlOffset + STAFF_PAGE_SIZE_DEFAULT })}
              className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
            >
              Next
            </button>
          </div>
          <p className="text-xs text-[var(--muted)]">
            Sorted by username (Account Server default).
          </p>
        </>
      ) : null}
    </div>
  );
}
