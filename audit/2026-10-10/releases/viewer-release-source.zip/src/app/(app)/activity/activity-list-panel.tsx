"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  ACTIVITY_GROUPS,
  ACTIVITY_PAGE_SIZE_DEFAULT,
  isActivityGroup,
  type ActivityGroup,
  type ActivityListApiResponse,
  type ActivityListItem,
} from "@/lib/activity";
import { formatActivityTime } from "@/lib/overview";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek } from "@/lib/viewer-cache";

type LoadState = "loading" | "ready" | "error";

function ListSkeleton() {
  return (
    <div className="space-y-3" aria-busy="true" aria-label="Loading activity">
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          key={i}
          className="h-14 animate-pulse rounded-xl border border-[var(--line)] bg-[var(--card)]"
        />
      ))}
    </div>
  );
}

function CategoryPill({ category, important }: { category: string; important?: boolean }) {
  return (
    <span
      className={`inline-flex rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide uppercase ${
        important
          ? "bg-[var(--orange-light)] text-[var(--orange)]"
          : "bg-[var(--bg)] text-[var(--muted)]"
      }`}
    >
      {category}
    </span>
  );
}

function EventDetailPanel({
  event,
  onClose,
}: {
  event: ActivityListItem;
  onClose: () => void;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeRef.current?.focus();
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-black/30 p-4 sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-labelledby="activity-detail-title"
      onClick={onClose}
    >
      <div
        className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-xl border border-[var(--line)] bg-[var(--card)] p-5 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <p className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Event</p>
            <h2 id="activity-detail-title" className="text-lg font-semibold leading-snug text-[var(--ink)]">
              {event.summary}
            </h2>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            className="rounded-lg border border-[var(--line)] px-2.5 py-1.5 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)]"
          >
            Close
          </button>
        </div>

        <dl className="mt-5 space-y-2.5 text-sm">
          <div className="flex justify-between gap-3">
            <dt className="text-[var(--muted)]">When</dt>
            <dd className="tabular-nums text-[var(--ink)]">
              <time dateTime={event.at}>
                {new Date(event.at).toLocaleString(undefined, {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                  hour: "numeric",
                  minute: "2-digit",
                  second: "2-digit",
                })}
              </time>
            </dd>
          </div>
          {event.target_username ? (
            <div className="flex justify-between gap-3">
              <dt className="text-[var(--muted)]">Target</dt>
              <dd className="font-medium text-[var(--ink)]">{event.target_username}</dd>
            </div>
          ) : null}
          <div className="flex justify-between gap-3">
            <dt className="text-[var(--muted)]">Category</dt>
            <dd>
              <CategoryPill category={event.category} important={event.important} />
            </dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-[var(--muted)]">Action</dt>
            <dd className="font-mono text-xs text-[var(--muted)]">{event.action}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-[var(--muted)]">Audit ID</dt>
            <dd className="font-mono text-xs text-[var(--muted)]">{String(event.id)}</dd>
          </div>
        </dl>

        {event.safe_fields.length > 0 ? (
          <section className="mt-5 space-y-2" aria-label="Details">
            <h3 className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Details</h3>
            <dl className="space-y-2.5 text-sm">
              {event.safe_fields.map((f) => (
                <div key={f.key} className="flex justify-between gap-3">
                  <dt className="text-[var(--muted)]">{f.label}</dt>
                  <dd className="max-w-[60%] break-words text-right text-[var(--ink)]">
                    {f.key === "shop_id" && event.shop_id ? (
                      <Link href={`/shops/${event.shop_id}`} className="text-[var(--accent)] underline-offset-2 hover:underline">
                        {f.value}
                      </Link>
                    ) : f.key === "staff_id" && event.staff_id ? (
                      <Link href={`/staff/${event.staff_id}`} className="text-[var(--accent)] underline-offset-2 hover:underline">
                        {f.value}
                      </Link>
                    ) : (
                      f.value
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          </section>
        ) : null}

        {event.suppressed_sensitive ? (
          <p className="mt-3 text-xs text-[var(--warn)]" role="status">
            Sensitive credential fields were withheld from this event.
          </p>
        ) : null}

        <div className="mt-5 flex flex-wrap gap-2">
          {event.staff_id ? (
            <Link
              href={`/staff/${event.staff_id}`}
              className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)]"
            >
              View staff
            </Link>
          ) : null}
          {event.shop_id ? (
            <Link
              href={`/shops/${event.shop_id}`}
              className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)]"
            >
              {event.shop_name ? `View ${event.shop_name}` : "View shop"}
            </Link>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export function ActivityListPanel() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const groupParam = searchParams.get("group") || "all";
  const group: ActivityGroup = isActivityGroup(groupParam) ? groupParam : "all";
  const target = (searchParams.get("target") || "").trim();
  const from = (searchParams.get("from") || "").trim();
  const to = (searchParams.get("to") || "").trim();
  const offset = Math.max(0, Number.parseInt(searchParams.get("offset") || "0", 10) || 0);

  const [draftTarget, setDraftTarget] = useState(target);
  const [draftFrom, setDraftFrom] = useState(from);
  const [draftTo, setDraftTo] = useState(to);
  const activityPeekQs = new URLSearchParams();
  activityPeekQs.set("limit", String(ACTIVITY_PAGE_SIZE_DEFAULT));
  if (group !== "all") activityPeekQs.set("group", group);
  if (target) activityPeekQs.set("target", target);
  if (from) activityPeekQs.set("from", from);
  if (to) activityPeekQs.set("to", to);
  if (offset > 0) activityPeekQs.set("offset", String(offset));
  const peeked = viewerCachePeek(`activity?${activityPeekQs.toString()}`) as ActivityListApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok && peeked.events ? "ready" : "loading");
  const [data, setData] = useState<ActivityListApiResponse | null>(peeked);
  const [selected, setSelected] = useState<ActivityListItem | null>(null);

  const filterIdentity = `${target}|${from}|${to}`;
  const [previousFilters, setPreviousFilters] = useState(filterIdentity);
  if (previousFilters !== filterIdentity) {
    setPreviousFilters(filterIdentity);
    setDraftTarget(target);
    setDraftFrom(from);
    setDraftTo(to);
  }

  const queryKey = useMemo(
    () => `${group}|${target}|${from}|${to}|${offset}`,
    [group, target, from, to, offset],
  );

  const buildHref = useCallback(
    (next: {
      group?: ActivityGroup;
      target?: string;
      from?: string;
      to?: string;
      offset?: number;
    }) => {
      const qs = new URLSearchParams();
      const g = next.group ?? group;
      if (g !== "all") qs.set("group", g);
      const t = next.target !== undefined ? next.target : target;
      if (t) qs.set("target", t);
      const f = next.from !== undefined ? next.from : from;
      if (f) qs.set("from", f);
      const tt = next.to !== undefined ? next.to : to;
      if (tt) qs.set("to", tt);
      const off = next.offset !== undefined ? next.offset : offset;
      if (off > 0) qs.set("offset", String(off));
      const s = qs.toString();
      return s ? `${pathname}?${s}` : pathname;
    },
    [group, target, from, to, offset, pathname],
  );

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    const qs = new URLSearchParams();
    qs.set("limit", String(ACTIVITY_PAGE_SIZE_DEFAULT));
    if (group !== "all") qs.set("group", group);
    if (target) qs.set("target", target);
    if (from) qs.set("from", from);
    if (to) qs.set("to", to);
    if (offset > 0) qs.set("offset", String(offset));
    const qsStr = qs.toString();
    const apply = (status: number, json: ActivityListApiResponse) => {
      if (!isCurrent()) return;
      if (
        status === 401 ||
        json.error?.code === "UNAUTHENTICATED" ||
        json.error?.code === "UNAUTHORIZED"
      ) {
        router.replace("/login?error=session");
        return;
      }
      setData(json);
      if (json.ok && json.events) setState("ready");
      else setState("error");
    };
    try {
      const result = await viewerCachedGet({
        key: `activity?${qsStr}`,
        url: `/api/activity?${qsStr}`,
        ttlMs: VIEWER_TTL.activity,
        onRevalidated: ({ status, body }) =>
          apply(status, body as ActivityListApiResponse),
      });
      apply(result.status, result.body as ActivityListApiResponse);
    } catch {
      if (!isCurrent()) return;
      setData({
        ok: false,
        env: "unknown",
        contract: "v1.1.0-read-admin",
        events: null,
        page: {
          limit: ACTIVITY_PAGE_SIZE_DEFAULT,
          offset: 0,
          hasMore: false,
          count: 0,
        },
        filters: { group: "all", target: null, from: null, to: null },
        group_post_filtered: false,
        error: {
          code: "SERVER_UNAVAILABLE",
          message: "Account Server could not be reached.",
        },
      });
      setState("error");
    }
  }, [group, target, from, to, offset, router]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load, queryKey]);

  function applyFilters(e: FormEvent) {
    e.preventDefault();
    router.replace(
      buildHref({
        target: draftTarget.trim(),
        from: draftFrom.trim(),
        to: draftTo.trim(),
        offset: 0,
      }),
    );
  }

  function clearFilters() {
    setDraftTarget("");
    setDraftFrom("");
    setDraftTo("");
    router.replace(pathname);
  }

  const hasFilters = group !== "all" || !!target || !!from || !!to;
  const showPaging =
    state === "ready" &&
    data?.events &&
    (offset > 0 || data.page.hasMore || data.events.length >= ACTIVITY_PAGE_SIZE_DEFAULT);

  const envLabel = (data?.env || "unknown").toUpperCase();

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Unified header */}
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">Activity</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Identity and access changes — what happened, when, and to whom.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
          {envLabel}
        </span>
      </header>

      {/* Filters */}
      <form
        onSubmit={applyFilters}
        className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm"
      >
        <div className="flex flex-wrap gap-1.5 pb-3" role="group" aria-label="Activity category">
          {ACTIVITY_GROUPS.map((g) => {
            const active = group === g.id;
            return (
              <button
                key={g.id}
                type="button"
                onClick={() => router.replace(buildHref({ group: g.id, offset: 0 }))}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors duration-150 ${
                  active
                    ? "bg-[var(--accent)] text-white shadow-sm"
                    : "border border-[var(--line)] bg-[var(--card)] text-[var(--muted)] hover:bg-[var(--bg)]"
                }`}
              >
                {g.label}
              </button>
            );
          })}
        </div>

        <div className="grid gap-3 border-t border-[var(--line)] pt-3 sm:grid-cols-3">
          <label className="block space-y-1.5 text-sm sm:col-span-1">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Target username</span>
            <input
              value={draftTarget}
              onChange={(e) => setDraftTarget(e.target.value)}
              placeholder="e.g. ali"
              maxLength={64}
              className="w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-[var(--ink)] placeholder:text-[var(--muted)]/60"
              autoComplete="off"
            />
          </label>
          <label className="block space-y-1.5 text-sm">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">From</span>
            <input
              type="date"
              value={draftFrom}
              onChange={(e) => setDraftFrom(e.target.value)}
              className="w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-[var(--ink)]"
            />
          </label>
          <label className="block space-y-1.5 text-sm">
            <span className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">To</span>
            <input
              type="date"
              value={draftTo}
              onChange={(e) => setDraftTo(e.target.value)}
              className="w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-[var(--ink)]"
            />
          </label>
        </div>

        <div className="mt-3 flex flex-wrap gap-2 border-t border-[var(--line)] pt-3">
          <button
            type="submit"
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)]"
          >
            Apply
          </button>
          <button
            type="button"
            onClick={clearFilters}
            disabled={!hasFilters && !draftTarget && !draftFrom && !draftTo}
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium text-[var(--muted)] transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
          >
            Clear
          </button>
        </div>
        <p className="mt-2 text-xs text-[var(--muted)]">
          Dates use your local timezone. Newest events first. Target filter matches
          username (server substring).
        </p>
      </form>

      {state === "loading" ? <ListSkeleton /> : null}

      {state === "error" ? (
        <section className="space-y-3 rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4" role="alert">
          <p className="text-sm text-[var(--danger)]">
            {data?.error?.message || "Activity is unavailable."}
          </p>
          <p className="text-sm text-[var(--muted)]">
            Activity is not shown while data cannot be loaded.
          </p>
          <button
            type="button"
            onClick={() => void load()}
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium hover:bg-[var(--bg)]"
          >
            Retry
          </button>
        </section>
      ) : null}

      {state === "ready" && data?.events ? (
        <>
          {data.events.length === 0 ? (
            <p className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-6 text-center text-sm text-[var(--muted)]">
              {hasFilters
                ? "No activity matches these filters."
                : "No account activity yet."}
            </p>
          ) : (
            <>
              {/* Desktop table */}
              <div className="hidden overflow-hidden rounded-xl border border-[var(--line)] bg-[var(--card)] shadow-sm md:block">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[var(--line)] bg-[var(--bg)] text-xs tracking-wide text-[var(--muted)] uppercase">
                    <tr>
                      <th className="px-4 py-3 font-medium">Time</th>
                      <th className="px-4 py-3 font-medium">Event</th>
                      <th className="px-4 py-3 font-medium">Target</th>
                      <th className="px-4 py-3 font-medium">Category</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--line)]">
                    {data.events.map((ev) => (
                      <tr
                        key={String(ev.id)}
                        className="cursor-pointer transition-colors duration-100 hover:bg-[var(--bg)]"
                        tabIndex={0}
                        role="button"
                        aria-label={`Open details: ${ev.summary}`}
                        onClick={() => setSelected(ev)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            setSelected(ev);
                          }
                        }}
                      >
                        <td className="px-4 py-3 whitespace-nowrap tabular-nums text-[var(--muted)]">
                          <time dateTime={ev.at}>{formatActivityTime(ev.at)}</time>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-[var(--ink)] ${ev.important ? "font-medium" : ""}`}>
                            {ev.summary}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-[var(--muted)]">
                          {ev.target_username || "—"}
                        </td>
                        <td className="px-4 py-3">
                          <CategoryPill category={ev.category} important={ev.important} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile cards */}
              <ul className="space-y-2 md:hidden">
                {data.events.map((ev) => (
                  <li key={String(ev.id)}>
                    <button
                      type="button"
                      onClick={() => setSelected(ev)}
                      className="w-full rounded-xl border border-[var(--line)] bg-[var(--card)] p-3.5 text-left shadow-sm transition-colors duration-100 hover:border-[var(--accent)]/30"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className={`text-sm leading-snug text-[var(--ink)] ${ev.important ? "font-medium" : ""}`}>
                          {ev.summary}
                        </p>
                        <CategoryPill category={ev.category} important={ev.important} />
                      </div>
                      <p className="mt-1 text-xs text-[var(--muted)]">
                        <time dateTime={ev.at}>{formatActivityTime(ev.at)}</time>
                        {ev.target_username ? (
                          <>
                            <span className="mx-1">·</span>
                            {ev.target_username}
                          </>
                        ) : null}
                      </p>
                    </button>
                  </li>
                ))}
              </ul>

              <p className="text-xs text-[var(--muted)]">
                Ordered newest first (server). Click an event for details. Credential values
                are never shown.
              </p>
            </>
          )}

          {showPaging ? (
            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                type="button"
                disabled={offset <= 0}
                onClick={() =>
                  router.replace(
                    buildHref({ offset: Math.max(0, offset - ACTIVITY_PAGE_SIZE_DEFAULT) }),
                  )
                }
                className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
              >
                Previous
              </button>
              <p className="text-xs text-[var(--muted)]">
                {data.events.length === 0
                  ? "No results"
                  : `Showing ${offset + 1}–${offset + data.events.length}`}
                {data.page.hasMore ? "+" : ""}
              </p>
              <button
                type="button"
                disabled={!data.page.hasMore}
                onClick={() =>
                  router.replace(buildHref({ offset: offset + ACTIVITY_PAGE_SIZE_DEFAULT }))
                }
                className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
              >
                Next
              </button>
            </div>
          ) : null}
        </>
      ) : null}

      {selected ? (
        <EventDetailPanel event={selected} onClose={() => setSelected(null)} />
      ) : null}
    </div>
  );
}
