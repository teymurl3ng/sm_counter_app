"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

export function NavHighlight() {
  const pathname = usePathname();

  useEffect(() => {
    const links = document.querySelectorAll<HTMLAnchorElement>(".nav-item");
    links.forEach((link) => {
      const href = link.getAttribute("href");
      const isActive =
        href === pathname ||
        (href !== "/" && pathname.startsWith(href!));
      if (isActive) {
        link.classList.remove(
          "text-[var(--muted)]",
          "hover:bg-[var(--accent-light)]",
          "hover:text-[var(--accent)]",
        );
        link.classList.add(
          "bg-[var(--accent-light)]",
          "text-[var(--accent)]",
          "font-semibold",
        );
      } else {
        link.classList.remove(
          "bg-[var(--accent-light)]",
          "text-[var(--accent)]",
          "font-semibold",
        );
        link.classList.add(
          "text-[var(--muted)]",
          "hover:bg-[var(--accent-light)]",
          "hover:text-[var(--accent)]",
        );
      }
    });
  }, [pathname]);

  return null;
}
