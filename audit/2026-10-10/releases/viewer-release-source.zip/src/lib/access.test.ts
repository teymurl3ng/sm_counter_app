import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { decideViewerAccess } from "./access";
import {
  isPlausibleCredential,
  isPlausibleUsername,
  normalizeCredential,
  normalizeUsername,
} from "./normalize";
import type { SessionProfile } from "./types";

const baseProfile = (over: Partial<SessionProfile> = {}): SessionProfile => ({
  staff_id: "00000000-0000-0000-0000-000000000001",
  username: "alice",
  display_name: "Alice",
  role: "owner",
  active: true,
  terminated_at: null,
  business_id: "00000000-0000-0000-0000-000000000002",
  ...over,
});

describe("normalize", () => {
  it("trims and lowercases username", () => {
    assert.equal(normalizeUsername("  TeImUr  "), "teimur");
  });
  it("strips non-digits from credential", () => {
    assert.equal(normalizeCredential("12345-67890-12345"), "123456789012345");
  });
  it("validates username and credential shapes", () => {
    assert.equal(isPlausibleUsername("ab"), false);
    assert.equal(isPlausibleUsername("alice"), true);
    assert.equal(isPlausibleCredential("123"), false);
    assert.equal(isPlausibleCredential("123456789012345"), true);
  });
});

describe("decideViewerAccess", () => {
  it("allows active owner and admin", () => {
    assert.equal(decideViewerAccess(true, false, baseProfile({ role: "owner" })).kind, "ALLOWED");
    assert.equal(decideViewerAccess(true, false, baseProfile({ role: "admin" })).kind, "ALLOWED");
  });
  it("denies lower roles", () => {
    for (const role of ["manager", "cashier", "operator"] as const) {
      assert.equal(
        decideViewerAccess(true, false, baseProfile({ role })).kind,
        "ROLE_DENIED",
      );
    }
  });
  it("denies disabled", () => {
    assert.equal(
      decideViewerAccess(true, false, baseProfile({ active: false })).kind,
      "DISABLED",
    );
  });
  it("maps invalid credentials and not authorized", () => {
    assert.equal(decideViewerAccess(false, true, null).kind, "INVALID_CREDENTIALS");
    assert.equal(decideViewerAccess(true, false, null).kind, "NOT_AUTHORIZED");
  });
  it("maps network failure to UNKNOWN", () => {
    assert.equal(
      decideViewerAccess(false, false, null, "down").kind,
      "UNKNOWN",
    );
  });
});
