import assert from "node:assert/strict";
import { it } from "node:test";
import { createOutcomeIsAmbiguous } from "./identity-create";
it("retains identities after lost, malformed, proxy and server responses", () => {
  for (const result of [
    { kind: "unreachable" as const },
    { kind: "ok" as const, data: null },
    { kind: "error" as const, status: 502, body: {} },
    { kind: "error" as const, status: 400, body: "proxy error" },
    { kind: "error" as const, status: 429, body: {} },
  ]) assert.equal(createOutcomeIsAmbiguous(result), true);
});
it("recognizes valid completion and definitive permission/SQL rejection", () => {
  assert.equal(createOutcomeIsAmbiguous({kind: "ok", data: "11111111-1111-4111-8111-111111111111"}), false);
  assert.equal(createOutcomeIsAmbiguous({kind: "unauthorized", status: 403}), false);
  assert.equal(createOutcomeIsAmbiguous({kind: "error", status: 409, body: {code: "23505"}}), false);
  assert.equal(createOutcomeIsAmbiguous({kind: "error", status: 409, body: '{"code":"23505"}'}), false);
});
