import { NextResponse } from "next/server";
import { signInWithServerCredential } from "@/lib/account-server";
import { setViewerSession } from "@/lib/session";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: { username?: string; credential?: string };
  try {
    body = (await request.json()) as { username?: string; credential?: string };
  } catch {
    return NextResponse.json(
      { ok: false, code: "INVALID_CREDENTIALS", message: "Could not sign in." },
      { status: 400 },
    );
  }

  const outcome = await signInWithServerCredential(
    body.username ?? "",
    body.credential ?? "",
  );

  switch (outcome.kind) {
    case "ALLOWED":
      await setViewerSession({
        accessToken: outcome.accessToken,
        refreshToken: outcome.refreshToken,
        profile: outcome.profile,
        expiresIn: outcome.expiresIn,
      });
      return NextResponse.json({
        ok: true,
        user: {
          username: outcome.profile.username,
          display_name: outcome.profile.display_name,
          role: outcome.profile.role,
        },
      });
    case "DISABLED":
      return NextResponse.json(
        { ok: false, code: "DISABLED", message: "This account is disabled." },
        { status: 403 },
      );
    case "ROLE_DENIED":
      return NextResponse.json(
        {
          ok: false,
          code: "ROLE_DENIED",
          message: "This account does not have access to the Admin Viewer.",
        },
        { status: 403 },
      );
    case "NOT_AUTHORIZED":
      return NextResponse.json(
        {
          ok: false,
          code: "NOT_AUTHORIZED",
          message: "This account does not have access to the Admin Viewer.",
        },
        { status: 403 },
      );
    case "UNKNOWN":
      return NextResponse.json(
        {
          ok: false,
          code: "UNKNOWN",
          message: "Account Server could not be reached.",
        },
        { status: 503 },
      );
    case "INVALID_CREDENTIALS":
    default:
      return NextResponse.json(
        { ok: false, code: "INVALID_CREDENTIALS", message: "Could not sign in." },
        { status: 401 },
      );
  }
}
