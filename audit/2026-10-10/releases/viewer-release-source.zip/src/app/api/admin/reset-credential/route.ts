import { requireMutationContext, parseMutationBody, mutationError, mutationSuccess } from "@/lib/admin-mutation";
import { getAdminKeyConfig, getAccountServerConfig } from "@/lib/config";
import { callDataApiAdmin, callAuthAdminApi, callWriteRpc } from "@/lib/account-server";
import { isUuid, safeCorrelationId } from "@/lib/admin-security";
import { generateServerCredential } from "@/lib/credential";
import { elapsedMs } from "@/lib/perf";
import { logOperationalFailure, recordReconciliation } from "@/lib/reconciliation";

export async function POST(request: Request) {
  const reqRes = await requireMutationContext(request);
  if (!reqRes.ok) return reqRes.response;
  const { ctx } = reqRes;
  const correlationId = safeCorrelationId();

  const body = await parseMutationBody<{ staff_id?: string }>(request);
  if (!isUuid(body?.staff_id)) {
    return mutationError(ctx.meta, "INVALID_REQUEST", "A valid staff_id is required.", 400, {
      label: "admin.resetCredential",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  // Admin key is required for Auth API
  const adminKeyCfg = getAdminKeyConfig();
  if (!adminKeyCfg) {
    return mutationError(
      ctx.meta,
      "ADMIN_KEY_MISSING",
      "Account Server Admin Key is not configured for this environment.",
      503,
      { label: "admin.resetCredential", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) }
    );
  }

  const caller = ctx.profile;

  // 2. Fetch target staff using Admin Key (to get auth_user_id)
  const cfg = getAccountServerConfig();
  const staffRes = await callDataApiAdmin(
    adminKeyCfg.adminKey,
    cfg.url,
    "GET",
    `/rest/v1/staff?id=eq.${encodeURIComponent(body.staff_id)}&select=id,business_id,username,terminated_at,auth_user_id`
  );

  if (staffRes.kind !== "ok" || !Array.isArray(staffRes.data) || staffRes.data.length === 0) {
    return mutationError(ctx.meta, "NOT_FOUND", "Staff not found.", 404, {
      label: "admin.resetCredential",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }
  
  const target = staffRes.data[0] as {
    id: string;
    business_id: string;
    username: string;
    terminated_at: string | null;
    auth_user_id: string | null;
  };

  // 3. Business isolation
  if (target.business_id !== caller.business_id) {
    return mutationError(ctx.meta, "NOT_FOUND", "Staff not found.", 404, {
      label: "admin.resetCredential",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  // 4. Terminated / No Auth check
  if (target.terminated_at) {
    return mutationError(ctx.meta, "TERMINATED", "Cannot reset credentials for a terminated account.", 400, {
      label: "admin.resetCredential",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }
  if (!target.auth_user_id) {
    return mutationError(
      ctx.meta,
      "CONFLICT",
      "This account has no Auth identity (cannot reset). If it was terminated, create a new username instead.",
      400,
      { label: "admin.resetCredential", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) }
    );
  }

  // 5. Generate new credential
  const credential = generateServerCredential();

  // 6. Call Auth Admin API to update password
  const authRes = await callAuthAdminApi(
    adminKeyCfg.adminKey,
    cfg.url,
    "PUT",
    `/auth/v1/admin/users/${target.auth_user_id}`,
    { password: credential }
  );

  if (authRes.kind !== "ok") {
    return mutationError(
      ctx.meta,
      "INTERNAL_ERROR",
      "The credential could not be reset.",
      authRes.kind === "unreachable" ? 503 : 500,
      { label: "admin.resetCredential", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) }
    );
  }

  // 7. Audit through a caller-authorized RPC. If unavailable, preserve the
  // one-time credential while durably recording the missing audit work.
  const auditResult = await callWriteRpc(ctx.accessToken, "admin_record_reset_credential_audit", {
    p_staff_id: target.id,
  });
  if (auditResult.kind !== "ok") {
    const recorded = await recordReconciliation({
      adminKey: adminKeyCfg.adminKey,
      businessId: caller.business_id,
      operation: "reset_audit",
      authUserId: target.auth_user_id,
      targetUsername: target.username,
      performedBy: caller.staff_id,
      performedByUsername: caller.username,
      errorCode: auditResult.kind === "unreachable" ? "UNREACHABLE" : "SERVER_ERROR",
      correlationId,
    });
    logOperationalFailure("reset_credential_audit", correlationId, recorded ? "PENDING" : "RECORD_FAILED");
    if (!recorded) {
      return mutationError(ctx.meta, "INTERNAL_ERROR", "The credential changed, but its audit state could not be recorded.", 500, {
        label: "admin.resetCredential",
        sessionMs: ctx.sessionMs,
        totalMs: elapsedMs(ctx.tTotal),
      });
    }
    return mutationSuccess(
      ctx.meta,
      {
        credential,
        reconciliation_required: true,
        warning: "The credential changed, but its audit entry is pending reconciliation.",
      },
      { label: "admin.resetCredential", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) },
      202,
    );
  }

  return mutationSuccess(
    ctx.meta,
    { credential },
    {
      label: "admin.resetCredential",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    }
  );
  
}
