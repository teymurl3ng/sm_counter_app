import { isPlausibleUsername } from "./normalize";
import { isUuid } from "./admin-security";
import type { ViewerRole } from "./types";

export const ALLOWED_ROLES = ["owner", "admin", "manager", "cashier", "operator"] as const;

export function validateUsername(raw: string | undefined): { valid: boolean; normalized: string; error?: string } {
  if (!raw) return { valid: false, normalized: "", error: "Username is required." };
  const normalized = raw.trim().toLowerCase();
  if (!isPlausibleUsername(normalized)) {
    return { valid: false, normalized, error: "Username must be 3-32 characters: lowercase letters, digits, . _ - only." };
  }
  return { valid: true, normalized };
}

export function validateDisplayName(raw: string | undefined): { valid: boolean; normalized: string; error?: string } {
  if (!raw) return { valid: false, normalized: "", error: "Display name is required." };
  const normalized = raw.trim();
  if (normalized.length < 2 || normalized.length > 100) {
    return { valid: false, normalized, error: "Display name must be between 2 and 100 characters." };
  }
  return { valid: true, normalized };
}

export function validateRole(raw: string | undefined): { valid: boolean; role?: ViewerRole; error?: string } {
  if (!raw) return { valid: false, error: "Role is required." };
  if (!ALLOWED_ROLES.some((role) => role === raw)) {
    return { valid: false, error: "Invalid role." };
  }
  return { valid: true, role: raw as ViewerRole };
}

export function validateShops(
  role: ViewerRole,
  shopIds: unknown,
): { valid: boolean; shopIds: string[]; error?: string } {
  if (shopIds !== undefined && !Array.isArray(shopIds)) {
    return { valid: false, shopIds: [], error: "Shop assignments must be an array." };
  }
  const values = (shopIds ?? []) as unknown[];
  if (!values.every(isUuid)) {
    return { valid: false, shopIds: [], error: "Every shop assignment must be a valid UUID." };
  }
  const normalized = [...new Set(values as string[])];
  if (normalized.length !== values.length) {
    return { valid: false, shopIds: [], error: "Duplicate shop assignments are not allowed." };
  }
  if (normalized.length > 100) {
    return { valid: false, shopIds: [], error: "Too many shop assignments." };
  }
  if (role !== "owner" && normalized.length === 0) {
    return { valid: false, shopIds: [], error: "Non-owners require at least one shop assignment." };
  }
  return { valid: true, shopIds: normalized };
}
