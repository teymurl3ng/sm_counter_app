import "server-only";

import { decideViewerAccess } from "./access";
import { getAccountServerConfig } from "./config";
import {
  isPlausibleCredential,
  isPlausibleUsername,
  normalizeCredential,
  normalizeUsername,
} from "./normalize";
import type { AuthOutcome, SessionProfile, ViewerRole } from "./types";
import { buildPrivilegedHeaders } from "./admin-security";
import { readSuccessfulWriteRpcResponse } from "./write-rpc-response";

type TokenResponse = {
  access_token?: string;
  refresh_token?: string;
  expires_in?: number;
  error_code?: string;
  msg?: string;
  message?: string;
};

function pubHeaders(extra?: Record<string, string>): HeadersInit {
  const cfg = getAccountServerConfig();
  return {
    apikey: cfg.publishableKey,
    Authorization: `Bearer ${cfg.publishableKey}`,
    "Content-Type": "application/json",
    ...extra,
  };
}

function authHeaders(accessToken: string): HeadersInit {
  const cfg = getAccountServerConfig();
  return {
    apikey: cfg.publishableKey,
    Authorization: `Bearer ${accessToken}`,
    "Content-Type": "application/json",
  };
}

function parseProfile(raw: unknown): SessionProfile | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  if (typeof o.username !== "string" || typeof o.role !== "string") return null;
  return {
    staff_id: String(o.staff_id ?? ""),
    username: o.username,
    display_name: String(o.display_name ?? o.username),
    role: o.role as ViewerRole,
    active: Boolean(o.active),
    terminated_at: (o.terminated_at as string | null) ?? null,
    business_id: String(o.business_id ?? ""),
  };
}

export async function pingAccountServer(): Promise<{
  ok: boolean;
  at?: string;
  error?: string;
  durationMs: number;
}> {
  const cfg = getAccountServerConfig();
  const t0 = performance.now();
  try {
    const res = await fetch(`${cfg.url}/rest/v1/rpc/ping`, {
      method: "POST",
      headers: pubHeaders(),
      body: "{}",
      cache: "no-store",
    });
    const text = await res.text();
    const durationMs = Math.round(performance.now() - t0);
    if (!res.ok) {
      return { ok: false, error: `ping HTTP ${res.status}`, durationMs };
    }
    return { ok: true, at: text.replace(/^"|"$/g, ""), durationMs };
  } catch {
    return {
      ok: false,
      error: "Account Server could not be reached.",
      durationMs: Math.round(performance.now() - t0),
    };
  }
}

export async function fetchMyProfile(accessToken: string): Promise<{
  status: number;
  profile: SessionProfile | null;
  unreachable: boolean;
}> {
  const cfg = getAccountServerConfig();
  try {
    const res = await fetch(`${cfg.url}/rest/v1/rpc/my_profile`, {
      method: "POST",
      headers: authHeaders(accessToken),
      body: "{}",
      cache: "no-store",
    });
    if (!res.ok) {
      return { status: res.status, profile: null, unreachable: res.status >= 500 };
    }
    const raw = await res.json();
    return { status: res.status, profile: parseProfile(raw), unreachable: false };
  } catch {
    return { status: 0, profile: null, unreachable: true };
  }
}

export async function signInWithServerCredential(
  usernameRaw: string,
  credentialRaw: string,
): Promise<AuthOutcome> {
  const cfg = getAccountServerConfig();
  const username = normalizeUsername(usernameRaw);
  const credential = normalizeCredential(credentialRaw);

  if (!isPlausibleUsername(username) || !isPlausibleCredential(credential)) {
    return { kind: "INVALID_CREDENTIALS" };
  }

  const email = `${username}@${cfg.fakeDomain}`;

  let tokenJson: TokenResponse;
  let status: number;
  try {
    const res = await fetch(`${cfg.url}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: pubHeaders(),
      body: JSON.stringify({ email, password: credential }),
      cache: "no-store",
    });
    status = res.status;
    tokenJson = (await res.json()) as TokenResponse;
  } catch {
    return { kind: "UNKNOWN", message: "Account Server could not be reached." };
  }

  if (status === 400 && tokenJson.error_code === "invalid_credentials") {
    return { kind: "INVALID_CREDENTIALS" };
  }
  if (status !== 200 || !tokenJson.access_token) {
    if (status >= 500 || status === 0) {
      return { kind: "UNKNOWN", message: "Account Server could not be reached." };
    }
    return { kind: "INVALID_CREDENTIALS" };
  }

  const profileResult = await fetchMyProfile(tokenJson.access_token);
  if (profileResult.unreachable) {
    return { kind: "UNKNOWN", message: "Account Server could not be reached." };
  }

  const decision = decideViewerAccess(true, false, profileResult.profile);
  if (decision.kind !== "ALLOWED") {
    // Best-effort logout of the Auth session we just created
    void signOutBestEffort(tokenJson.access_token);
    return decision;
  }

  return {
    kind: "ALLOWED",
    profile: decision.profile,
    accessToken: tokenJson.access_token,
    refreshToken: tokenJson.refresh_token ?? null,
    expiresIn: tokenJson.expires_in ?? null,
  };
}

export async function signOutBestEffort(accessToken: string): Promise<void> {
  const cfg = getAccountServerConfig();
  try {
    await fetch(`${cfg.url}/auth/v1/logout?scope=local`, {
      method: "POST",
      headers: authHeaders(accessToken),
      body: "{}",
      cache: "no-store",
    });
  } catch {
    // best-effort
  }
}

export type AdminRpcResult =
  | { kind: "ok"; data: unknown; durationMs: number }
  | { kind: "unauthorized"; status: number; durationMs: number }
  | { kind: "unreachable"; durationMs: number }
  | { kind: "error"; status: number; body: string; durationMs: number };

/** Read-only admin RPCs permitted for the Viewer (C0 contract). */
export const ALLOWED_ADMIN_RPCS = [
  "admin_overview",
  "admin_list_staff",
  "admin_get_staff",
  "admin_list_shops",
  "admin_get_shop",
  "admin_list_activity",
] as const;

export type AllowedAdminRpc = (typeof ALLOWED_ADMIN_RPCS)[number];

/** Call a read-only admin RPC with the Viewer session access token. */
export async function callAdminRpc(
  accessToken: string,
  rpcName: AllowedAdminRpc,
  body: Record<string, unknown> = {},
): Promise<AdminRpcResult> {
  if (!(ALLOWED_ADMIN_RPCS as readonly string[]).includes(rpcName)) {
    return { kind: "error", status: 400, body: "RPC not permitted.", durationMs: 0 };
  }
  const cfg = getAccountServerConfig();
  const t0 = performance.now();
  try {
    const res = await fetch(`${cfg.url}/rest/v1/rpc/${rpcName}`, {
      method: "POST",
      headers: authHeaders(accessToken),
      body: JSON.stringify(body),
      cache: "no-store",
    });
    const durationMs = Math.round(performance.now() - t0);
    if (res.status === 401 || res.status === 403) {
      return { kind: "unauthorized", status: res.status, durationMs };
    }
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return { kind: "error", status: res.status, body: text, durationMs };
    }
    const data: unknown = await res.json();
    return { kind: "ok", data, durationMs };
  } catch {
    return { kind: "unreachable", durationMs: Math.round(performance.now() - t0) };
  }
}

export async function fetchAdminOverview(accessToken: string): Promise<AdminRpcResult> {
  return callAdminRpc(accessToken, "admin_overview", {});
}

export async function fetchAdminListStaff(
  accessToken: string,
  params: {
    search?: string | null;
    role?: string | null;
    status?: string | null;
    shopId?: string | null;
    limit: number;
    offset: number;
  },
): Promise<AdminRpcResult> {
  const body: Record<string, unknown> = {
    p_limit: params.limit,
    p_offset: params.offset,
  };
  if (params.search) body.p_search = params.search;
  if (params.role && params.role !== "all") body.p_role = params.role;
  if (params.status && params.status !== "all") body.p_status = params.status;
  if (params.shopId) body.p_shop_id = params.shopId;
  return callAdminRpc(accessToken, "admin_list_staff", body);
}

export async function fetchAdminGetStaff(
  accessToken: string,
  staffId: string,
): Promise<AdminRpcResult> {
  return callAdminRpc(accessToken, "admin_get_staff", { p_staff_id: staffId });
}

export async function fetchAdminListShops(
  accessToken: string,
  limit = 100,
  offset = 0,
): Promise<AdminRpcResult> {
  return callAdminRpc(accessToken, "admin_list_shops", {
    p_limit: limit,
    p_offset: offset,
  });
}

export async function fetchAdminGetShop(
  accessToken: string,
  shopId: string,
): Promise<AdminRpcResult> {
  return callAdminRpc(accessToken, "admin_get_shop", { p_shop_id: shopId });
}

export async function fetchAdminListActivity(
  accessToken: string,
  params: {
    action?: string | null;
    targetUsername?: string | null;
    from?: string | null;
    to?: string | null;
    limit?: number;
    offset?: number;
  } = {},
): Promise<AdminRpcResult> {
  const body: Record<string, unknown> = {
    p_limit: params.limit ?? 50,
    p_offset: params.offset ?? 0,
  };
  if (params.action) body.p_action = params.action;
  if (params.targetUsername) body.p_target_username = params.targetUsername;
  if (params.from) body.p_from = params.from;
  if (params.to) body.p_to = params.to;
  return callAdminRpc(accessToken, "admin_list_activity", body);
}

export async function fetchAdminListActivityForUsername(
  accessToken: string,
  username: string,
  limit = 8,
): Promise<AdminRpcResult> {
  return fetchAdminListActivity(accessToken, {
    targetUsername: username,
    limit,
    offset: 0,
  });
}

// ---------------------------------------------------------------------------
// C1: Write RPCs (SECURITY DEFINER, user JWT + publishable key)
// ---------------------------------------------------------------------------

/** Write RPCs permitted for the Viewer (C1 contract). */
export const ALLOWED_WRITE_RPCS = [
  "admin_disable_staff",
  "admin_enable_staff",
  "admin_set_role",
  "admin_assign_shop",
  "admin_unassign_shop",
  "admin_add_shop",
  "admin_create_staff_db",
  "admin_terminate_staff_db",
  "admin_record_reset_credential_audit",
] as const;

export type AllowedWriteRpc = (typeof ALLOWED_WRITE_RPCS)[number];

export const ALLOWED_INTERNAL_RPCS = [
  "admin_record_auth_reconciliation",
  "admin_list_auth_reconciliation",
  "admin_update_auth_reconciliation",
  "admin_reconcile_reset_audit",
  "admin_verify_created_identity",
] as const;

export type AllowedInternalRpc = (typeof ALLOWED_INTERNAL_RPCS)[number];

export async function callInternalRpc(
  adminKey: string,
  rpcName: AllowedInternalRpc,
  body: Record<string, unknown> = {},
): Promise<AdminRpcResult> {
  if (!(ALLOWED_INTERNAL_RPCS as readonly string[]).includes(rpcName)) {
    return { kind: "error", status: 400, body: "Internal RPC not permitted.", durationMs: 0 };
  }
  const cfg = getAccountServerConfig();
  const t0 = performance.now();

  try {
    const res = await fetch(`${cfg.url}/rest/v1/rpc/${rpcName}`, {
      method: "POST",
      headers: buildPrivilegedHeaders(adminKey),
      body: JSON.stringify(body),
      cache: "no-store",
    });
    const durationMs = Math.round(performance.now() - t0);
    if (res.status === 401 || res.status === 403) {
      return { kind: "unauthorized", status: res.status, durationMs };
    }
    if (!res.ok) {
      const errBody = await res.text();
      return { kind: "error", status: res.status, body: errBody, durationMs };
    }
    let data;
    const txt = await res.text();
    if (txt) {
      try { data = JSON.parse(txt); } catch { data = txt; }
    }
    return { kind: "ok", data, durationMs };
  } catch {
    return { kind: "unreachable", durationMs: Math.round(performance.now() - t0) };
  }
}

/** Call a C1 write RPC with the Viewer session access token. */
export async function callWriteRpc(
  accessToken: string,
  rpcName: AllowedWriteRpc,
  body: Record<string, unknown> = {},
): Promise<AdminRpcResult> {
  if (!(ALLOWED_WRITE_RPCS as readonly string[]).includes(rpcName)) {
    return { kind: "error", status: 400, body: "Write RPC not permitted.", durationMs: 0 };
  }
  const cfg = getAccountServerConfig();
  const t0 = performance.now();
  try {
    const res = await fetch(`${cfg.url}/rest/v1/rpc/${rpcName}`, {
      method: "POST",
      headers: authHeaders(accessToken),
      body: JSON.stringify(body),
      cache: "no-store",
    });
    const durationMs = Math.round(performance.now() - t0);
    if (res.status === 401 || res.status === 403) {
      return { kind: "unauthorized", status: res.status, durationMs };
    }
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return { kind: "error", status: res.status, body: text, durationMs };
    }
    const data: unknown = await readSuccessfulWriteRpcResponse(res, rpcName);
    return { kind: "ok", data, durationMs };
  } catch {
    return { kind: "unreachable", durationMs: Math.round(performance.now() - t0) };
  }
}

// ---------------------------------------------------------------------------
// C1: Auth Admin API helper (service-role key, server-side only)
// ---------------------------------------------------------------------------

export type AuthAdminResult =
  | { kind: "ok"; data: unknown; durationMs: number }
  | { kind: "error"; status: number; body: string; durationMs: number }
  | { kind: "unreachable"; durationMs: number };

/**
 * Call the Supabase Auth Admin API using the scoped admin key.
 * Used only by the 3 Auth-touching mutation routes:
 *   - /api/admin/create-staff (POST /auth/v1/admin/users)
 *   - /api/admin/reset-credential (PUT /auth/v1/admin/users/:id)
 *   - /api/admin/terminate-staff (DELETE /auth/v1/admin/users/:id)
 */
export async function callAuthAdminApi(
  adminKey: string,
  url: string,
  method: "POST" | "PUT" | "DELETE",
  path: string,
  body?: Record<string, unknown>,
): Promise<AuthAdminResult> {
  // Reject unsafe paths
  if (path.includes("..") || !path.startsWith("/")) {
    return { kind: "error", status: 400, body: "Invalid path.", durationMs: 0 };
  }
  const target = `${url}${path}`;
  const t0 = performance.now();
  try {
    const res = await fetch(target, {
      method,
      headers: buildPrivilegedHeaders(adminKey),
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
    });
    const durationMs = Math.round(performance.now() - t0);
    const text = await res.text().catch(() => "");
    if (!res.ok) {
      return { kind: "error", status: res.status, body: text, durationMs };
    }
    let data: unknown = null;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
    return { kind: "ok", data, durationMs };
  } catch {
    return { kind: "unreachable", durationMs: Math.round(performance.now() - t0) };
  }
}

/**
 * Call the Supabase REST Data API using the scoped admin key.
 * Used only by Auth-touching mutation routes to perform DB writes,
 * as RLS prevents client JWTs from direct table writes.
 */
export async function callDataApiAdmin(
  adminKey: string,
  url: string,
  method: "GET" | "POST" | "PATCH" | "DELETE",
  path: string,
  body?: Record<string, unknown> | Record<string, unknown>[],
  headers?: Record<string, string>,
): Promise<AuthAdminResult> {
  if (path.includes("..") || !path.startsWith("/")) {
    return { kind: "error", status: 400, body: "Invalid path.", durationMs: 0 };
  }
  const target = `${url}${path}`;
  const t0 = performance.now();
  try {
    const res = await fetch(target, {
      method,
      headers: { ...buildPrivilegedHeaders(adminKey), ...headers },
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
    });
    const durationMs = Math.round(performance.now() - t0);
    const text = await res.text().catch(() => "");
    if (!res.ok) {
      return { kind: "error", status: res.status, body: text, durationMs };
    }
    let data: unknown = null;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
    return { kind: "ok", data, durationMs };
  } catch {
    return { kind: "unreachable", durationMs: Math.round(performance.now() - t0) };
  }
}

