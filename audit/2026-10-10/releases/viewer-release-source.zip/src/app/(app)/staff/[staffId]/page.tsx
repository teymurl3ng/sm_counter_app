"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { formatActivityTime } from "@/lib/overview";
import {
  formatStaffDate,
  type StaffDetailApiResponse,
} from "@/lib/staff";
import type { StaffStatus } from "@/lib/staff-status";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek, viewerCacheInvalidate } from "@/lib/viewer-cache";
import { formatCredentialDisplay } from "@/lib/credential";

type LoadState = "loading" | "ready" | "error";

function StatusText({ status }: { status: StaffStatus }) {
  const color =
    status === "Active"
      ? "text-[var(--success)]"
      : status === "Disabled"
        ? "text-[var(--warn)]"
        : "text-[var(--muted)]";
  return <span className={`text-sm font-medium ${color}`}>{status}</span>;
}

export default function StaffDetailPage() {
  return <StaffDetailPanel />;
}

function StaffDetailPanel() {
  const params = useParams<{ staffId: string }>();
  const staffId = params.staffId;
  const router = useRouter();
  const peeked = viewerCachePeek(`staffDetail:${staffId}`) as StaffDetailApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok && peeked.staff ? "ready" : "loading");
  const [data, setData] = useState<StaffDetailApiResponse | null>(peeked);
  const [showId, setShowId] = useState(false);

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    const apply = (status: number, json: StaffDetailApiResponse) => {
      if (!isCurrent()) return;
      if (
        status === 401 ||
        json.error?.code === "UNAUTHENTICATED" ||
        json.error?.code === "UNAUTHORIZED"
      ) {
        router.replace("/login?error=session");
        return;
      }
      setData(json);
      if (json.ok && json.staff) setState("ready");
      else setState("error");
    };
    try {
      const url = `/api/staff/${encodeURIComponent(staffId)}`;
      const result = await viewerCachedGet({
        key: `staffDetail:${staffId}`,
        url,
        ttlMs: VIEWER_TTL.staffDetail,
        onRevalidated: ({ status, body }) =>
          apply(status, body as StaffDetailApiResponse),
      });
      apply(result.status, result.body as StaffDetailApiResponse);
    } catch {
      if (!isCurrent()) return;
      setData({
        ok: false,
        env: "unknown",
        contract: "v1.1.0-read-admin",
        staff: null,
        recent_activity: [],
        error: {
          code: "SERVER_UNAVAILABLE",
          message: "Account Server could not be reached.",
        },
      });
      setState("error");
    }
  }, [router, staffId]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load]);

  const staff = state === "ready" ? data?.staff : null;
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [resetCredential, setResetCredential] = useState<string | null>(null);

  async function handleToggleStatus() {
    if (!staff) return;
    const isDisabling = staff.active;
    const rpc = isDisabling ? "admin_disable_staff" : "admin_enable_staff";
    
    setIsUpdatingStatus(true);
    try {
      const res = await fetch("/api/admin/rpc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rpc, payload: { p_staff_id: staff.staff_id } }),
      });
      const json = await res.json();
      if (!json.ok) {
        alert(`Failed to ${isDisabling ? "disable" : "enable"}: ${json.error?.message || "Unknown error"}`);
      } else {
        viewerCacheInvalidate([`/api/staff/${staff.staff_id}`, `/api/staff`]);
        await load();
      }
    } catch {
      alert("Network error.");
    } finally {
      setIsUpdatingStatus(false);
    }
  }

  async function handleRoleChange(e: React.ChangeEvent<HTMLSelectElement>) {
    if (!staff) return;
    const newRole = e.target.value;
    if (newRole === staff.role) return;

    if (!confirm(`Are you sure you want to change role to ${newRole}?`)) {
      e.target.value = staff.role;
      return;
    }

    setIsUpdatingStatus(true);
    try {
      const res = await fetch("/api/admin/rpc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rpc: "admin_set_role", payload: { p_staff_id: staff.staff_id, p_new_role: newRole } }),
      });
      const json = await res.json();
      if (!json.ok) {
        alert(`Failed to set role: ${json.error?.message || "Unknown error"}`);
        e.target.value = staff.role;
      } else {
        viewerCacheInvalidate([`/api/staff/${staff.staff_id}`, `/api/staff`]);
        await load();
      }
    } catch {
      alert("Network error.");
      e.target.value = staff.role;
    } finally {
      setIsUpdatingStatus(false);
    }
  }

  async function handleAssignShop() {
    if (!staff) return;
    try {
      const res = await fetch("/api/shops?limit=100");
      const json: { ok?: boolean; shops?: { shop_id: string; name: string }[] } = await res.json();
      if (!json.ok || !json.shops) {
        alert("Could not load shops.");
        return;
      }
      const available = json.shops.filter((s) => !staff.shops.some((assigned) => assigned.id === s.shop_id));
      if (available.length === 0) {
        alert("All shops are already assigned to this staff.");
        return;
      }
      
      const msg = available.map((s, i) => `${i + 1}. ${s.name}`).join("\n");
      const choice = window.prompt(`Enter the number of the shop to assign:\n\n${msg}`);
      if (!choice) return;
      
      const idx = parseInt(choice, 10) - 1;
      const selected = available[idx];
      if (!selected) {
        alert("Invalid selection.");
        return;
      }

      setIsUpdatingStatus(true);
      const assignRes = await fetch("/api/admin/rpc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rpc: "admin_assign_shop", payload: { p_staff_id: staff.staff_id, p_shop_id: selected.shop_id } }),
      });
      const assignJson = await assignRes.json();
      if (!assignJson.ok) {
        alert(`Failed to assign shop: ${assignJson.error?.message || "Unknown error"}`);
      } else {
        viewerCacheInvalidate([`/api/staff/${staff.staff_id}`, `/api/shops`]);
        await load();
      }
    } catch {
      alert("Network error.");
    } finally {
      setIsUpdatingStatus(false);
    }
  }

  async function handleUnassignShop(shopId: string, shopName: string) {
    if (!staff) return;
    if (!confirm(`Are you sure you want to unassign ${shopName}?`)) return;
    
    setIsUpdatingStatus(true);
    try {
      const res = await fetch("/api/admin/rpc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rpc: "admin_unassign_shop", payload: { p_staff_id: staff.staff_id, p_shop_id: shopId } }),
      });
      const json = await res.json();
      if (!json.ok) {
        alert(`Failed to unassign shop: ${json.error?.message || "Unknown error"}`);
      } else {
        viewerCacheInvalidate([`/api/staff/${staff.staff_id}`, `/api/shops`]);
        await load();
      }
    } catch {
      alert("Network error.");
    } finally {
      setIsUpdatingStatus(false);
    }
  }

  async function handleResetCredential() {
    if (!staff) return;
    if (!confirm(`Are you sure you want to reset the server credential for ${staff.username}? The old credential will be invalidated immediately.`)) return;
    
    setIsUpdatingStatus(true);
    setResetCredential(null);
    try {
      const res = await fetch("/api/admin/reset-credential", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ staff_id: staff.staff_id }),
      });
      const json = await res.json();
      if (!json.ok) {
        alert(`Failed to reset credential: ${json.error?.message || "Unknown error"}`);
      } else {
        setResetCredential(json.credential);
        viewerCacheInvalidate([`/api/staff/${staff.staff_id}`, `/api/staff`]);
        await load();
      }
    } catch {
      alert("Network error.");
    } finally {
      setIsUpdatingStatus(false);
    }
  }

  async function handleTerminate() {
    if (!staff) return;
    if (!confirm(`DANGER: Are you absolutely sure you want to terminate ${staff.username}? This action is permanent and cannot be undone.`)) return;
    
    // Optional double-confirmation for termination
    const confirmText = window.prompt(`Type "${staff.username}" to confirm termination:`);
    if (confirmText !== staff.username) {
      if (confirmText !== null) alert("Termination cancelled: Username did not match.");
      return;
    }

    setIsUpdatingStatus(true);
    try {
      const res = await fetch("/api/admin/terminate-staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ staff_id: staff.staff_id }),
      });
      const json = await res.json();
      if (!json.ok) {
        alert(`Failed to terminate: ${json.error?.message || "Unknown error"}`);
      } else {
        viewerCacheInvalidate([`/api/staff/${staff.staff_id}`, `/api/staff`]);
        await load();
      }
    } catch {
      alert("Network error.");
    } finally {
      setIsUpdatingStatus(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <Link
          href="/staff"
          className="inline-flex items-center gap-1 text-sm font-medium text-[var(--accent)] transition-colors duration-150 hover:text-[#025a8a]"
        >
          ← Back to Staff
        </Link>
      </div>

      {state === "loading" ? (
        <div className="space-y-4 rounded-xl border border-[var(--line)] bg-[var(--card)] p-5" aria-busy="true" aria-label="Loading staff detail">
          <div className="h-8 w-48 animate-pulse rounded-lg bg-[var(--line)]" />
          <div className="h-4 w-32 animate-pulse rounded bg-[var(--line)]" />
          <div className="h-40 animate-pulse rounded-lg bg-[var(--bg)]" />
        </div>
      ) : null}

      {state === "error" ? (
        <section className="space-y-3 rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4" role="alert">
          <h1 className="text-2xl font-semibold text-[var(--ink)]">Staff</h1>
          <p className="text-sm text-[var(--danger)]">
            {data?.error?.message || "Staff detail is unavailable."}
          </p>
          {data?.error?.code !== "NOT_FOUND" && data?.error?.code !== "INVALID_REQUEST" ? (
            <button
              type="button"
              onClick={() => void load()}
              className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium hover:bg-[var(--bg)]"
            >
              Retry
            </button>
          ) : (
            <Link
              href="/staff"
              className="inline-block text-sm font-medium text-[var(--accent)] underline-offset-2 hover:underline"
            >
              Back to staff list
            </Link>
          )}
        </section>
      ) : null}

      {staff ? (
        <>
          {/* Header card */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">{staff.display_name}</h1>
                <p className="mt-1 text-sm text-[var(--muted)]">{staff.username}</p>
              </div>
              <StatusText status={staff.status} />
            </div>
            {staff.status === "Terminated" ? (
              <p className="mt-3 text-sm text-[var(--muted)]">
                This account is terminated and cannot authenticate.
                {staff.terminated_at
                  ? ` Terminated ${formatStaffDate(staff.terminated_at, true)}.`
                  : ""}
              </p>
            ) : null}
            {staff.status === "Disabled" ? (
              <p className="mt-3 text-sm text-[var(--muted)]">
                This account is disabled and cannot sign in until enabled by an
                administrator.
              </p>
            ) : null}
          </section>

          {/* Identity */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Identity">
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
                Identity
              </h2>
              {!staff.terminated_at ? (
                <button
                  type="button"
                  onClick={handleResetCredential}
                  disabled={isUpdatingStatus}
                  className="rounded border border-[var(--line)] bg-[var(--bg)] px-2 py-1 text-xs font-medium text-[var(--ink)] hover:bg-[var(--line)] disabled:opacity-50"
                >
                  Reset Credential
                </button>
              ) : null}
            </div>
            
            {resetCredential && (
              <div className="mb-6 rounded-xl border border-[var(--success)]/30 bg-[#e6f4ea] p-4 text-center dark:bg-[#1e2e22]">
                <p className="text-sm font-semibold text-[#137333] dark:text-[#81c995]">Credential Reset Successfully</p>
                <p className="mt-1 text-xs text-[var(--ink)]">Please provide this temporary credential to the user.</p>
                <div className="my-3 inline-block rounded-lg border border-[#137333]/30 bg-white p-3 dark:bg-black/20">
                  <p className="font-mono text-xl font-bold tracking-widest text-[var(--ink)]">
                    {formatCredentialDisplay(resetCredential)}
                  </p>
                </div>
                <p className="text-xs font-medium text-[var(--danger)]">
                  Warning: This credential will not be shown again.
                </p>
                <button 
                  onClick={() => setResetCredential(null)}
                  className="mt-3 text-xs font-medium text-[var(--muted)] hover:underline"
                >
                  Dismiss
                </button>
              </div>
            )}

            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Display name</dt>
                <dd className="mt-1 font-medium text-[var(--ink)]">{staff.display_name}</dd>
              </div>
              <div>
                <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Username</dt>
                <dd className="mt-1 font-medium text-[var(--ink)]">{staff.username}</dd>
              </div>
              <div>
                <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Created</dt>
                <dd className="mt-1 font-medium text-[var(--ink)]">{formatStaffDate(staff.created_at, true)}</dd>
              </div>
              {staff.updated_at ? (
                <div>
                  <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Updated</dt>
                  <dd className="mt-1 font-medium text-[var(--ink)]">{formatStaffDate(staff.updated_at, true)}</dd>
                </div>
              ) : null}
            </dl>
            <div className="mt-3 text-xs text-[var(--muted)]">
              <button
                type="button"
                className="font-medium text-[var(--accent)] underline-offset-2 hover:underline"
                onClick={() => setShowId((v) => !v)}
              >
                {showId ? "Hide staff ID" : "Show staff ID"}
              </button>
              {showId ? (
                <p className="mt-1 break-all font-mono">{staff.staff_id}</p>
              ) : null}
            </div>
          </section>

          {/* Access */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Access">
            <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
              Access
            </h2>
            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Role</dt>
                <dd className="mt-1 font-medium text-[var(--ink)]">
                  {!staff.terminated_at ? (
                    <select
                      defaultValue={staff.role}
                      onChange={handleRoleChange}
                      disabled={isUpdatingStatus}
                      className="rounded border border-[var(--line)] bg-[var(--bg)] px-2 py-1 text-sm font-medium text-[var(--ink)] focus:border-[var(--accent)] focus:outline-none focus:ring-1 focus:ring-[var(--accent)] disabled:opacity-50"
                    >
                      <option value="owner">Owner</option>
                      <option value="admin">Admin</option>
                      <option value="manager">Manager</option>
                      <option value="cashier">Cashier</option>
                      <option value="operator">Operator</option>
                    </select>
                  ) : (
                    staff.role_label
                  )}
                </dd>
              </div>
              <div>
                <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Status</dt>
                <dd className="mt-1 flex items-center gap-3">
                  <StatusText status={staff.status} />
                  {!staff.terminated_at ? (
                    <button
                      type="button"
                      onClick={handleToggleStatus}
                      disabled={isUpdatingStatus}
                      className="rounded border border-[var(--line)] bg-[var(--bg)] px-2 py-0.5 text-xs font-medium text-[var(--ink)] hover:bg-[var(--line)] disabled:opacity-50"
                    >
                      {staff.active ? "Disable" : "Enable"}
                    </button>
                  ) : null}
                </dd>
              </div>
              {staff.terminated_at ? (
                <div className="sm:col-span-2">
                  <dt className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Terminated</dt>
                  <dd className="mt-1 font-medium text-[var(--ink)]">
                    {formatStaffDate(staff.terminated_at, true)}
                  </dd>
                </div>
              ) : null}
            </dl>
          </section>

          {/* Shops */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Shops">
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
                Shops
              </h2>
              {staff.role !== "owner" && !staff.terminated_at ? (
                <button
                  type="button"
                  onClick={handleAssignShop}
                  disabled={isUpdatingStatus}
                  className="rounded-lg bg-[var(--ink)] px-3 py-1.5 text-xs font-medium text-[var(--bg)] hover:opacity-90 disabled:opacity-50"
                >
                  + Assign Shop
                </button>
              ) : null}
            </div>
            {staff.role === "owner" ? (
              <p className="text-sm font-medium text-[var(--ink)]">All shops</p>
            ) : staff.shops.length === 0 ? (
              <p className="text-sm text-[var(--muted)]">No shop assigned</p>
            ) : (
              <ul className="space-y-2 text-sm">
                {staff.shops.map((s) => (
                  <li key={s.id} className="flex items-center justify-between gap-3 rounded-lg border border-[var(--line)] p-2">
                    <span className="font-medium text-[var(--ink)]">{s.name}</span>
                    {!staff.terminated_at ? (
                      <button
                        type="button"
                        onClick={() => handleUnassignShop(s.id, s.name)}
                        disabled={isUpdatingStatus}
                        className="text-xs font-medium text-[var(--danger)] hover:underline disabled:opacity-50"
                      >
                        Unassign
                      </button>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Danger Zone */}
          {!staff.terminated_at && (
            <section className="rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4 shadow-sm sm:p-5" aria-label="Danger Zone">
              <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--danger)] uppercase">
                Danger Zone
              </h2>
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-medium text-[var(--danger)]">Terminate Account</p>
                  <p className="mt-1 text-xs text-[var(--muted)]">Permanently revoke all access. This action cannot be undone.</p>
                </div>
                <button
                  type="button"
                  onClick={handleTerminate}
                  disabled={isUpdatingStatus}
                  className="rounded-lg bg-[var(--danger)] px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
                >
                  Terminate
                </button>
              </div>
            </section>
          )}

          {/* Recent activity */}
          {data?.recent_activity && data.recent_activity.length > 0 ? (
            <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Recent account activity">
              <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
                Recent account activity
              </h2>
              <ul className="divide-y divide-[var(--line)]">
                {data.recent_activity.map((ev) => (
                  <li
                    key={String(ev.id)}
                    className="flex flex-col gap-0.5 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4"
                  >
                    <span className="text-sm text-[var(--ink)]">{ev.summary}</span>
                    <time
                      className="shrink-0 text-xs text-[var(--muted)] tabular-nums"
                      dateTime={ev.at}
                    >
                      {formatActivityTime(ev.at)}
                    </time>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          <p className="text-xs text-[var(--muted)]">
            Dates shown in your local timezone.
          </p>
        </>
      ) : null}
    </div>
  );
}
