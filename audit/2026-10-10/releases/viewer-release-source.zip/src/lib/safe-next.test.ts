import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { safeNextPath } from "./safe-next";

describe("safeNextPath", () => {
  it("allows known Viewer destinations", () => {
    assert.equal(safeNextPath("/overview"), "/overview");
    assert.equal(safeNextPath("/staff"), "/staff");
    assert.equal(
      safeNextPath("/staff/11111111-1111-4111-8111-111111111111"),
      "/staff/11111111-1111-4111-8111-111111111111",
    );
    assert.equal(safeNextPath("/shops"), "/shops");
    assert.equal(safeNextPath("/activity?group=accounts"), "/activity?group=accounts");
    assert.equal(safeNextPath("/system"), "/system");
  });

  it("rejects open redirects", () => {
    assert.equal(safeNextPath("//evil.com"), "/overview");
    assert.equal(safeNextPath("/\\evil.com"), "/overview");
    assert.equal(safeNextPath("https://evil.com"), "/overview");
    assert.equal(safeNextPath("/%2F%2Fevil.com"), "/overview");
    assert.equal(safeNextPath("/login"), "/overview");
    assert.equal(safeNextPath(""), "/overview");
    assert.equal(safeNextPath(null), "/overview");
  });
});
