import {
  fetchAdminGetStaff,
  fetchAdminListActivityForUsername,
} from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { safeAccountServerMeta } from "@/lib/safe-meta";
import {
  isUuid,
  mapStaffActivity,
  mapStaffDetail,
  type StaffDetailApiResponse,
} from "@/lib/staff";
import { clearViewerSession, readViewerSession } from "@/lib/session";

export const runtime = "nodejs";

/**
 * P1.1: no blocking ping.
 * Activity still waits on get_staff because admin_list_activity needs username
 * (URL only has staff UUID).
 */

function baseMeta() {
  return safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });
}

type Ctx = { params: Promise<{ staffId: string }> };

export async function GET(_request: Request, context: Ctx) {
  const tTotal = nowMs();
  const meta = baseMeta();
  const { staffId: rawId } = await context.params;
  const staffId = (rawId || "").trim();

  if (!isUuid(staffId)) {
    const body: StaffDetailApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      recent_activity: [],
      error: { code: "INVALID_REQUEST", message: "Invalid staff id." },
    };
    return timedJson(body, 400, { label: "staff.detail", totalMs: elapsedMs(tTotal) });
  }

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);
  if (!session) {
    const body: StaffDetailApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      recent_activity: [],
      error: { code: "UNAUTHENTICATED", message: "Sign in required." },
    };
    return timedJson(body, 401, {
      label: "staff.detail",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const result = await fetchAdminGetStaff(session.accessToken, staffId);

  if (result.kind === "unauthorized") {
    await clearViewerSession();
    const body: StaffDetailApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      recent_activity: [],
      error: {
        code: "UNAUTHORIZED",
        message: "Session is no longer authorized for Staff.",
      },
    };
    return timedJson(body, 401, {
      label: "staff.detail",
      sessionMs,
      rpcMs: result.durationMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  if (result.kind === "unreachable") {
    const body: StaffDetailApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      recent_activity: [],
      error: {
        code: "SERVER_UNAVAILABLE",
        message: "Account Server could not be reached.",
      },
    };
    return timedJson(body, 503, {
      label: "staff.detail",
      sessionMs,
      rpcMs: result.durationMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  if (result.kind === "error") {
    const bodyText = (result.body || "").toLowerCase();
    const looksMissing =
      result.status === 404 ||
      result.status === 400 ||
      result.status === 406 ||
      bodyText.includes("not found") ||
      bodyText.includes("p0002") ||
      bodyText.includes("no rows");
    const body: StaffDetailApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      recent_activity: [],
      error: {
        code: looksMissing ? "NOT_FOUND" : "STAFF_UNAVAILABLE",
        message: looksMissing
          ? "Staff account not found."
          : "Staff detail is unavailable right now.",
      },
    };
    return timedJson(body, looksMissing ? 404 : 502, {
      label: "staff.detail",
      sessionMs,
      rpcMs: result.durationMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const staff = mapStaffDetail(result.data);
  if (!staff) {
    const body: StaffDetailApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      recent_activity: [],
      error: { code: "NOT_FOUND", message: "Staff account not found." },
    };
    return timedJson(body, 404, {
      label: "staff.detail",
      sessionMs,
      rpcMs: result.durationMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  let recent_activity: StaffDetailApiResponse["recent_activity"] = [];
  const activityResult = await fetchAdminListActivityForUsername(
    session.accessToken,
    staff.username,
    8,
  );
  if (activityResult.kind === "ok") {
    const rows = Array.isArray(activityResult.data)
      ? activityResult.data.filter((row) => {
          if (row == null || typeof row !== "object") return false;
          const target = (row as Record<string, unknown>).target_username;
          return (
            typeof target === "string" &&
            target.trim().toLowerCase() === staff.username.toLowerCase()
          );
        })
      : [];
    recent_activity = mapStaffActivity(rows, 8);
  }

  const body: StaffDetailApiResponse = {
    ok: true,
    ...meta,
    staff,
    recent_activity,
    error: null,
  };
  return timedJson(body, 200, {
    label: "staff.detail",
    sessionMs,
    rpcMs: result.durationMs,
    extra: { rpc_activity: activityResult.durationMs },
    totalMs: elapsedMs(tTotal),
  });
}
