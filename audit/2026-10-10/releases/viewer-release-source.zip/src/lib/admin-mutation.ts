import "server-only";

import { readViewerSession, clearViewerSession } from "@/lib/session";
import { fetchMyProfile } from "@/lib/account-server";
import type { SessionProfile } from "@/lib/types";
import { getAccountServerConfig } from "@/lib/config";
import { safeAccountServerMeta, type AccountServerMeta } from "@/lib/safe-meta";
import { NextResponse } from "next/server";
import { timedJson } from "@/lib/perf-response";
import { elapsedMs, nowMs, type PerfMarks } from "@/lib/perf";

/** Stable error codes for C1 mutation responses. */
export type AdminMutationErrorCode =
  | "INVALID_REQUEST"
  | "UNAUTHENTICATED"
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "CONFLICT"
  | "LAST_OWNER"
  | "TERMINATED"
  | "ADMIN_KEY_MISSING"
  | "SERVER_UNAVAILABLE"
  | "RECONCILIATION_REQUIRED"
  | "INTERNAL_ERROR";

export type AdminMutationError = {
  code: AdminMutationErrorCode;
  message: string;
};

export type AdminMutationResponse<T = Record<string, unknown>> = {
  ok: boolean;
  env: string;
  contract: string;
  error: AdminMutationError | null;
} & Partial<T>;

/** Validated mutation context, available after requireMutationContext. */
export type MutationContext = { profile: SessionProfile;
  accessToken: string;
  meta: AccountServerMeta;
  tTotal: number;
  sessionMs: number;
};

function preventMutationCaching(response: NextResponse): NextResponse {
  response.headers.set("Cache-Control", "no-store, max-age=0");
  response.headers.set("Pragma", "no-cache");
  response.headers.set("Expires", "0");
  return response;
}

/**
 * Validate a mutation request: check method, content-type, parse JSON body,
 * and verify session. Returns either a validated context or an error response.
 *
 * Pattern follows the established convention from staff/route.ts:
 * - timedJson for all responses
 * - safeAccountServerMeta for env/contract
 * - clearViewerSession on unauthorized
 */
export async function requireMutationContext(
  request: Request,
): Promise<
  { ok: true; ctx: MutationContext } | { ok: false; response: NextResponse }
> {
  const tTotal = nowMs();
  const meta = safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });

  // Must be POST
  if (request.method !== "POST") {
    return {
      ok: false,
      response: mutationError(meta, "INVALID_REQUEST", "POST required.", 405, {
        label: "admin.mutation",
        totalMs: elapsedMs(tTotal),
      }),
    };
  }

  // Must have JSON content-type
  const ct = request.headers.get("content-type") || "";
  if (!ct.includes("application/json")) {
    return {
      ok: false,
      response: mutationError(meta, "INVALID_REQUEST", "Content-Type must be application/json.", 400, {
        label: "admin.mutation",
        totalMs: elapsedMs(tTotal),
      }),
    };
  }

  // Session check
  const tSession = nowMs();
  const session = await readViewerSession();

  if (!session) {
    return {
      ok: false,
      response: mutationError(meta, "UNAUTHENTICATED", "Sign in required.", 401, {
        label: "admin.mutation",
        sessionMs: elapsedMs(tSession),
        totalMs: elapsedMs(tTotal),
      }),
    };
  }

  // Fresh authorization check
  const profileRes = await fetchMyProfile(session.accessToken);
  const sessionMs = elapsedMs(tSession);

  if (profileRes.unreachable) {
    return {
      ok: false,
      response: mutationError(meta, "SERVER_UNAVAILABLE", "Account Server could not be reached.", 503, {
        label: "admin.mutation",
        sessionMs,
        totalMs: elapsedMs(tTotal),
      }),
    };
  }

  const profile = profileRes.profile;
  if (!profile || profile.terminated_at != null || profile.active !== true) {
    await clearViewerSession();
    return {
      ok: false,
      response: mutationError(
        meta,
        profile?.terminated_at ? "TERMINATED" : "UNAUTHORIZED",
        "Session revoked or unauthorized.",
        401,
        { label: "admin.mutation", sessionMs, totalMs: elapsedMs(tTotal) },
      ),
    };
  }

  if (profile.role !== "owner" && profile.role !== "admin") {
    await clearViewerSession();
    return {
      ok: false,
      response: mutationError(meta, "FORBIDDEN", "This operation requires owner or admin privileges.", 403, {
        label: "admin.mutation",
        sessionMs,
        totalMs: elapsedMs(tTotal),
      }),
    };
  }

  return {
    ok: true,
    ctx: { profile, accessToken: session.accessToken, meta, tTotal, sessionMs },
  };
}

/**
 * Parse and validate JSON body from request.
 * Returns null on parse failure (caller should return 400).
 */
export async function parseMutationBody<T>(request: Request): Promise<T | null> {
  try {
    return (await request.json()) as T;
  } catch {
    return null;
  }
}

/**
 * Build a typed error response following the established timedJson convention.
 */
export function mutationError(
  meta: AccountServerMeta,
  code: AdminMutationErrorCode,
  message: string,
  httpStatus: number,
  marks: PerfMarks,
): NextResponse {
  return preventMutationCaching(timedJson(
    { ok: false, ...meta, error: { code, message } } satisfies AdminMutationResponse,
    httpStatus,
    marks,
  ));
}

/**
 * Build a typed success response following the established timedJson convention.
 */
export function mutationSuccess<T extends Record<string, unknown>>(
  meta: AccountServerMeta,
  data: T,
  marks: PerfMarks,
  httpStatus = 200,
): NextResponse {
  return preventMutationCaching(timedJson(
    { ok: true, ...meta, error: null, ...data },
    httpStatus,
    marks,
  ));
}
