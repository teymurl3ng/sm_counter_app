import { randomInt } from "crypto";

/**
 * Generates a cryptographically secure 15-digit numeric credential.
 * Leading zeros are allowed and preserved.
 */
export function generateServerCredential(): string {
  const p1 = randomInt(0, 100000).toString().padStart(5, "0");
  const p2 = randomInt(0, 100000).toString().padStart(5, "0");
  const p3 = randomInt(0, 100000).toString().padStart(5, "0");
  return p1 + p2 + p3;
}

/**
 * Formats a 15-digit credential for display as XXXXX-XXXXX-XXXXX.
 */
export function formatCredentialDisplay(cred: string): string {
  if (cred.length !== 15) return cred;
  return `${cred.slice(0, 5)}-${cred.slice(5, 10)}-${cred.slice(10, 15)}`;
}
