"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { formatActivityTime } from "@/lib/overview";
import {
  formatStaffDate,
  type ShopDetailApiResponse,
  type ShopStaffSummary,
  type ShopStatus,
} from "@/lib/shops";
import type { StaffStatus } from "@/lib/staff-status";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek } from "@/lib/viewer-cache";

type LoadState = "loading" | "ready" | "error";

function ShopStatusText({ status }: { status: ShopStatus }) {
  return (
    <span
      className={`text-sm font-medium ${
        status === "Active" ? "text-[var(--success)]" : "text-[var(--muted)]"
      }`}
    >
      {status}
    </span>
  );
}

function StaffStatusText({ status }: { status: StaffStatus }) {
  const color =
    status === "Active"
      ? "text-[var(--success)]"
      : status === "Disabled"
        ? "text-[var(--warn)]"
        : "text-[var(--muted)]";
  return <span className={`text-sm font-medium ${color}`}>{status}</span>;
}

function StaffRows({
  people,
  emptyLabel,
}: {
  people: ShopStaffSummary[];
  emptyLabel: string;
}) {
  if (people.length === 0) {
    return <p className="text-sm text-[var(--muted)]">{emptyLabel}</p>;
  }
  return (
    <>
      {/* Desktop */}
      <ul className="hidden divide-y divide-[var(--line)] rounded-xl border border-[var(--line)] md:block">
        {people.map((p) => (
          <li key={p.staff_id}>
            <Link
              href={`/staff/${p.staff_id}`}
              className="grid grid-cols-[1fr_auto_auto] items-baseline gap-3 px-4 py-3 text-sm transition-colors duration-100 hover:bg-[var(--bg)]"
            >
              <span>
                <span className="font-medium text-[var(--ink)]">{p.display_name}</span>
                <span className="mt-0.5 block text-xs text-[var(--muted)]">{p.username}</span>
              </span>
              <span className="text-[var(--ink)]">{p.role_label}</span>
              <StaffStatusText status={p.status} />
            </Link>
          </li>
        ))}
      </ul>
      {/* Mobile */}
      <ul className="space-y-2 md:hidden">
        {people.map((p) => (
          <li key={p.staff_id}>
            <Link
              href={`/staff/${p.staff_id}`}
              className="block rounded-xl border border-[var(--line)] bg-[var(--card)] p-3.5 shadow-sm transition-colors duration-100 hover:border-[var(--accent)]/30"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium text-[var(--ink)]">{p.display_name}</p>
                  <p className="text-sm text-[var(--muted)]">{p.username}</p>
                </div>
                <StaffStatusText status={p.status} />
              </div>
              <p className="mt-1 text-sm text-[var(--muted)]">{p.role_label}</p>
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}

export default function ShopDetailPage() {
  return <ShopDetailPanel />;
}

function ShopDetailPanel() {
  const params = useParams<{ shopId: string }>();
  const shopId = params.shopId;
  const router = useRouter();
  const peeked = viewerCachePeek(`shopDetail:${shopId}`) as ShopDetailApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok && peeked.shop ? "ready" : "loading");
  const [data, setData] = useState<ShopDetailApiResponse | null>(peeked);
  const [showId, setShowId] = useState(false);

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    const apply = (status: number, json: ShopDetailApiResponse) => {
      if (!isCurrent()) return;
      if (
        status === 401 ||
        json.error?.code === "UNAUTHENTICATED" ||
        json.error?.code === "UNAUTHORIZED"
      ) {
        router.replace("/login?error=session");
        return;
      }
      setData(json);
      if (json.ok && json.shop) setState("ready");
      else setState("error");
    };
    try {
      const url = `/api/shops/${encodeURIComponent(shopId)}`;
      const result = await viewerCachedGet({
        key: `shopDetail:${shopId}`,
        url,
        ttlMs: VIEWER_TTL.shopDetail,
        onRevalidated: ({ status, body }) =>
          apply(status, body as ShopDetailApiResponse),
      });
      apply(result.status, result.body as ShopDetailApiResponse);
    } catch {
      if (!isCurrent()) return;
      setData({
        ok: false,
        env: "unknown",
        contract: "v1.1.0-read-admin",
        shop: null,
        recent_activity: [],
        error: {
          code: "SERVER_UNAVAILABLE",
          message: "Account Server could not be reached.",
        },
      });
      setState("error");
    }
  }, [router, shopId]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load]);

  const shop = state === "ready" ? data?.shop : null;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <Link
          href="/shops"
          className="inline-flex items-center gap-1 text-sm font-medium text-[var(--accent)] transition-colors duration-150 hover:text-[#025a8a]"
        >
          ← Back to Shops
        </Link>
      </div>

      {state === "loading" ? (
        <div className="space-y-4 rounded-xl border border-[var(--line)] bg-[var(--card)] p-5" aria-busy="true" aria-label="Loading shop detail">
          <div className="h-8 w-48 animate-pulse rounded-lg bg-[var(--line)]" />
          <div className="h-4 w-32 animate-pulse rounded bg-[var(--line)]" />
          <div className="h-40 animate-pulse rounded-lg bg-[var(--bg)]" />
        </div>
      ) : null}

      {state === "error" ? (
        <section className="space-y-3 rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4" role="alert">
          <h1 className="text-2xl font-semibold text-[var(--ink)]">Shop</h1>
          <p className="text-sm text-[var(--danger)]">
            {data?.error?.message || "Shop detail is unavailable."}
          </p>
          {data?.error?.code !== "NOT_FOUND" && data?.error?.code !== "INVALID_REQUEST" ? (
            <button
              type="button"
              onClick={() => void load()}
              className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium hover:bg-[var(--bg)]"
            >
              Retry
            </button>
          ) : (
            <Link
              href="/shops"
              className="inline-block text-sm font-medium text-[var(--accent)] underline-offset-2 hover:underline"
            >
              Back to shops list
            </Link>
          )}
        </section>
      ) : null}

      {shop ? (
        <>
          {/* Header card */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">{shop.name}</h1>
              <ShopStatusText status={shop.status} />
            </div>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Created {formatStaffDate(shop.created_at, true)}
            </p>
            <div className="mt-2 text-xs text-[var(--muted)]">
              <button
                type="button"
                className="font-medium text-[var(--accent)] underline-offset-2 hover:underline"
                onClick={() => setShowId((v) => !v)}
              >
                {showId ? "Hide shop ID" : "Show shop ID"}
              </button>
              {showId ? (
                <p className="mt-1 break-all font-mono">{shop.shop_id}</p>
              ) : null}
            </div>
          </section>

          {/* Assigned staff */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Assigned staff">
            <h2 className="mb-2 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
              Assigned staff
            </h2>
            <p className="mb-4 text-xs text-[var(--muted)]">
              Explicit shop assignments only. Ordered by username (server order).
            </p>
            <StaffRows
              people={shop.assigned_staff}
              emptyLabel="No staff are assigned to this shop."
            />
          </section>

          {/* Owners */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Owners">
            <h2 className="mb-2 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
              Owners
            </h2>
            <p className="mb-4 text-sm text-[var(--muted)]">
              Owners have access to all shops.
            </p>
            <StaffRows
              people={shop.owners}
              emptyLabel="No active owners returned for this business."
            />
          </section>

          {/* Recent activity */}
          {data?.recent_activity && data.recent_activity.length > 0 ? (
            <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Recent shop activity">
              <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
                Recent shop activity
              </h2>
              <ul className="divide-y divide-[var(--line)]">
                {data.recent_activity.map((ev) => (
                  <li
                    key={String(ev.id)}
                    className="flex flex-col gap-0.5 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4"
                  >
                    <span className="text-sm text-[var(--ink)]">{ev.summary}</span>
                    <time
                      className="shrink-0 text-xs text-[var(--muted)] tabular-nums"
                      dateTime={ev.at}
                    >
                      {formatActivityTime(ev.at)}
                    </time>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          <p className="text-xs text-[var(--muted)]">
            Dates shown in your local timezone. 
          </p>
        </>
      ) : null}
    </div>
  );
}
