"use client";

import { useEffect, useState, useSyncExternalStore } from "react";

const STORAGE_KEY = "smav-theme";

function getInitialTheme(): "light" | "dark" {
  if (typeof window === "undefined") return "light";
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored === "dark" || stored === "light") return stored;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

const subscribeMounted = () => () => {};
const clientMounted = () => true;
const serverMounted = () => false;

export function ThemeToggle({ className }: { className?: string }) {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const mounted = useSyncExternalStore(subscribeMounted, clientMounted, serverMounted);
  const [initialized, setInitialized] = useState(false);
  if (mounted && !initialized) {
    setInitialized(true);
    setTheme(getInitialTheme());
  }

  useEffect(() => {
    if (!mounted) return;
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(STORAGE_KEY, theme);
  }, [theme, mounted]);

  if (!mounted) {
    return <div className={className} style={{ width: 32, height: 32 }} />;
  }

  return (
    <button
      type="button"
      onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
      className={`inline-flex items-center justify-center rounded-lg border border-[var(--line)] bg-[var(--card)] text-[var(--muted)] transition-all duration-200 hover:bg-[var(--bg)] hover:text-[var(--ink)] ${className ?? ""}`}
      style={{ width: 32, height: 32 }}
      aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      title={theme === "dark" ? "Light mode" : "Dark mode"}
    >
      {theme === "dark" ? (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="8" cy="8" r="3.5" />
          <line x1="8" y1="1" x2="8" y2="2.5" />
          <line x1="8" y1="13.5" x2="8" y2="15" />
          <line x1="1" y1="8" x2="2.5" y2="8" />
          <line x1="13.5" y1="8" x2="15" y2="8" />
          <line x1="3.05" y1="3.05" x2="4.1" y2="4.1" />
          <line x1="11.9" y1="11.9" x2="12.95" y2="12.95" />
          <line x1="3.05" y1="12.95" x2="4.1" y2="11.9" />
          <line x1="11.9" y1="4.1" x2="12.95" y2="3.05" />
        </svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M13.5 9.5a5.5 5.5 0 1 1-7-7A4.5 4.5 0 0 0 13.5 9.5z" />
        </svg>
      )}
    </button>
  );
}
