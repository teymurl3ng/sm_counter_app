import "server-only";

import { callAuthAdminApi, callInternalRpc, type AuthAdminResult } from "./account-server";
import { classifyProviderFailure, isUuid, type ProviderFailureCode } from "./admin-security";

export type ReconciliationOperation = "create_cleanup" | "create_verify" | "terminate_cleanup" | "reset_audit";

export type ReconciliationInput = {
  adminKey: string;
  businessId: string;
  operation: ReconciliationOperation;
  authUserId: string;
  targetUsername: string;
  performedBy: string;
  performedByUsername: string;
  errorCode: ProviderFailureCode;
  correlationId: string;
};

export async function deleteAuthWithRetry(
  adminKey: string,
  url: string,
  authUserId: string,
  attempts = 2,
): Promise<{ resolved: boolean; errorCode: ProviderFailureCode }> {
  let last: AuthAdminResult | null = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    last = await callAuthAdminApi(adminKey, url, "DELETE", `/auth/v1/admin/users/${authUserId}`);
    if (last.kind === "ok" || (last.kind === "error" && last.status === 404)) {
      return { resolved: true, errorCode: "NOT_FOUND" };
    }
  }
  if (!last || last.kind === "unreachable") return { resolved: false, errorCode: "UNREACHABLE" };
  return { resolved: false, errorCode: classifyProviderFailure(last.status, last.body) };
}

export async function recordReconciliation(input: ReconciliationInput): Promise<boolean> {
  const result = await callInternalRpc(input.adminKey, "admin_record_auth_reconciliation", {
    p_business_id: input.businessId,
    p_operation: input.operation,
    p_auth_user_id: input.authUserId,
    p_target_username: input.targetUsername,
    p_performed_by: input.performedBy,
    p_performed_by_username: input.performedByUsername,
    p_error_code: input.errorCode,
    p_correlation_id: input.correlationId,
  });
  return result.kind === "ok";
}

export type PendingReconciliation = {
  id: string;
  operation: ReconciliationOperation;
  auth_user_id: string;
};

export function parsePendingReconciliations(data: unknown): PendingReconciliation[] {
  if (!Array.isArray(data)) return [];
  return data.flatMap((value) => {
    if (!value || typeof value !== "object") return [];
    const row = value as Record<string, unknown>;
    if (
      !isUuid(row.id) ||
      !isUuid(row.auth_user_id) ||
      !["create_cleanup", "create_verify", "terminate_cleanup", "reset_audit"].includes(String(row.operation))
    ) {
      return [];
    }
    return [{
      id: row.id,
      operation: row.operation as ReconciliationOperation,
      auth_user_id: row.auth_user_id,
    }];
  });
}

export function logOperationalFailure(
  operation: string,
  correlationId: string,
  code: string,
): void {
  console.error(JSON.stringify({ event: "admin_operation_failed", operation, correlationId, code }));
}
