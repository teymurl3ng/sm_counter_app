import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  KEEP_ALIVE_NOTE,
  KEEP_ALIVE_SUMMARY,
  SYSTEM_MESSAGE,
  SYSTEM_LIMITATIONS,
  VIEWER_ACCESS_TEXT,
  buildSystemStatic,
  formatAccountServerEnvLabel,
  formatViewerDeploymentLabel,
  frozenRoleCatalog,
  mapHealthStatus,
  mapSafeAccount,
  mapShopSummary,
  payloadContainsForbiddenKeys,
  shortCommit,
} from "./system";

describe("System health mapping", () => {
  it("maps online with checked_at", () => {
    const h = mapHealthStatus({
      pingOk: true,
      at: "2026-09-20T12:00:00.000Z",
    });
    assert.equal(h.status, "online");
    assert.equal(h.ping_ok, true);
    assert.equal(h.checked_at, "2026-09-20T12:00:00.000Z");
  });

  it("maps unavailable without stale checked_at", () => {
    const h = mapHealthStatus({
      pingOk: false,
      at: "2026-09-20T12:00:00.000Z",
    });
    assert.equal(h.status, "unavailable");
    assert.equal(h.ping_ok, false);
    assert.equal(h.checked_at, null);
  });

  it("online without at still works", () => {
    const h = mapHealthStatus({ pingOk: true, at: null });
    assert.equal(h.status, "online");
    assert.equal(h.checked_at, null);
  });
});

describe("System environment / contract", () => {
  it("labels Account Server env as DEV", () => {
    assert.equal(formatAccountServerEnvLabel("dev"), "DEV");
    assert.equal(formatAccountServerEnvLabel("DEV"), "DEV");
  });

  it("labels missing/unknown Account Server env as UNKNOWN", () => {
    assert.equal(formatAccountServerEnvLabel(""), "UNKNOWN");
    assert.equal(formatAccountServerEnvLabel("unknown"), "UNKNOWN");
  });

  it("distinguishes Viewer deployment from Account Server env", () => {
    assert.equal(formatViewerDeploymentLabel("production"), "Vercel production URL");
    assert.equal(formatViewerDeploymentLabel("preview"), "Vercel preview");
    assert.equal(formatViewerDeploymentLabel(null), "Local");
    assert.notEqual(formatViewerDeploymentLabel("production"), "PROD");
    assert.notEqual(formatViewerDeploymentLabel("production"), "Production");
  });

  it("static info carries configured contract", () => {
    const s = buildSystemStatic({
      env: "dev",
      contract: "v1.1.0-read-admin",
    });
    assert.equal(s.account_server_env, "dev");
    assert.equal(s.account_server_contract, "v1.1.0-read-admin");
  });
});

describe("System account context", () => {
  it("maps display name, username, and role safely", () => {
    const a = mapSafeAccount({
      display_name: "Viewer C01 Owner",
      username: "viewer_c01_owner",
      role: "owner",
      staff_id: "should-be-ignored-by-mapper-input-shape",
    });
    assert.ok(a);
    assert.equal(a.display_name, "Viewer C01 Owner");
    assert.equal(a.username, "viewer_c01_owner");
    assert.equal(a.role, "owner");
    assert.equal(a.role_label, "Owner");
    assert.equal(
      Object.prototype.hasOwnProperty.call(a, "staff_id"),
      false,
    );
    assert.equal(
      Object.prototype.hasOwnProperty.call(a, "business_id"),
      false,
    );
  });

  it("rejects incomplete profiles", () => {
    assert.equal(mapSafeAccount(null), null);
    assert.equal(mapSafeAccount({ username: "x" }), null);
  });
});

describe("System access model", () => {
  it("states Owner/Admin Viewer access", () => {
    assert.equal(VIEWER_ACCESS_TEXT, "Owner and Admin");
    const s = buildSystemStatic({ env: "dev", contract: "v1.1.0-read-admin" });
    assert.equal(s.viewer_access, "Owner and Admin");
  });

  it("lists frozen role catalog", () => {
    const roles = frozenRoleCatalog();
    assert.deepEqual(
      roles.map((r) => r.label),
      ["Owner", "Admin", "Manager", "Cashier", "Operator"],
    );
  });
});

describe("System keep-alive / limitations", () => {
  it("keep-alive is informational only", () => {
    assert.match(KEEP_ALIVE_SUMMARY, /GitHub Actions/);
    assert.match(KEEP_ALIVE_NOTE, /not displayed/i);
    assert.ok(!KEEP_ALIVE_SUMMARY.toLowerCase().includes("failing"));
    assert.ok(!KEEP_ALIVE_NOTE.toLowerCase().includes("last run"));
  });

  it("read-only and limitations are present", () => {
    assert.match(SYSTEM_MESSAGE, /connected to the Account Server/i);
    assert.ok(SYSTEM_LIMITATIONS.length >= 4);
    assert.ok(SYSTEM_LIMITATIONS.some((l) => /Owner and Admin/i.test(l)));
    assert.ok(SYSTEM_LIMITATIONS.some((l) => /keep-alive/i.test(l)));
  });
});

describe("System shop summary", () => {
  it("maps overview shop counts", () => {
    assert.deepEqual(mapShopSummary({ shops: 2, active_shops: 2 }), {
      shops: 2,
      active_shops: 2,
    });
    assert.equal(mapShopSummary(null), null);
    assert.equal(mapShopSummary({ shops: -1, active_shops: 0 }), null);
  });
});

describe("System security payload checks", () => {
  it("detects forbidden keys", () => {
    assert.equal(
      payloadContainsForbiddenKeys({
        account: { username: "a", role: "owner" },
      }),
      false,
    );
    assert.equal(
      payloadContainsForbiddenKeys({ publishableKey: "sb_publishable_x" }),
      true,
    );
    assert.equal(
      payloadContainsForbiddenKeys({ nested: { accessToken: "eyJ" } }),
      true,
    );
    assert.equal(
      payloadContainsForbiddenKeys({ staff_id: "uuid" }),
      true,
    );
  });

  it("static system response shape has no secrets", () => {
    const s = buildSystemStatic({ env: "dev", contract: "v1.1.0-read-admin" });
    assert.equal(payloadContainsForbiddenKeys(s), false);
  });
});

describe("System viewer meta helpers", () => {
  it("shortens commit SHA", () => {
    assert.equal(shortCommit("abcdef1234567890"), "abcdef1");
    assert.equal(shortCommit("abc"), null);
    assert.equal(shortCommit(null), null);
  });
});

describe("System loading contract", () => {
  it("loading UI must not treat unchecked health as Offline", () => {
    // Documented contract: UI starts in "checking"/loading, not unavailable.
    const loadingLabel = "Checking…";
    const offlineLabel = "Unavailable";
    assert.notEqual(loadingLabel, offlineLabel);
  });
});
