/**
 * Retained operational performance metrics (P1).
 * Durations only — never logs tokens, cookies, or payloads.
 * Server-Timing headers are the primary signal; console lines are omitted.
 */

export type PerfMarks = {
  label: string;
  sessionMs?: number;
  pingMs?: number;
  rpcMs?: number;
  mapMs?: number;
  totalMs?: number;
  extra?: Record<string, number>;
};

export function nowMs(): number {
  return performance.now();
}

export function elapsedMs(start: number): number {
  return Math.round(performance.now() - start);
}

/** No-op: keep call sites; prefer Server-Timing over noisy function logs. */
export function logPerf(_marks: PerfMarks): void {
  void _marks; // intentionally empty
}

/** W3C Server-Timing for browser DevTools / client measurement. */
export function serverTimingHeader(marks: PerfMarks): string {
  const entries: string[] = [];
  if (marks.sessionMs != null) {
    entries.push(`session;dur=${marks.sessionMs}`);
  }
  if (marks.pingMs != null) {
    entries.push(`ping;dur=${marks.pingMs}`);
  }
  if (marks.rpcMs != null) {
    entries.push(`rpc;dur=${marks.rpcMs}`);
  }
  if (marks.mapMs != null) {
    entries.push(`map;dur=${marks.mapMs}`);
  }
  if (marks.extra) {
    for (const [k, v] of Object.entries(marks.extra)) {
      const safe = k.replace(/[^a-zA-Z0-9_-]/g, "_");
      entries.push(`${safe};dur=${v}`);
    }
  }
  if (marks.totalMs != null) {
    entries.push(`total;dur=${marks.totalMs}`);
  }
  return entries.join(", ");
}
