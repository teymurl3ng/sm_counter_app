import { isUuid } from "./admin-security";

/** An HTTP error alone is not proof of rollback; compensate only a known rejection. */
export function createOutcomeIsAmbiguous(result: {
  kind: "ok" | "error" | "unauthorized" | "unreachable";
  status?: number; data?: unknown; body?: unknown;
}): boolean {
  if (result.kind === "ok") return !isUuid(result.data);
  if (result.kind === "unauthorized") return false;
  if (result.kind === "unreachable") return true;
  if (!result.status || result.status >= 500) return true;
  let body = result.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { return true; }
  }
  const code = body && typeof body === "object" ? (body as Record<string, unknown>).code : null;
  return typeof code !== "string" || !/^[0-9A-Z]{5}$/.test(code);
}
