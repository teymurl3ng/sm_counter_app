/** Username / server-credential normalization (Account Server CONTRACT). */

export function normalizeUsername(raw: string): string {
  return raw.trim().toLowerCase();
}

/** Strip every non-digit character; Auth uses 15 plain digits. */
export function normalizeCredential(raw: string): string {
  return raw.replace(/\D/g, "");
}

export function isPlausibleCredential(digits: string): boolean {
  return /^\d{15}$/.test(digits);
}

export function isPlausibleUsername(username: string): boolean {
  return /^[a-z0-9._-]{3,32}$/.test(username);
}
