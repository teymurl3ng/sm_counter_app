# Saaf Milk Admin Viewer — Security Review

**Product:** Saaf Milk Admin Viewer (`sm-server-view`)  
**Contract:** `v1.2.0-write-admin`  
**Release:** C0 frozen at `v1.0.0`  
**Dates:** C0.7 audit 2026-09-20 · C0.8 production boundary 2026-09-20

This document describes Viewer-specific security. It does not replace Account Server security docs.

---

## Architecture

- Next.js App Router UI + Node API routes
- Authenticated Owner/Admin sessions via Account Server Auth + `my_profile`
- All Account Server calls use the **publishable** key server-side only (never `NEXT_PUBLIC_*`)
- Includes read-only and write admin RPCs (C1 enabled)

### Destinations (all real)

Overview · Staff · Shops · Activity · System

---

## Auth / session model

1. Username + 15-digit **server credential** (Auth password grant)
2. `my_profile` must be active `owner` or `admin`
3. Session cookies (`httpOnly`, `SameSite=Lax`, `Secure` in production/Vercel):
   - `smav_access` — access token
   - `smav_profile` — non-secret display profile JSON
   - `smav_refresh` — **not persisted as of C0.7** (unused refresh previously stored; removed until renewal exists)
4. Middleware + server layout enforce role/active before pages render
5. API routes independently require `readViewerSession()`
6. Logout clears cookies and best-effort Auth logout
7. Server credential is never stored after the login request

### Post-login redirect

`safeNextPath()` allowlists Viewer destinations and rejects `//…` / backslash open redirects.

---

## Account Server boundary

### Allowed

| Call | Use |
|---|---|
| Auth password grant / logout | Sign-in / sign-out |
| `ping` | Health |
| `my_profile` | Login gate |
| `admin_overview` | Overview + System shop counts |
| `admin_list_staff` / `admin_get_staff` | Staff |
| `admin_list_shops` / `admin_get_shop` | Shops |
| `admin_list_activity` | Activity (+ compact recent on Staff/Shop detail) |

### Forbidden

- Privileged / service-role / `sb_secret_*` keys
- Direct protected table REST
- Write/admin mutation RPCs (create, disable, enable, set_role, assign/unassign, terminate, reset credential, add_shop, recover)
- Client-side Account Server URL/key exposure

---

## Secrets policy

- Never commit secrets
- Gitleaks (working tree + history) on every push
- Bundle secret scan + `npm audit --audit-level=high`
- Publishable key is intentionally public-class material; still kept server-side in C0

---

## Mutation boundary (C1)

C1 adds deliberate write administration. Its guarantees:

- Every mutation route passes `requireMutationContext`, which re-verifies an active, non-terminated owner/admin **on every request** (no reliance on stale profile state) and clears the session on failure.
- No privileged keys exist in the Viewer or reach the browser; the admin key stays server-side and is used only for the Auth Admin API, never for data reads/writes that DB RPCs already authorize.
- Role enforcement is duplicated at the database layer (`admin_require_write_caller`), so a Viewer bug cannot by itself grant privilege.
- Failing write RPCs raise stable SQLSTATEs (42P01/22023/42501/P0001/…) that `classifyRpcFailure` maps to safe client errors; raw database details never reach clients.
- Audit action *names* from the pre-C1 era (e.g. `disable`) still appear only as translated history.

---

## Security tools (C0.7)

| Tool | Result |
|---|---|
| Gitleaks (tree + history) | Clean |
| Semgrep (TS/JS/React/Next/secrets) | Clean |
| npm audit (high+) | 0 |
| Bundle secret scan | Clean |
| GitHub `security` workflow | Required on main |

CI hardening in C0.7:

- Gitleaks tarball SHA256 verified before install
- Semgrep image pinned to `semgrep/semgrep:1.177.0`

---

## Headers

Deployed responses include:

- Content-Security-Policy (`default-src 'self'`; scripts/styles allow `'unsafe-inline'` for Next.js; production omits `'unsafe-eval'`)
- X-Content-Type-Options: nosniff
- Referrer-Policy: strict-origin-when-cross-origin
- X-Frame-Options: DENY (+ CSP `frame-ancestors 'none'`)
- Permissions-Policy (camera/mic/geo disabled)
- Strict-Transport-Security (production builds)

---

## C0.7 findings

| Severity | Finding | Fix / status |
|---|---|---|
| HIGH | Login `next` open redirect (`//evil`) | **Fixed** — `safeNextPath` allowlist |
| HIGH | Unused 7-day refresh cookie stored | **Fixed** — refresh no longer persisted |
| HIGH | Semgrep CI image floating tag | **Fixed** — pin `1.177.0` |
| MEDIUM | Missing HSTS | **Fixed** — production header |
| MEDIUM | Middleware bad-profile catch left cookies | **Fixed** — cookies cleared |
| MEDIUM | Activity dialog Escape/focus; table keyboard | **Fixed** |
| MEDIUM | Gitleaks binary without checksum | **Fixed** — SHA256 verify |
| MEDIUM | Cookie `Secure` only when `VERCEL=1` | **Fixed** — also production NODE_ENV |
| MEDIUM | Distinct DISABLED / ROLE_DENIED login codes | **Accepted** — UX clarity for denied roles; invalid credentials remain generic; no staff profile → deny |
| LOW | RPC name stringly typed | **Fixed** — allowlist type |
| LOW | Credential input maxLength | **Fixed** — 32 |
| INFO | CSP `'unsafe-inline'` | Accepted for Next.js C0 |
| INFO | Middleware trusts profile cookie presence | Accepted with layout + API JWT RPC re-check; full JWT verify deferred |
| INFO | Auth-before-validation order on some list APIs | Accepted low risk |

No unresolved CRITICAL/HIGH after fixes.

---

## Deployment safety (updated C0.8)

| Hosting channel | Required `ACCOUNT_SERVER_ENV` | Account Server |
|---|---|---|
| Local | `dev` | DEV |
| Vercel Preview | `dev` | DEV |
| Vercel Development | `dev` | DEV |
| Vercel Production | `prod` | PROD |

Fail-closed rules (`config-env.ts`):

- Missing `ACCOUNT_SERVER_ENV` → startup/config error
- Preview/local with `prod` → reject
- Production with `dev` → reject
- Known DEV project URL with `prod` (and reverse) → reject

Vercel Production secrets were switched to the PROD Account Server publishable URL/key in C0.8. Preview and Development remain DEV.

“Vercel production URL” means Viewer hosting. The Account Server environment badge shows **PROD** or **DEV** from `ACCOUNT_SERVER_ENV`.

### GitHub ↔ Vercel

Private repo `teymurl3ng/sm-server-view`. Preferred: Vercel GitHub App authorized for this repo so `main` → Production and PRs → Preview.

If auto-deploy remains unavailable: **CLI `vercel deploy --prod`** is the verified Production release path; document and accept as residual process limitation (do not weaken repo privacy).

---

## C0.8 production verification (summary)

- Production deployment targets PROD Account Server (`ACCOUNT_SERVER_ENV=prod`, known PROD project ref)
- Preview + Development + local require DEV; mismatches fail closed (`config-env.ts`)
- API/UI config failure labels env as `unknown` (never silently claim DEV or PROD)
- Preview deployment verified: login badge DEV; health/`overview` `env=dev`; DEV fixtures present; PROD owner `teimur` absent
- Production authenticated Owner session verified: `my_profile` role=owner active; Overview/Staff/Shops/Activity/System against PROD only (staff=`teimur` only; zero username overlap with DEV)
- Invalid credential login → 401; unauthenticated APIs → 401; unauthenticated pages → redirect
- No privileged keys in Viewer; System payload secret scan clean
- Security scanners re-run at freeze (gitleaks history clean; npm audit high+ 0; bundle scan clean; GitHub `security` workflow green on main)
- C1 write surface limited to the approved RPC allowlist; every mutation route fresh-authorizes (see Mutation boundary)
- GitHub↔Vercel App connect still requires owner UI authorization for private repo; CLI `vercel deploy --prod` is the verified Production release path (used for the 2026-09-25 C1 release, commit `5ebfd52`, deployment `dpl_9t9cYUzE16RyGHa7WiqMpV5zBzPZ`)

### Minimal GitHub App steps (when ready)

1. Vercel Dashboard → Project `sm-server-view` → Settings → Git → Connect
2. Authorize Vercel GitHub App for **only** `teymurl3ng/sm-server-view` (keep repo private)
3. Confirm Production branch = `main`; Preview = other branches/PRs
4. Verify a push to a non-main branch creates a Preview deployment still on DEV Account Server

---

## Tooling notes (C0.7)

- `npm run lint` currently fails due to a flat-config / `eslint-config-next` circular JSON error (tooling). TypeScript production build is clean; still accepted in C0.8 as non-runtime.

---

## Accepted low-risk limitations (C0.8 status)

| Limitation | Status |
|---|---|
| No automatic access-token refresh | Still accepted |
| CSP `'unsafe-inline'` | Still accepted |
| Middleware profile-cookie trust mitigated by API JWT RPCs | Still accepted |
| Distinct DISABLED / ROLE_DENIED login codes | Still accepted |
| ESLint flat-config tooling failure | Still accepted (maintenance) |
| GitHub↔Vercel auto-deploy may remain CLI-based | Documented; prefer App link when available |

---

## Related docs

- `README.md` — setup / freeze
- `C0.7-CHECKLIST.md` — feature freeze
- Account Server `CONTRACT.md` / `SECURITY.md` — server-side identity

