import { NextResponse } from "next/server";
import type { PerfMarks } from "@/lib/perf";
import { logPerf, serverTimingHeader } from "@/lib/perf";

/** Attach Server-Timing + console perf log to a JSON API response. */
export function timedJson<T>(
  body: T,
  status: number,
  marks: PerfMarks,
): NextResponse {
  logPerf(marks);
  const res = NextResponse.json(body, { status });
  res.headers.set("Server-Timing", serverTimingHeader(marks));
  res.headers.set("X-Perf-Audit", "1");
  // Expose region hints when present on the platform
  if (process.env.VERCEL_REGION) {
    res.headers.set("X-Vercel-Region-Hint", process.env.VERCEL_REGION);
  }
  return res;
}
