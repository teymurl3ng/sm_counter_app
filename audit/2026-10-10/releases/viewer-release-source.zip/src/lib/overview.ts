import { translateAuditEvent } from "./activity-translate";

export type OverviewCounts = {
  active_staff: number;
  disabled_staff: number;
  terminated_staff: number;
  active_owners: number;
  active_admins: number;
  shops: number;
  active_shops: number;
};

export type OverviewActivityItem = {
  id: number | string;
  at: string;
  action: string;
  target_username: string | null;
  summary: string;
};

export type MappedOverview = OverviewCounts & {
  recent_activity: OverviewActivityItem[];
};

function asNonNegInt(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value) && value >= 0) {
    return Math.trunc(value);
  }
  if (typeof value === "string" && /^\d+$/.test(value)) {
    return Number.parseInt(value, 10);
  }
  return null;
}

/** Parse + validate `admin_overview` JSON. Returns null if shape is unusable. */
export function mapAdminOverview(raw: unknown): MappedOverview | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;

  const active_staff = asNonNegInt(o.active_staff);
  const disabled_staff = asNonNegInt(o.disabled_staff);
  const terminated_staff = asNonNegInt(o.terminated_staff);
  const active_owners = asNonNegInt(o.active_owners);
  const active_admins = asNonNegInt(o.active_admins);
  const shops = asNonNegInt(o.shops);
  const active_shops = asNonNegInt(o.active_shops);

  if (
    active_staff == null ||
    disabled_staff == null ||
    terminated_staff == null ||
    active_owners == null ||
    active_admins == null ||
    shops == null ||
    active_shops == null
  ) {
    return null;
  }

  const recentRaw = Array.isArray(o.recent_activity) ? o.recent_activity : [];
  const recent_activity: OverviewActivityItem[] = [];

  for (const item of recentRaw) {
    if (item == null || typeof item !== "object") continue;
    const e = item as Record<string, unknown>;
    const action = typeof e.action === "string" ? e.action : "";
    const at = typeof e.at === "string" ? e.at : "";
    if (!action || !at) continue;
    const target =
      typeof e.target_username === "string" && e.target_username.trim()
        ? e.target_username
        : null;
    const detail =
      e.detail != null && typeof e.detail === "object"
        ? (e.detail as Record<string, unknown>)
        : null;
    const id =
      typeof e.id === "number" || typeof e.id === "string" ? e.id : `${at}:${action}`;

    recent_activity.push({
      id,
      at,
      action,
      target_username: target,
      summary: translateAuditEvent({
        action,
        target_username: target,
        detail,
      }),
    });
  }

  return {
    active_staff,
    disabled_staff,
    terminated_staff,
    active_owners,
    active_admins,
    shops,
    active_shops,
    recent_activity,
  };
}

export function formatActivityTime(iso: string, now: Date = new Date()): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const sameDay =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();
  if (sameDay) {
    return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export type OverviewApiErrorCode =
  | "UNAUTHENTICATED"
  | "UNAUTHORIZED"
  | "SERVER_UNAVAILABLE"
  | "OVERVIEW_UNAVAILABLE"
  | "UNKNOWN";

export type OverviewApiResponse = {
  ok: boolean;
  env: string;
  contract: string;
  server: {
    status: "online" | "unavailable";
    pingOk: boolean;
  };
  /** Present only when overview RPC succeeded and mapped cleanly. */
  overview: MappedOverview | null;
  error: null | {
    code: OverviewApiErrorCode;
    message: string;
  };
};
