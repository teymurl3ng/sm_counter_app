export type ViewerRole = "owner" | "admin" | "manager" | "cashier" | "operator";

export type SessionProfile = {
  staff_id: string;
  username: string;
  display_name: string;
  role: ViewerRole;
  active: boolean;
  terminated_at: string | null;
  business_id: string;
};

export type AuthOutcome =
  | { kind: "ALLOWED"; profile: SessionProfile; accessToken: string; refreshToken: string | null; expiresIn: number | null }
  | { kind: "INVALID_CREDENTIALS" }
  | { kind: "DISABLED"; profile: SessionProfile }
  | { kind: "ROLE_DENIED"; profile: SessionProfile }
  | { kind: "NOT_AUTHORIZED" }
  | { kind: "UNKNOWN"; message: string };

export const ALLOWED_VIEWER_ROLES: ReadonlySet<string> = new Set(["owner", "admin"]);
