import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { readSuccessfulWriteRpcResponse } from "./write-rpc-response";

describe("write RPC response contract", () => {
  it("accepts empty 204 acknowledgements for each SQL void mutation", async () => {
    for (const rpc of ["admin_disable_staff", "admin_enable_staff", "admin_set_role", "admin_assign_shop", "admin_unassign_shop", "admin_record_reset_credential_audit"]) {
      assert.equal(await readSuccessfulWriteRpcResponse(new Response(null, { status: 204 }), rpc), null);
    }
  });
  it("does not treat absent identity/shop results as valid acknowledgements", async () => {
    for (const rpc of ["admin_create_staff_db", "admin_terminate_staff_db", "admin_add_shop", "unknown_rpc"]) {
      await assert.rejects(readSuccessfulWriteRpcResponse(new Response(null, { status: 204 }), rpc), SyntaxError);
    }
  });
  it("preserves JSON UUID and structured results", async () => {
    const id = "123e4567-e89b-42d3-a456-426614174000";
    assert.equal(await readSuccessfulWriteRpcResponse(Response.json(id), "admin_create_staff_db"), id);
    assert.deepEqual(await readSuccessfulWriteRpcResponse(Response.json({ shop_id: id }), "admin_add_shop"), { shop_id: id });
  });
  it("accepts the JSON null form of a void success", async () => {
    assert.equal(await readSuccessfulWriteRpcResponse(Response.json(null), "admin_disable_staff"), null);
  });
  it("keeps malformed JSON and unexplained empty 200 responses ambiguous", async () => {
    await assert.rejects(readSuccessfulWriteRpcResponse(new Response("{broken"), "admin_create_staff_db"), SyntaxError);
    await assert.rejects(readSuccessfulWriteRpcResponse(new Response(""), "admin_disable_staff"), SyntaxError);
  });
});
