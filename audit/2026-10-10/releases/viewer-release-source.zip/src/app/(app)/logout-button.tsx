"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { clearViewerCache } from "@/lib/viewer-cache";

export function LogoutButton() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      clearViewerCache();
      router.replace("/login");
      router.refresh();
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      onClick={logout}
      disabled={busy}
      className="w-full rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-sm font-medium text-[var(--muted)] transition-colors duration-150 hover:bg-[var(--bg)] hover:text-[var(--ink)] disabled:opacity-60"
    >
      {busy ? "Signing out…" : "Sign out"}
    </button>
  );
}
