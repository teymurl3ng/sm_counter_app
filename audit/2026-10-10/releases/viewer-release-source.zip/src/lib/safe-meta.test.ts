import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { safeAccountServerMeta } from "./safe-meta";

describe("safeAccountServerMeta", () => {
  it("returns live config when load succeeds", () => {
    const meta = safeAccountServerMeta(() => ({
      env: "prod",
      contract: "v1.1.0-read-admin",
    }));
    assert.equal(meta.env, "prod");
    assert.equal(meta.contract, "v1.1.0-read-admin");
  });

  it("fails closed to unknown when load throws", () => {
    const meta = safeAccountServerMeta(() => {
      throw new Error("Missing required environment variable: ACCOUNT_SERVER_ENV");
    });
    assert.equal(meta.env, "unknown");
  });
});
