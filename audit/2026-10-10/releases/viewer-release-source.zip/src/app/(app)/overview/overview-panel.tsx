"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { formatActivityTime, type OverviewApiResponse } from "@/lib/overview";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek } from "@/lib/viewer-cache";

type LoadState = "loading" | "ready" | "error";

function StatusDot({ online }: { online: boolean }) {
  return (
    <span
      className={`inline-block h-2.5 w-2.5 rounded-full ${
        online ? "bg-[var(--success)]" : "bg-[var(--danger)]"
      }`}
      aria-hidden
    />
  );
}

function CountSkeleton() {
  return (
    <div className="grid grid-cols-3 gap-4 sm:gap-6" aria-hidden>
      {["Active", "Disabled", "Terminated"].map((label) => (
        <div key={label} className="space-y-2">
          <p className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">{label}</p>
          <div className="h-8 w-10 animate-pulse rounded-lg bg-[var(--line)]" />
        </div>
      ))}
    </div>
  );
}

function applyOverviewPayload(
  status: number,
  json: OverviewApiResponse,
  router: ReturnType<typeof useRouter>,
  setData: (d: OverviewApiResponse) => void,
  setState: (s: LoadState) => void,
): boolean {
  if (
    status === 401 ||
    json.error?.code === "UNAUTHENTICATED" ||
    json.error?.code === "UNAUTHORIZED"
  ) {
    router.replace("/login?error=session");
    return false;
  }
  setData(json);
  if (json.ok && json.overview) {
    setState("ready");
  } else {
    setState("error");
  }
  return true;
}

export function OverviewPanel() {
  const router = useRouter();
  const peeked = viewerCachePeek("overview") as OverviewApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok && peeked.overview ? "ready" : "loading");
  const [data, setData] = useState<OverviewApiResponse | null>(peeked);
  const [tick, setTick] = useState(0);

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    try {
      const result = await viewerCachedGet({
        key: "overview",
        url: "/api/overview",
        ttlMs: VIEWER_TTL.overview,
        onRevalidated: ({ status, body }) => {
          applyOverviewPayload(
            status,
            body as OverviewApiResponse,
            router,
            setData,
            setState,
          );
        },
      });
      applyOverviewPayload(
        result.status,
        result.body as OverviewApiResponse,
        router,
        setData,
        setState,
      );
    } catch {
      if (!isCurrent()) return;
      setData({
        ok: false,
        env: "unknown",
        contract: "v1.1.0-read-admin",
        server: { status: "unavailable", pingOk: false },
        overview: null,
        error: {
          code: "SERVER_UNAVAILABLE",
          message: "Account Server could not be reached.",
        },
      });
      setState("error");
    }
  }, [router]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load, tick]);

  const envLabel = (data?.env || "unknown").toUpperCase();
  const serverOnline = data?.server.status === "online";
  const overview = state === "ready" ? data?.overview : null;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Unified header */}
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">Overview</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Account Server status, staff access counts, and recent changes.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
          {envLabel}
        </span>
      </header>

      {/* Server status card */}
      <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <p className="text-sm font-medium text-[var(--ink)]">Account Server</p>
            {state === "loading" ? (
              <span className="text-sm text-[var(--muted)]">Checking…</span>
            ) : (
              <span className="inline-flex items-center gap-2 text-sm">
                <StatusDot online={Boolean(serverOnline)} />
                <span className={serverOnline ? "text-[var(--success)]" : "text-[var(--danger)]"}>
                  {serverOnline ? "Online" : "Unavailable"}
                </span>
              </span>
            )}
          </div>
        </div>
      </section>

      {state === "loading" ? (
        <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-busy="true" aria-label="Loading overview">
          <CountSkeleton />
          <div className="mt-4 space-y-2">
            <div className="h-4 w-40 animate-pulse rounded bg-[var(--line)]" />
            <div className="h-4 w-full animate-pulse rounded bg-[var(--line)]" />
            <div className="h-4 w-4/5 animate-pulse rounded bg-[var(--line)]" />
          </div>
        </section>
      ) : null}

      {state === "error" ? (
        <section className="space-y-3 rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4" role="alert">
          <p className="text-sm text-[var(--danger)]">
            {data?.error?.code === "OVERVIEW_UNAVAILABLE" && serverOnline
              ? "Account Server is reachable, but Overview data is unavailable."
              : data?.error?.message || "Account Server could not be reached."}
          </p>
          <p className="text-sm text-[var(--muted)]">
            Counts are not shown while data cannot be loaded.
          </p>
          <button
            type="button"
            onClick={() => setTick((n) => n + 1)}
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium hover:bg-[var(--bg)]"
          >
            Retry
          </button>
        </section>
      ) : null}

      {overview ? (
        <>
          {/* Staff counts */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Staff access summary">
            <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
              Staff Access
            </h2>
            <div className="grid grid-cols-3 gap-4 sm:gap-6">
              <div>
                <p className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Active</p>
                <p className="mt-1 text-3xl font-semibold tabular-nums text-[var(--success)]">{overview.active_staff}</p>
              </div>
              <div>
                <p className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Disabled</p>
                <p className="mt-1 text-3xl font-semibold tabular-nums text-[var(--warn)]">{overview.disabled_staff}</p>
              </div>
              <div>
                <p className="text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Terminated</p>
                <p className="mt-1 text-3xl font-semibold tabular-nums text-[var(--muted)]">
                  {overview.terminated_staff}
                </p>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 border-t border-[var(--line)] pt-4 text-sm">
              <p className="text-[var(--muted)]">
                Active owners:{" "}
                <span className="font-medium text-[var(--ink)] tabular-nums">
                  {overview.active_owners}
                </span>
              </p>
              {overview.active_admins > 0 ? (
                <p className="text-[var(--muted)]">
                  Active admins:{" "}
                  <span className="font-medium text-[var(--ink)] tabular-nums">
                    {overview.active_admins}
                  </span>
                </p>
              ) : null}
              <p className="text-[var(--muted)]">
                Shops:{" "}
                <span className="font-medium text-[var(--ink)] tabular-nums">{overview.shops}</span>
              </p>
            </div>
          </section>

          {/* Recent activity */}
          <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5" aria-label="Recent activity">
            <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
              Recent Activity
            </h2>
            {overview.recent_activity.length === 0 ? (
              <p className="text-sm text-[var(--muted)]">No account activity yet.</p>
            ) : (
              <ul className="divide-y divide-[var(--line)]">
                {overview.recent_activity.map((ev) => (
                  <li
                    key={String(ev.id)}
                    className="flex flex-col gap-0.5 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4"
                  >
                    <span className="text-sm text-[var(--ink)]">{ev.summary}</span>
                    <time
                      className="shrink-0 text-xs text-[var(--muted)] tabular-nums"
                      dateTime={ev.at}
                    >
                      {formatActivityTime(ev.at)}
                    </time>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      ) : null}
    </div>
  );
}
