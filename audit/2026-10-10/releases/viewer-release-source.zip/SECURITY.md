# Security notes — Saaf Milk Admin Viewer

Short operational notes. Full C0.7 audit: **`SECURITY-REVIEW.md`**.

## Session

- Login runs only on the server (`POST /api/auth/login`).
- Publishable key stays server-side (not `NEXT_PUBLIC_*`).
- Cookies: `smav_access`, `smav_profile` — `httpOnly`, `SameSite=Lax`, `Secure` in production.
- Refresh tokens are not persisted (C0.7).
- Server credential is used once for the Auth password grant and discarded.
- Middleware + server layouts enforce owner/admin access on protected routes.
- Post-login `next` is allowlisted via `safeNextPath`.

## Headers

`next.config.ts` sets CSP, `X-Content-Type-Options`, `Referrer-Policy`, `X-Frame-Options`, `Permissions-Policy`, and HSTS (production).

## Environment

C0 refuses privileged key material in env. `ACCOUNT_SERVER_ENV` must be `dev` (local/Preview) or `prod` (Vercel Production); missing or mismatched values fail closed.
