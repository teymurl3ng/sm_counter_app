import type { ViewerRole } from "./types";

export type StaffStatus = "Active" | "Disabled" | "Terminated";

/** Contract status priority: terminated → disabled → active. */
export function deriveStaffStatus(input: {
  active: boolean;
  terminated_at: string | null;
}): StaffStatus {
  if (input.terminated_at != null && String(input.terminated_at).trim() !== "") {
    return "Terminated";
  }
  if (!input.active) return "Disabled";
  return "Active";
}

export type StaffStatusFilter = "all" | "active" | "disabled" | "terminated";

export const STAFF_ROLES = [
  "owner",
  "admin",
  "manager",
  "cashier",
  "operator",
] as const;

export type StaffRoleFilter = (typeof STAFF_ROLES)[number];

export function formatStaffRole(role: string): string {
  const key = role.trim().toLowerCase();
  const map: Record<string, string> = {
    owner: "Owner",
    admin: "Admin",
    manager: "Manager",
    cashier: "Cashier",
    operator: "Operator",
  };
  return map[key] ?? (role ? role.charAt(0).toUpperCase() + role.slice(1).toLowerCase() : "Unknown");
}

export function isStaffRoleFilter(value: string): value is StaffRoleFilter {
  return (STAFF_ROLES as readonly string[]).includes(value.trim().toLowerCase());
}

export function isStaffStatusFilter(value: string): value is StaffStatusFilter {
  return ["all", "active", "disabled", "terminated"].includes(value.trim().toLowerCase());
}

export function isViewerRole(role: string): role is ViewerRole {
  return isStaffRoleFilter(role);
}
