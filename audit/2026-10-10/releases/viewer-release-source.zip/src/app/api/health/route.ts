import { NextResponse } from "next/server";
import { fetchMyProfile, pingAccountServer } from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { readViewerSession } from "@/lib/session";

export const runtime = "nodejs";

/** Connectivity proof: ping + my_profile in parallel (P1.1). */
export async function GET() {
  const session = await readViewerSession();
  if (!session) {
    return NextResponse.json({ ok: false, code: "UNAUTHENTICATED" }, { status: 401 });
  }

  const cfg = getAccountServerConfig();
  const [ping, profile] = await Promise.all([
    pingAccountServer(),
    fetchMyProfile(session.accessToken),
  ]);

  return NextResponse.json({
    ok: ping.ok && profile.profile != null && profile.profile.active === true,
    env: cfg.env,
    contract: cfg.contract,
    ping: ping.ok ? { ok: true, at: ping.at } : { ok: false },
    my_profile: profile.profile
      ? {
          username: profile.profile.username,
          display_name: profile.profile.display_name,
          role: profile.profile.role,
          active: profile.profile.active,
        }
      : null,
  });
}
