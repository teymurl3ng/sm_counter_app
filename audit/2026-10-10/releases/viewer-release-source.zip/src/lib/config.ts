import "server-only";

import {
  resolveAccountServerEnv,
  type AccountServerEnv,
} from "./config-env";

export type { AccountServerEnv } from "./config-env";
export {
  KNOWN_DEV_PROJECT_REF,
  KNOWN_PROD_PROJECT_REF,
  resolveAccountServerEnv,
  resolveHostingChannel,
  type HostingChannel,
} from "./config-env";

export type AccountServerConfig = {
  url: string;
  publishableKey: string;
  env: AccountServerEnv;
  contract: string;
  fakeDomain: string;
};

/**
 * Admin key config for C1 Auth-touching mutation routes only.
 * Never loaded at startup or by read-only routes.
 */
export type AdminKeyConfig = {
  url: string;
  adminKey: string;
  env: AccountServerEnv;
  fakeDomain: string;
};

function required(name: string): string {
  const v = process.env[name]?.trim();
  if (!v) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return v;
}

/**
 * Block privileged key material in env — except ACCOUNT_SERVER_ADMIN_KEY
 * which is intentionally loaded on-demand by specific admin mutation routes.
 */
function refusePrivilegedEnv(): void {
  const ALLOWED_ADMIN_KEY = "ACCOUNT_SERVER_ADMIN_KEY";
  for (const key of Object.keys(process.env)) {
    const upper = key.toUpperCase();
    if (upper === ALLOWED_ADMIN_KEY) continue;
    if (
      upper.includes("SERVICE_ROLE") ||
      upper === "SUPABASE_SECRET_KEY" ||
      upper === "ACCOUNT_SERVER_SECRET_KEY" ||
      (upper.includes("SECRET") && upper.includes("SUPABASE") && process.env[key])
    ) {
      const val = process.env[key] || "";
      if (val.includes("sb_secret_") || upper.includes("SERVICE_ROLE")) {
        throw new Error(`Refusing to start: privileged key material detected in ${key}`);
      }
    }
  }
}

/**
 * Load Account Server client config.
 * Local + Vercel Preview/Development → DEV only.
 * Vercel Production → PROD only.
 * Fail closed on missing/mismatched ACCOUNT_SERVER_ENV.
 */
export function getAccountServerConfig(): AccountServerConfig {
  refusePrivilegedEnv();

  const url = required("ACCOUNT_SERVER_URL").replace(/\/$/, "");
  const publishableKey = required("ACCOUNT_SERVER_PUBLISHABLE_KEY");
  const accountServerEnv = process.env.ACCOUNT_SERVER_ENV;

  if (publishableKey.includes("sb_secret_") || publishableKey.startsWith("eyJ")) {
    throw new Error("Refusing privileged/admin/JWT material in ACCOUNT_SERVER_PUBLISHABLE_KEY.");
  }
  if (!publishableKey.startsWith("sb_publishable_")) {
    throw new Error("ACCOUNT_SERVER_PUBLISHABLE_KEY must be a publishable/client key.");
  }
  if (!url.toLowerCase().startsWith("https://")) {
    throw new Error("ACCOUNT_SERVER_URL must be https://");
  }

  const resolved = resolveAccountServerEnv({
    accountServerEnv,
    vercelEnv: process.env.VERCEL_ENV,
    url,
  });
  if (!resolved.ok) {
    throw new Error(resolved.message);
  }

  return {
    url,
    publishableKey,
    env: resolved.env,
    contract: process.env.ACCOUNT_SERVER_CONTRACT?.trim() || "v1.1.0-read-admin",
    fakeDomain: process.env.FAKE_DOMAIN?.trim() || "saafmilk.local",
  };
}

/**
 * Load admin key config for C1 Auth-touching mutation routes.
 * Called on-demand by /api/admin/create-staff, /api/admin/reset-credential,
 * and /api/admin/terminate-staff — NOT at startup.
 *
 * Returns null if ACCOUNT_SERVER_ADMIN_KEY is not set (feature disabled).
 * Throws on validation failure (key format, URL mismatch).
 */
export function getAdminKeyConfig(): AdminKeyConfig | null {
  const adminKey = process.env.ACCOUNT_SERVER_ADMIN_KEY?.trim();
  if (!adminKey) return null;

  // Admin key must look like a Supabase secret key or service-role JWT
  const legacyJwt = /^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(adminKey);
  const opaqueSecret = /^sb_secret_[A-Za-z0-9_-]+$/.test(adminKey);
  if (!legacyJwt && !opaqueSecret) {
    throw new Error(
      "ACCOUNT_SERVER_ADMIN_KEY must be a Supabase service-role JWT or secret key.",
    );
  }

  const url = required("ACCOUNT_SERVER_URL").replace(/\/$/, "");
  if (!url.toLowerCase().startsWith("https://")) {
    throw new Error("ACCOUNT_SERVER_URL must be https://");
  }

  const resolved = resolveAccountServerEnv({
    accountServerEnv: process.env.ACCOUNT_SERVER_ENV,
    vercelEnv: process.env.VERCEL_ENV,
    url,
  });
  if (!resolved.ok) {
    throw new Error(resolved.message);
  }

  return {
    url,
    adminKey,
    env: resolved.env,
    fakeDomain: process.env.FAKE_DOMAIN?.trim() || "saafmilk.local",
  };
}

