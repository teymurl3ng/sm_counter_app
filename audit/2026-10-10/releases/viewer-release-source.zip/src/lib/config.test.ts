import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  KNOWN_DEV_PROJECT_REF,
  KNOWN_PROD_PROJECT_REF,
  resolveAccountServerEnv,
  resolveHostingChannel,
} from "./config-env";

describe("resolveHostingChannel", () => {
  it("maps Vercel channels", () => {
    assert.equal(resolveHostingChannel("production"), "production");
    assert.equal(resolveHostingChannel("preview"), "preview");
    assert.equal(resolveHostingChannel("development"), "development");
    assert.equal(resolveHostingChannel(undefined), "local");
  });
});

describe("resolveAccountServerEnv", () => {
  const devUrl = `https://${KNOWN_DEV_PROJECT_REF}.supabase.co`;
  const prodUrl = `https://${KNOWN_PROD_PROJECT_REF}.supabase.co`;

  it("requires ACCOUNT_SERVER_ENV", () => {
    const r = resolveAccountServerEnv({
      accountServerEnv: "",
      vercelEnv: undefined,
      url: devUrl,
    });
    assert.equal(r.ok, false);
  });

  it("local/preview/development require DEV", () => {
    for (const vercelEnv of [undefined, "preview", "development"] as const) {
      const ok = resolveAccountServerEnv({
        accountServerEnv: "dev",
        vercelEnv,
        url: devUrl,
      });
      assert.equal(ok.ok, true);
      if (ok.ok) assert.equal(ok.env, "dev");

      const bad = resolveAccountServerEnv({
        accountServerEnv: "prod",
        vercelEnv,
        url: prodUrl,
      });
      assert.equal(bad.ok, false);
    }
  });

  it("Vercel production requires PROD", () => {
    const ok = resolveAccountServerEnv({
      accountServerEnv: "prod",
      vercelEnv: "production",
      url: prodUrl,
    });
    assert.equal(ok.ok, true);
    if (ok.ok) assert.equal(ok.env, "prod");

    const bad = resolveAccountServerEnv({
      accountServerEnv: "dev",
      vercelEnv: "production",
      url: devUrl,
    });
    assert.equal(bad.ok, false);
  });

  it("rejects env/url project mismatches", () => {
    assert.equal(
      resolveAccountServerEnv({
        accountServerEnv: "dev",
        vercelEnv: "preview",
        url: prodUrl,
      }).ok,
      false,
    );
    assert.equal(
      resolveAccountServerEnv({
        accountServerEnv: "prod",
        vercelEnv: "production",
        url: devUrl,
      }).ok,
      false,
    );
  });

  it("rejects unknown env labels", () => {
    assert.equal(
      resolveAccountServerEnv({
        accountServerEnv: "staging",
        vercelEnv: "preview",
        url: devUrl,
      }).ok,
      false,
    );
  });
});
