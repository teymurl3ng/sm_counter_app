import { translateAuditEvent } from "./activity-translate";
import { formatStaffDate, isUuid } from "./staff";
import {
  deriveStaffStatus,
  formatStaffRole,
  type StaffStatus,
} from "./staff-status";

export type ShopStatus = "Active" | "Inactive";

export function deriveShopStatus(active: boolean): ShopStatus {
  return active ? "Active" : "Inactive";
}

export type ShopListItem = {
  shop_id: string;
  name: string;
  active: boolean;
  status: ShopStatus;
  created_at: string;
  assigned_staff_count: number;
};

export type ShopStaffSummary = {
  staff_id: string;
  username: string;
  display_name: string;
  role: string;
  role_label: string;
  status: StaffStatus;
  active: boolean;
  terminated_at: string | null;
};

export type ShopDetail = ShopListItem & {
  assigned_staff: ShopStaffSummary[];
  owners: ShopStaffSummary[];
};

export type ShopActivityItem = {
  id: number | string;
  at: string;
  action: string;
  summary: string;
};

export const SHOP_PAGE_SIZE_DEFAULT = 50;
export const SHOP_PAGE_SIZE_MAX = 100;

export type ShopApiErrorCode =
  | "UNAUTHENTICATED"
  | "UNAUTHORIZED"
  | "SERVER_UNAVAILABLE"
  | "SHOPS_UNAVAILABLE"
  | "NOT_FOUND"
  | "INVALID_REQUEST"
  | "UNKNOWN";

export type ShopListApiResponse = {
  ok: boolean;
  env: string;
  contract: string;
  shops: ShopListItem[] | null;
  page: { limit: number; offset: number; hasMore: boolean; count: number };
  error: null | { code: ShopApiErrorCode; message: string };
};

export type ShopDetailApiResponse = {
  ok: boolean;
  env: string;
  contract: string;
  shop: ShopDetail | null;
  recent_activity: ShopActivityItem[];
  error: null | { code: ShopApiErrorCode; message: string };
};

function asString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const t = value.trim();
  return t.length ? t : null;
}

function asBool(value: unknown): boolean | null {
  if (typeof value === "boolean") return value;
  return null;
}

function asNonNegInt(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value) && value >= 0) {
    return Math.trunc(value);
  }
  if (typeof value === "string" && /^\d+$/.test(value)) {
    return Number.parseInt(value, 10);
  }
  return null;
}

function mapStaffSummary(raw: unknown): ShopStaffSummary | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const staff_id = asString(o.staff_id);
  const username = asString(o.username);
  const role = asString(o.role);
  const active = asBool(o.active);
  if (!staff_id || !username || !role || active == null) return null;
  const terminated_at = asString(o.terminated_at);
  const display_name = asString(o.display_name) ?? username;
  return {
    staff_id,
    username,
    display_name,
    role: role.toLowerCase(),
    role_label: formatStaffRole(role),
    status: deriveStaffStatus({ active, terminated_at }),
    active,
    terminated_at,
  };
}

export function mapShopListItem(raw: unknown): ShopListItem | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const shop_id = asString(o.shop_id) ?? asString(o.id);
  const name = asString(o.name);
  const active = asBool(o.active);
  const created_at = asString(o.created_at);
  const assigned_staff_count = asNonNegInt(o.assigned_staff_count);
  if (!shop_id || !name || active == null || !created_at || assigned_staff_count == null) {
    return null;
  }
  if (!isUuid(shop_id)) return null;
  return {
    shop_id,
    name,
    active,
    status: deriveShopStatus(active),
    created_at,
    assigned_staff_count,
  };
}

export function mapShopList(raw: unknown): ShopListItem[] | null {
  if (!Array.isArray(raw)) return null;
  const out: ShopListItem[] = [];
  for (const row of raw) {
    const item = mapShopListItem(row);
    if (!item) return null;
    out.push(item);
  }
  return out;
}

export function mapShopDetail(raw: unknown): ShopDetail | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const base = mapShopListItem({
    shop_id: o.shop_id,
    name: o.name,
    active: o.active,
    created_at: o.created_at,
    // Detail may omit count — derive from assigned_staff length for non-terminated later if needed.
    assigned_staff_count:
      o.assigned_staff_count ??
      (Array.isArray(o.assigned_staff)
        ? (o.assigned_staff as unknown[]).filter((s) => {
            const m = mapStaffSummary(s);
            return m && m.status !== "Terminated";
          }).length
        : 0),
  });
  if (!base) return null;

  const assignedRaw = Array.isArray(o.assigned_staff) ? o.assigned_staff : null;
  const ownersRaw = Array.isArray(o.owners) ? o.owners : null;
  if (assignedRaw == null || ownersRaw == null) return null;

  const assigned_staff: ShopStaffSummary[] = [];
  for (const row of assignedRaw) {
    const m = mapStaffSummary(row);
    if (!m) return null;
    assigned_staff.push(m);
  }

  const owners: ShopStaffSummary[] = [];
  const ownerIds = new Set<string>();
  for (const row of ownersRaw) {
    const m = mapStaffSummary(row);
    if (!m) return null;
    owners.push(m);
    ownerIds.add(m.staff_id);
  }

  // Prefer owners section for owner role; keep assigned list free of owners to avoid double meaning.
  const assignedWithoutOwners = assigned_staff.filter((s) => !ownerIds.has(s.staff_id));

  return {
    ...base,
    assigned_staff_count:
      asNonNegInt(o.assigned_staff_count) ??
      assignedWithoutOwners.filter((s) => s.status !== "Terminated").length,
    assigned_staff: assignedWithoutOwners,
    owners,
  };
}

const SHOP_ACTIVITY_ACTIONS = new Set(["add_shop", "assign_shop", "unassign_shop"]);

/**
 * Keep only audit rows that structurally reference this shop_id
 * (detail.shop_id). No fuzzy name matching.
 */
export function mapShopActivity(
  raw: unknown,
  shopId: string,
  limit = 8,
): ShopActivityItem[] {
  if (!Array.isArray(raw)) return [];
  const out: ShopActivityItem[] = [];
  for (const item of raw) {
    if (out.length >= limit) break;
    if (item == null || typeof item !== "object") continue;
    const e = item as Record<string, unknown>;
    const action = asString(e.action);
    const at = asString(e.at);
    if (!action || !at || !SHOP_ACTIVITY_ACTIONS.has(action)) continue;
    const detail =
      e.detail != null && typeof e.detail === "object"
        ? (e.detail as Record<string, unknown>)
        : null;
    const detailShopId = detail ? asString(detail.shop_id) : null;
    if (!detailShopId || detailShopId.toLowerCase() !== shopId.toLowerCase()) continue;
    const target = asString(e.target_username);
    const id =
      typeof e.id === "number" || typeof e.id === "string" ? e.id : `${at}:${action}`;
    out.push({
      id,
      at,
      action,
      summary: translateAuditEvent({
        action,
        target_username: target,
        detail,
      }),
    });
  }
  return out;
}

export { formatStaffDate, isUuid };
