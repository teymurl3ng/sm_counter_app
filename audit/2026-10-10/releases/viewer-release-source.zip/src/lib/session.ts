import "server-only";

import { cookies } from "next/headers";
import type { SessionProfile } from "./types";

const ACCESS = "smav_access";
const REFRESH = "smav_refresh";
const PROFILE = "smav_profile";

const cookieBase = {
  httpOnly: true,
  sameSite: "lax" as const,
  path: "/",
  // Secure on Vercel / NODE_ENV=production / explicit override.
  // Local `next start` over http: set COOKIE_SECURE=false if needed.
  secure:
    process.env.COOKIE_SECURE === "true" ||
    (process.env.COOKIE_SECURE !== "false" &&
      (process.env.VERCEL === "1" || process.env.NODE_ENV === "production")),
};

export type ViewerSession = {
  accessToken: string;
  refreshToken: string | null;
  profile: SessionProfile;
};

export async function setViewerSession(input: {
  accessToken: string;
  refreshToken: string | null;
  profile: SessionProfile;
  expiresIn: number | null;
}): Promise<void> {
  const jar = await cookies();
  const maxAge = Math.max(60, Math.min(input.expiresIn ?? 3600, 60 * 60 * 12));

  jar.set(ACCESS, input.accessToken, { ...cookieBase, maxAge });
  // C0.7: do not persist unused Auth refresh tokens. Access cookie alone
  // gates the session until expiry; refresh will return in a later phase
  // if automatic renewal is implemented.
  void input.refreshToken;
  jar.delete(REFRESH);
  jar.set(PROFILE, JSON.stringify(input.profile), { ...cookieBase, maxAge });
}

export async function clearViewerSession(): Promise<void> {
  const jar = await cookies();
  jar.delete(ACCESS);
  jar.delete(REFRESH);
  jar.delete(PROFILE);
}

export async function readViewerSession(): Promise<ViewerSession | null> {
  const jar = await cookies();
  const accessToken = jar.get(ACCESS)?.value;
  const profileRaw = jar.get(PROFILE)?.value;
  if (!accessToken || !profileRaw) return null;
  try {
    const profile = JSON.parse(profileRaw) as SessionProfile;
    if (!profile.username || !profile.role) return null;
    return {
      accessToken,
      refreshToken: jar.get(REFRESH)?.value ?? null,
      profile,
    };
  } catch {
    return null;
  }
}

/** Lightweight presence check for middleware (Edge-safe: cookie names only). */
export function sessionCookieNames() {
  return { ACCESS, REFRESH, PROFILE };
}
