import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { translateAuditEvent } from "./activity-translate";
import { formatActivityTime, mapAdminOverview } from "./overview";

describe("mapAdminOverview", () => {
  it("maps counts and recent events from admin_overview", () => {
    const mapped = mapAdminOverview({
      active_staff: 4,
      disabled_staff: 1,
      terminated_staff: 2,
      active_owners: 1,
      active_admins: 1,
      shops: 1,
      active_shops: 1,
      recent_activity: [
        {
          id: 10,
          at: "2026-09-20T12:42:00Z",
          action: "set_role",
          target_username: "ali",
          detail: { from: "cashier", to: "admin" },
        },
        {
          id: 9,
          at: "2026-09-20T11:18:00Z",
          action: "disable",
          target_username: "usman",
          detail: {},
        },
      ],
    });
    assert.ok(mapped);
    assert.equal(mapped.active_staff, 4);
    assert.equal(mapped.disabled_staff, 1);
    assert.equal(mapped.terminated_staff, 2);
    assert.equal(mapped.active_owners, 1);
    assert.equal(mapped.active_admins, 1);
    assert.equal(mapped.shops, 1);
    assert.equal(mapped.recent_activity.length, 2);
    assert.equal(
      mapped.recent_activity[0].summary,
      "Role changed for ali: Cashier → Admin",
    );
    assert.equal(mapped.recent_activity[1].summary, "usman disabled");
  });

  it("treats empty recent_activity as valid empty list", () => {
    const mapped = mapAdminOverview({
      active_staff: 1,
      disabled_staff: 0,
      terminated_staff: 0,
      active_owners: 1,
      active_admins: 0,
      shops: 1,
      active_shops: 1,
      recent_activity: [],
    });
    assert.ok(mapped);
    assert.equal(mapped.disabled_staff, 0);
    assert.equal(mapped.recent_activity.length, 0);
  });

  it("rejects incomplete payloads instead of inventing zeroes", () => {
    assert.equal(mapAdminOverview(null), null);
    assert.equal(mapAdminOverview({ active_staff: 1 }), null);
    assert.equal(
      mapAdminOverview({
        active_staff: 1,
        disabled_staff: 0,
        terminated_staff: 0,
        active_owners: 1,
        active_admins: 0,
        shops: 1,
        // missing active_shops
        recent_activity: [],
      }),
      null,
    );
  });
});

describe("translateAuditEvent", () => {
  it("translates known actions", () => {
    assert.equal(
      translateAuditEvent({
        action: "create",
        target_username: "ahmed",
        detail: { display_name: "Ahmed" },
      }),
      "Account created: Ahmed",
    );
    assert.equal(
      translateAuditEvent({ action: "disable", target_username: "usman" }),
      "usman disabled",
    );
    assert.equal(
      translateAuditEvent({ action: "enable", target_username: "usman" }),
      "usman enabled",
    );
    assert.equal(
      translateAuditEvent({ action: "set_role", target_username: "ali" }),
      "Role changed for ali",
    );
    assert.equal(
      translateAuditEvent({
        action: "set_role",
        target_username: "ali",
        detail: { from: "cashier", to: "manager" },
      }),
      "Role changed for ali: Cashier → Manager",
    );
    assert.equal(
      translateAuditEvent({
        action: "assign_shop",
        target_username: "ahmed",
        detail: { shop: "Shop 2" },
      }),
      "Shop 2 assigned to ahmed",
    );
    assert.equal(
      translateAuditEvent({
        action: "unassign_shop",
        target_username: "ahmed",
        detail: { shop: "Shop 2" },
      }),
      "ahmed removed from Shop 2",
    );
    assert.equal(
      translateAuditEvent({ action: "terminate", target_username: "x" }),
      "x terminated",
    );
    assert.equal(
      translateAuditEvent({
        action: "reset_server_credential",
        target_username: "ali",
      }),
      "Server credential reset for ali",
    );
    assert.equal(
      translateAuditEvent({ action: "add_shop", detail: { name: "North" } }),
      "Shop added: North",
    );
    assert.equal(
      translateAuditEvent({ action: "recover_identity", detail: { staff_restored: 3 } }),
      "Identity recovery performed",
    );
  });

  it("falls back safely for unknown actions and missing fields", () => {
    assert.equal(
      translateAuditEvent({ action: "mystery_thing" }),
      "Mystery thing",
    );
    assert.equal(translateAuditEvent({}), "Account activity recorded");
    assert.equal(
      translateAuditEvent({ action: "disable" }),
      "Account disabled",
    );
    assert.doesNotThrow(() =>
      translateAuditEvent({
        action: "assign_shop",
        target_username: null,
        detail: null,
      }),
    );
  });

  it("does not invent display names from username alone", () => {
    assert.equal(
      translateAuditEvent({
        action: "create",
        target_username: "ahmed",
        detail: {},
      }),
      "Account created: ahmed",
    );
  });
});

describe("formatActivityTime", () => {
  it("formats same-day times compactly", () => {
    const now = new Date("2026-09-20T15:00:00");
    const label = formatActivityTime("2026-09-20T12:42:00", now);
    assert.ok(label.length > 0);
    assert.equal(typeof label, "string");
  });
});

describe("overview loading contract", () => {
  it("loading UI must not receive overview counts (null until ready)", () => {
    // Documented contract for OverviewPanel: overview is only bound when state===ready
    const loadingOverview = null;
    assert.equal(loadingOverview, null);
  });
});
