import { requireMutationContext, parseMutationBody, mutationError, mutationSuccess } from "@/lib/admin-mutation";
import { getAdminKeyConfig, getAccountServerConfig } from "@/lib/config";
import { callWriteRpc, callAuthAdminApi, fetchAdminListShops } from "@/lib/account-server";
import { classifyProviderFailure, classifyRpcFailure, readAuthUserId, safeCorrelationId } from "@/lib/admin-security";
import { createOutcomeIsAmbiguous } from "@/lib/identity-create";
import { generateServerCredential } from "@/lib/credential";
import { elapsedMs } from "@/lib/perf";
import { deleteAuthWithRetry, logOperationalFailure, recordReconciliation } from "@/lib/reconciliation";
import { mapShopList } from "@/lib/shops";

import { validateUsername, validateDisplayName, validateRole, validateShops } from "@/lib/validation";

export async function POST(request: Request) {
  const reqRes = await requireMutationContext(request);
  if (!reqRes.ok) return reqRes.response;
  const { ctx } = reqRes;
  const correlationId = safeCorrelationId();

  const body = await parseMutationBody<{
    username?: string;
    display_name?: string;
    role?: string;
    shop_ids?: unknown;
  }>(request);

  if (!body) {
    return mutationError(ctx.meta, "INVALID_REQUEST", "Invalid JSON body.", 400, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const uVal = validateUsername(body?.username);
  const dVal = validateDisplayName(body?.display_name);
  const rVal = validateRole(body?.role);

  if (!uVal.valid || !dVal.valid || !rVal.valid) {
    return mutationError(ctx.meta, "INVALID_REQUEST", uVal.error || dVal.error || rVal.error || "Invalid input", 400, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  if (!rVal.role) {
    return mutationError(ctx.meta, "INVALID_REQUEST", "Invalid role.", 400, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const sVal = validateShops(rVal.role, body.shop_ids);
  if (!sVal.valid) {
    return mutationError(ctx.meta, "INVALID_REQUEST", sVal.error!, 400, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  if ((rVal.role === "owner" || rVal.role === "admin") && ctx.profile.role !== "owner") {
    return mutationError(ctx.meta, "FORBIDDEN", "Only owners can create owners or admins", 403, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  // Verify every shop against the caller-scoped read RPC before creating Auth state.
  if (sVal.shopIds.length > 0) {
    const shopsResult = await fetchAdminListShops(ctx.accessToken, 100, 0);
    const visibleShops = shopsResult.kind === "ok" ? mapShopList(shopsResult.data) : null;
    if (!visibleShops) {
      return mutationError(ctx.meta, "SERVER_UNAVAILABLE", "Shop assignments could not be verified.", 503, {
        label: "admin.createStaff",
        sessionMs: ctx.sessionMs,
        totalMs: elapsedMs(ctx.tTotal),
      });
    }
    const allowedShopIds = new Set(visibleShops.map((shop) => shop.shop_id));
    if (sVal.shopIds.some((shopId) => !allowedShopIds.has(shopId))) {
      return mutationError(ctx.meta, "NOT_FOUND", "One or more shops were not found.", 404, {
        label: "admin.createStaff",
        sessionMs: ctx.sessionMs,
        totalMs: elapsedMs(ctx.tTotal),
      });
    }
  }

  const adminKeyCfg = getAdminKeyConfig();
  if (!adminKeyCfg) {
    return mutationError(
      ctx.meta,
      "ADMIN_KEY_MISSING",
      "Account administration is unavailable.",
      503,
      { label: "admin.createStaff", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) }
    );
  }

  const cfg = getAccountServerConfig();
  const email = `${uVal.normalized}@${cfg.fakeDomain}`;
  const credential = generateServerCredential();

  // 1. Create Auth Identity
  const authRes = await callAuthAdminApi(adminKeyCfg.adminKey, cfg.url, "POST", "/auth/v1/admin/users", {
    email,
    password: credential,
    email_confirm: true,
  });

  if (authRes.kind !== "ok") {
    const providerCode = authRes.kind === "error"
      ? classifyProviderFailure(authRes.status, authRes.body)
      : "UNREACHABLE";
    logOperationalFailure("create_staff_auth", correlationId, providerCode);
    const code = providerCode === "ALREADY_EXISTS" ? "CONFLICT" : "SERVER_UNAVAILABLE";
    const message = code === "CONFLICT"
      ? "That username is already reserved."
      : providerCode === "FORBIDDEN"
        ? "The server admin key was rejected for this project — check ACCOUNT_SERVER_ADMIN_KEY."
        : providerCode === "INVALID_INPUT"
          ? "The credential was rejected by the server password policy."
          : providerCode === "RATE_LIMITED"
            ? "The auth server rate-limited the request — wait a moment and retry."
            : providerCode === "UNREACHABLE"
              ? "The auth server is unreachable from the viewer — check network and key configuration."
              : "Account creation could not be completed.";
    return mutationError(ctx.meta, code, message, code === "CONFLICT" ? 409 : 503, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const authUserId = readAuthUserId(authRes.data);
  if (!authUserId) {
    logOperationalFailure("create_staff_auth", correlationId, "INVALID_RESPONSE");
    return mutationError(ctx.meta, "INTERNAL_ERROR", "The auth server response was invalid — account not created.", 500, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  // 2. Call DB RPC
  const rpcRes = await callWriteRpc(ctx.accessToken, "admin_create_staff_db", {
    p_auth_user_id: authUserId,
    p_username: uVal.normalized,
    p_display_name: dVal.normalized,
    p_role: rVal.role,
    p_shop_ids: sVal.shopIds,
  });

  // A missing/malformed response or server error does not prove that the write rolled back.
  if (createOutcomeIsAmbiguous(rpcRes)) {
    const recorded = await recordReconciliation({
      adminKey: adminKeyCfg.adminKey, businessId: ctx.profile.business_id,
      operation: "create_verify", authUserId, targetUsername: uVal.normalized,
      performedBy: ctx.profile.staff_id, performedByUsername: ctx.profile.username,
      errorCode: "UNREACHABLE", correlationId,
    });
    logOperationalFailure("create_staff_verify", correlationId, recorded ? "PENDING" : "RECORD_FAILED");
    return mutationError(ctx.meta, "RECONCILIATION_REQUIRED",
      "Account creation has an unknown outcome. Reconcile it before retrying; its identity has been preserved.",
      503, { label: "admin.createStaff", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) });
  }
  // Compensate only a definitive rejected database request.
  if (rpcRes.kind !== "ok") {
    const cleanup = await deleteAuthWithRetry(adminKeyCfg.adminKey, cfg.url, authUserId);
    if (!cleanup.resolved) {
      const recorded = await recordReconciliation({
        adminKey: adminKeyCfg.adminKey,
        businessId: ctx.profile.business_id,
        operation: "create_cleanup",
        authUserId,
        targetUsername: uVal.normalized,
        performedBy: ctx.profile.staff_id,
        performedByUsername: ctx.profile.username,
        errorCode: cleanup.errorCode,
        correlationId,
      });
      logOperationalFailure("create_staff_cleanup", correlationId, recorded ? "PENDING" : "RECORD_FAILED");
      return mutationError(
        ctx.meta,
        recorded ? "RECONCILIATION_REQUIRED" : "INTERNAL_ERROR",
        recorded
          ? "Account creation was rolled back incompletely and requires administrator reconciliation."
          : "Account creation failed and its cleanup state could not be recorded.",
        503,
        { label: "admin.createStaff", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) },
      );
    }

    const failure = rpcRes.kind === "unauthorized"
      ? { code: "FORBIDDEN" as const, status: rpcRes.status, message: "This operation is not permitted." }
      : rpcRes.kind === "error"
        ? classifyRpcFailure(rpcRes.body)
        : { code: "SERVER_UNAVAILABLE" as const, status: 503, message: "Account Server could not be reached." };
    return mutationError(ctx.meta, failure.code, failure.message, failure.status, {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const staffId = rpcRes.data as string;

  return mutationSuccess(
    ctx.meta,
    { ok: true, staff_id: staffId, credential },
    {
      label: "admin.createStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    }
  );
  
}
