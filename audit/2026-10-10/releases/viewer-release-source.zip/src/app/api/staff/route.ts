import {
  fetchAdminListShops,
  fetchAdminListStaff,
} from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { safeAccountServerMeta } from "@/lib/safe-meta";
import {
  isUuid,
  mapShopOptions,
  mapStaffList,
  STAFF_PAGE_SIZE_DEFAULT,
  STAFF_PAGE_SIZE_MAX,
  STAFF_SEARCH_MAX,
  type StaffListApiResponse,
  type StaffListQuery,
} from "@/lib/staff";
import {
  isStaffRoleFilter,
  isStaffStatusFilter,
} from "@/lib/staff-status";
import { clearViewerSession, readViewerSession } from "@/lib/session";

export const runtime = "nodejs";

function baseMeta() {
  return safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });
}

function parseQuery(url: URL): { ok: true; query: StaffListQuery } | { ok: false; message: string } {
  const searchRaw = (url.searchParams.get("search") || "").trim();
  if (searchRaw.length > STAFF_SEARCH_MAX) {
    return { ok: false, message: `Search must be at most ${STAFF_SEARCH_MAX} characters.` };
  }

  const roleRaw = (url.searchParams.get("role") || "all").trim().toLowerCase();
  if (roleRaw !== "all" && !isStaffRoleFilter(roleRaw)) {
    return { ok: false, message: "Invalid role filter." };
  }

  const statusRaw = (url.searchParams.get("status") || "all").trim().toLowerCase();
  if (!isStaffStatusFilter(statusRaw)) {
    return { ok: false, message: "Invalid status filter." };
  }

  const shopRaw = (url.searchParams.get("shop_id") || "").trim();
  if (shopRaw && !isUuid(shopRaw)) {
    return { ok: false, message: "Invalid shop filter." };
  }

  let limit = STAFF_PAGE_SIZE_DEFAULT;
  const limitRaw = url.searchParams.get("limit");
  if (limitRaw != null && limitRaw !== "") {
    const n = Number.parseInt(limitRaw, 10);
    if (!Number.isFinite(n)) return { ok: false, message: "Invalid limit." };
    limit = Math.max(1, Math.min(STAFF_PAGE_SIZE_MAX, n));
  }

  let offset = 0;
  const offsetRaw = url.searchParams.get("offset");
  if (offsetRaw != null && offsetRaw !== "") {
    const n = Number.parseInt(offsetRaw, 10);
    if (!Number.isFinite(n) || n < 0) return { ok: false, message: "Invalid offset." };
    offset = Math.min(n, 100_000);
  }

  return {
    ok: true,
    query: {
      search: searchRaw || null,
      role: roleRaw === "all" ? null : roleRaw,
      status: statusRaw === "all" ? null : statusRaw,
      shopId: shopRaw || null,
      limit,
      offset,
    },
  };
}

export async function GET(request: Request) {
  const tTotal = nowMs();
  const meta = baseMeta();
  const parsed = parseQuery(new URL(request.url));
  if (!parsed.ok) {
    const body: StaffListApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      shopOptions: [],
      page: { limit: STAFF_PAGE_SIZE_DEFAULT, offset: 0, hasMore: false, count: 0 },
      query: {
        search: null,
        role: null,
        status: null,
        shopId: null,
        limit: STAFF_PAGE_SIZE_DEFAULT,
        offset: 0,
      },
      error: { code: "INVALID_REQUEST", message: parsed.message },
    };
    return timedJson(body, 400, { label: "staff.list", totalMs: elapsedMs(tTotal) });
  }

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);
  if (!session) {
    const body: StaffListApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      shopOptions: [],
      page: {
        limit: parsed.query.limit,
        offset: parsed.query.offset,
        hasMore: false,
        count: 0,
      },
      query: parsed.query,
      error: { code: "UNAUTHENTICATED", message: "Sign in required." },
    };
    return timedJson(body, 401, {
      label: "staff.list",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  // P1.1: no blocking ping — list RPCs are the reachability signal.
  const tRpc = nowMs();
  const [staffResult, shopsResult] = await Promise.all([
    fetchAdminListStaff(session.accessToken, {
      search: parsed.query.search,
      role: parsed.query.role,
      status: parsed.query.status,
      shopId: parsed.query.shopId,
      limit: parsed.query.limit,
      offset: parsed.query.offset,
    }),
    fetchAdminListShops(session.accessToken, 100, 0),
  ]);
  const rpcWallMs = elapsedMs(tRpc);
  const rpcStaffMs = staffResult.durationMs;
  const rpcShopsMs = shopsResult.durationMs;

  if (staffResult.kind === "unauthorized" || shopsResult.kind === "unauthorized") {
    await clearViewerSession();
    const body: StaffListApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      shopOptions: [],
      page: {
        limit: parsed.query.limit,
        offset: parsed.query.offset,
        hasMore: false,
        count: 0,
      },
      query: parsed.query,
      error: {
        code: "UNAUTHORIZED",
        message: "Session is no longer authorized for Staff.",
      },
    };
    return timedJson(body, 401, {
      label: "staff.list",
      sessionMs,
      rpcMs: rpcWallMs,
      extra: { rpc_staff: rpcStaffMs, rpc_shops: rpcShopsMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  if (staffResult.kind !== "ok") {
    const body: StaffListApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      shopOptions: [],
      page: {
        limit: parsed.query.limit,
        offset: parsed.query.offset,
        hasMore: false,
        count: 0,
      },
      query: parsed.query,
      error: {
        code:
          staffResult.kind === "unreachable" ? "SERVER_UNAVAILABLE" : "STAFF_UNAVAILABLE",
        message:
          staffResult.kind === "unreachable"
            ? "Account Server could not be reached."
            : "Staff list is unavailable right now.",
      },
    };
    return timedJson(body, staffResult.kind === "unreachable" ? 503 : 502, {
      label: "staff.list",
      sessionMs,
      rpcMs: rpcWallMs,
      extra: { rpc_staff: rpcStaffMs, rpc_shops: rpcShopsMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  const tMap = nowMs();
  const staff = mapStaffList(staffResult.data);
  if (!staff) {
    const body: StaffListApiResponse = {
      ok: false,
      ...meta,
      staff: null,
      shopOptions: [],
      page: {
        limit: parsed.query.limit,
        offset: parsed.query.offset,
        hasMore: false,
        count: 0,
      },
      query: parsed.query,
      error: {
        code: "STAFF_UNAVAILABLE",
        message: "Staff list is unavailable right now.",
      },
    };
    return timedJson(body, 502, {
      label: "staff.list",
      sessionMs,
      rpcMs: rpcWallMs,
      mapMs: elapsedMs(tMap),
      totalMs: elapsedMs(tTotal),
    });
  }

  let shopOptions =
    shopsResult.kind === "ok" ? mapShopOptions(shopsResult.data) ?? [] : [];
  shopOptions = [...shopOptions].sort((a, b) => {
    if (a.active !== b.active) return a.active ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  const mapMs = elapsedMs(tMap);

  const body: StaffListApiResponse = {
    ok: true,
    ...meta,
    staff,
    shopOptions,
    page: {
      limit: parsed.query.limit,
      offset: parsed.query.offset,
      hasMore: staff.length >= parsed.query.limit,
      count: staff.length,
    },
    query: parsed.query,
    error: null,
  };
  return timedJson(body, 200, {
    label: "staff.list",
    sessionMs,
    rpcMs: rpcWallMs,
    mapMs,
    extra: { rpc_staff: rpcStaffMs, rpc_shops: rpcShopsMs },
    totalMs: elapsedMs(tTotal),
  });
}
