import {
  fetchAdminGetShop,
  fetchAdminListActivity,
} from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { safeAccountServerMeta } from "@/lib/safe-meta";
import { clearViewerSession, readViewerSession } from "@/lib/session";
import {
  isUuid,
  mapShopActivity,
  mapShopDetail,
  type ShopDetailApiResponse,
} from "@/lib/shops";

export const runtime = "nodejs";

/**
 * P1.1: no blocking ping.
 * get_shop and activity list are independent (activity filtered by URL shopId).
 */

function baseMeta() {
  return safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });
}

function looksMissing(status: number, body: string): boolean {
  const t = (body || "").toLowerCase();
  return (
    status === 404 ||
    status === 400 ||
    status === 406 ||
    t.includes("not found") ||
    t.includes("p0002") ||
    t.includes("no rows")
  );
}

type Ctx = { params: Promise<{ shopId: string }> };

export async function GET(_request: Request, context: Ctx) {
  const tTotal = nowMs();
  const meta = baseMeta();
  const { shopId: rawId } = await context.params;
  const shopId = (rawId || "").trim();

  if (!isUuid(shopId)) {
    const body: ShopDetailApiResponse = {
      ok: false,
      ...meta,
      shop: null,
      recent_activity: [],
      error: { code: "INVALID_REQUEST", message: "Invalid shop id." },
    };
    return timedJson(body, 400, { label: "shops.detail", totalMs: elapsedMs(tTotal) });
  }

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);
  if (!session) {
    const body: ShopDetailApiResponse = {
      ok: false,
      ...meta,
      shop: null,
      recent_activity: [],
      error: { code: "UNAUTHENTICATED", message: "Sign in required." },
    };
    return timedJson(body, 401, {
      label: "shops.detail",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const tRpc = nowMs();
  const [result, activityResult] = await Promise.all([
    fetchAdminGetShop(session.accessToken, shopId),
    fetchAdminListActivity(session.accessToken, {
      limit: 50,
      offset: 0,
    }),
  ]);
  const rpcWallMs = elapsedMs(tRpc);

  if (result.kind === "unauthorized") {
    await clearViewerSession();
    const body: ShopDetailApiResponse = {
      ok: false,
      ...meta,
      shop: null,
      recent_activity: [],
      error: {
        code: "UNAUTHORIZED",
        message: "Session is no longer authorized for Shops.",
      },
    };
    return timedJson(body, 401, {
      label: "shops.detail",
      sessionMs,
      rpcMs: rpcWallMs,
      extra: {
        rpc_shop: result.durationMs,
        rpc_activity: activityResult.durationMs,
      },
      totalMs: elapsedMs(tTotal),
    });
  }

  if (result.kind === "unreachable") {
    const body: ShopDetailApiResponse = {
      ok: false,
      ...meta,
      shop: null,
      recent_activity: [],
      error: {
        code: "SERVER_UNAVAILABLE",
        message: "Account Server could not be reached.",
      },
    };
    return timedJson(body, 503, {
      label: "shops.detail",
      sessionMs,
      rpcMs: rpcWallMs,
      extra: { rpc_shop: result.durationMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  if (result.kind === "error") {
    const missing = looksMissing(result.status, result.body);
    const body: ShopDetailApiResponse = {
      ok: false,
      ...meta,
      shop: null,
      recent_activity: [],
      error: {
        code: missing ? "NOT_FOUND" : "SHOPS_UNAVAILABLE",
        message: missing ? "Shop not found." : "Shop detail is unavailable right now.",
      },
    };
    return timedJson(body, missing ? 404 : 502, {
      label: "shops.detail",
      sessionMs,
      rpcMs: rpcWallMs,
      extra: { rpc_shop: result.durationMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  const shop = mapShopDetail(result.data);
  if (!shop) {
    const body: ShopDetailApiResponse = {
      ok: false,
      ...meta,
      shop: null,
      recent_activity: [],
      error: { code: "NOT_FOUND", message: "Shop not found." },
    };
    return timedJson(body, 404, {
      label: "shops.detail",
      sessionMs,
      rpcMs: rpcWallMs,
      extra: { rpc_shop: result.durationMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  let recent_activity: ShopDetailApiResponse["recent_activity"] = [];
  if (activityResult.kind === "ok") {
    recent_activity = mapShopActivity(activityResult.data, shop.shop_id, 8);
  }

  const body: ShopDetailApiResponse = {
    ok: true,
    ...meta,
    shop,
    recent_activity,
    error: null,
  };
  return timedJson(body, 200, {
    label: "shops.detail",
    sessionMs,
    rpcMs: rpcWallMs,
    extra: {
      rpc_shop: result.durationMs,
      rpc_activity: activityResult.durationMs,
    },
    totalMs: elapsedMs(tTotal),
  });
}
