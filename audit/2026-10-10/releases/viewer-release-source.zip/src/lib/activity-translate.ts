/**
 * Deterministic audit-action → human summary for Overview (C0.2),
 * Staff/Shops compact activity, and Activity (C0.5).
 *
 * Never invent display names: only use username / detail fields that exist.
 * Never return raw JSON.
 */

import { formatStaffRole } from "./staff-status";

export type AuditDetail = Record<string, unknown> | null | undefined;

export type AuditEventLike = {
  action?: unknown;
  target_username?: unknown;
  detail?: AuditDetail;
};

/** Known Account Server audit actions for Viewer C0. */
export const KNOWN_AUDIT_ACTIONS = [
  "create",
  "disable",
  "enable",
  "set_role",
  "assign_shop",
  "unassign_shop",
  "terminate",
  "reset_server_credential",
  "add_shop",
  "recover_identity",
] as const;

export type KnownAuditAction = (typeof KNOWN_AUDIT_ACTIONS)[number];

export function isKnownAuditAction(value: string): value is KnownAuditAction {
  return (KNOWN_AUDIT_ACTIONS as readonly string[]).includes(value);
}

function asTrimmedString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const t = value.trim();
  return t.length > 0 ? t : null;
}

function subjectLabel(event: AuditEventLike): string | null {
  const detail = event.detail && typeof event.detail === "object" ? event.detail : null;
  const fromDetail = detail ? asTrimmedString(detail.display_name) : null;
  if (fromDetail) return fromDetail;
  return asTrimmedString(event.target_username);
}

function shopLabel(detail: AuditDetail): string | null {
  if (!detail || typeof detail !== "object") return null;
  return asTrimmedString(detail.shop) ?? asTrimmedString(detail.name);
}

function roleLabel(value: unknown): string | null {
  const raw = asTrimmedString(value);
  if (!raw) return null;
  return formatStaffRole(raw);
}

function humanizeUnknownAction(action: string): string {
  const words = action
    .replace(/[_-]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
  if (!words) return "Account activity recorded";
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/** Pure translator — safe with missing/partial payloads. */
export function translateAuditEvent(event: AuditEventLike): string {
  const action = asTrimmedString(event.action);
  if (!action) return "Account activity recorded";

  const who = subjectLabel(event);
  const detail = event.detail && typeof event.detail === "object" ? event.detail : null;

  switch (action) {
    case "create":
      return who ? `Account created: ${who}` : "Account created";
    case "disable":
      return who ? `${who} disabled` : "Account disabled";
    case "enable":
      return who ? `${who} enabled` : "Account enabled";
    case "set_role": {
      const from = roleLabel(detail?.from);
      const to = roleLabel(detail?.to);
      if (who && from && to) return `Role changed for ${who}: ${from} → ${to}`;
      if (who) return `Role changed for ${who}`;
      if (from && to) return `Role changed: ${from} → ${to}`;
      return "Role changed";
    }
    case "assign_shop": {
      const shop = shopLabel(detail);
      if (shop && who) return `${shop} assigned to ${who}`;
      if (who) return `Shop assigned to ${who}`;
      if (shop) return `Shop assigned: ${shop}`;
      return "Shop assigned";
    }
    case "unassign_shop": {
      const shop = shopLabel(detail);
      if (shop && who) return `${who} removed from ${shop}`;
      if (who) return `${who} removed from a shop`;
      return "Shop assignment removed";
    }
    case "terminate":
      return who ? `${who} terminated` : "Account terminated";
    case "reset_server_credential":
      return who ? `Server credential reset for ${who}` : "Server credential reset";
    case "add_shop": {
      const name = detail ? asTrimmedString(detail.name) : null;
      return name ? `Shop added: ${name}` : "Shop added";
    }
    case "recover_identity":
      return "Identity recovery performed";
    default:
      return humanizeUnknownAction(action);
  }
}
