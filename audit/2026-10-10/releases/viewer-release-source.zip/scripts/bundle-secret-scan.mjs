import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

const ROOT = process.cwd();
const BANNED = ["sb_secret_", "SERVICE_ROLE", "service_role"];
const SKIP = new Set(["node_modules", ".git", ".next", ".vercel", "coverage", "security-reports"]);

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (/\.(js|jsx|ts|tsx|mjs|cjs|json|md|yml|yaml|css|html)$/i.test(name)) out.push(p);
  }
  return out;
}

const hits = [];
for (const file of walk(ROOT)) {
  if (file.includes(`${join("scripts", "bundle-secret-scan")}`)) continue;
  const text = readFileSync(file, "utf8");
  for (const ban of BANNED) {
    if (text.includes(ban) && !file.endsWith("SECURITY.md") && !file.endsWith("README.md") && !file.endsWith(".gitignore")) {
      // Allow documentation warnings that mention the string as a prohibition
      if ((file.endsWith("README.md") || file.endsWith("SECURITY.md") || file.endsWith("config.ts")) && text.includes("Never")) {
        continue;
      }
      if (file.endsWith("config.ts") || file.endsWith("README.md") || file.endsWith("SECURITY.md") || file.endsWith("SECURITY-REVIEW.md") || file.endsWith("C0.7-CHECKLIST.md") || file.endsWith(".env.example")) {
        continue;
      }
      hits.push(`${file}: ${ban}`);
    }
  }
}

if (hits.length) {
  console.error("Banned secret patterns found:\n" + hits.join("\n"));
  process.exit(1);
}
console.log("bundle-secret-scan: clean");
