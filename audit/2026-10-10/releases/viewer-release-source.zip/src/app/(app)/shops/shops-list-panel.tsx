"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  formatStaffDate,
  SHOP_PAGE_SIZE_DEFAULT,
  type ShopListApiResponse,
  type ShopStatus,
} from "@/lib/shops";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek, viewerCacheInvalidate } from "@/lib/viewer-cache";

type LoadState = "loading" | "ready" | "error";

function StatusText({ status }: { status: ShopStatus }) {
  return (
    <span
      className={`text-sm font-medium ${
        status === "Active" ? "text-[var(--success)]" : "text-[var(--muted)]"
      }`}
    >
      {status}
    </span>
  );
}

function ListSkeleton() {
  return (
    <div className="space-y-3" aria-busy="true" aria-label="Loading shops">
      {Array.from({ length: 3 }).map((_, i) => (
        <div
          key={i}
          className="h-14 animate-pulse rounded-xl border border-[var(--line)] bg-[var(--card)]"
        />
      ))}
    </div>
  );
}

export function ShopsListPanel() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const offset = Math.max(0, Number.parseInt(searchParams.get("offset") || "0", 10) || 0);

  const shopsPeekKey = offset > 0 ? `shops?limit=${SHOP_PAGE_SIZE_DEFAULT}&offset=${offset}` : `shops?limit=${SHOP_PAGE_SIZE_DEFAULT}`;
  const peeked = viewerCachePeek(shopsPeekKey) as ShopListApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok && peeked.shops ? "ready" : "loading");
  const [data, setData] = useState<ShopListApiResponse | null>(peeked);

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    const qs = new URLSearchParams();
    qs.set("limit", String(SHOP_PAGE_SIZE_DEFAULT));
    if (offset > 0) qs.set("offset", String(offset));
    const qsStr = qs.toString();
    const apply = (status: number, json: ShopListApiResponse) => {
      if (!isCurrent()) return;
      if (
        status === 401 ||
        json.error?.code === "UNAUTHENTICATED" ||
        json.error?.code === "UNAUTHORIZED"
      ) {
        router.replace("/login?error=session");
        return;
      }
      setData(json);
      if (json.ok && json.shops) setState("ready");
      else setState("error");
    };
    try {
      const result = await viewerCachedGet({
        key: `shops?${qsStr}`,
        url: `/api/shops?${qsStr}`,
        ttlMs: VIEWER_TTL.shopsList,
        onRevalidated: ({ status, body }) => apply(status, body as ShopListApiResponse),
      });
      apply(result.status, result.body as ShopListApiResponse);
    } catch {
      if (!isCurrent()) return;
      setData({
        ok: false,
        env: "unknown",
        contract: "v1.1.0-read-admin",
        shops: null,
        page: {
          limit: SHOP_PAGE_SIZE_DEFAULT,
          offset: 0,
          hasMore: false,
          count: 0,
        },
        error: {
          code: "SERVER_UNAVAILABLE",
          message: "Account Server could not be reached.",
        },
      });
      setState("error");
    }
  }, [offset, router]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load]);

  function setOffset(next: number) {
    const qs = new URLSearchParams();
    if (next > 0) qs.set("offset", String(next));
    const s = qs.toString();
    router.replace(s ? `${pathname}?${s}` : pathname);
  }

  const showPaging =
    state === "ready" &&
    data?.shops &&
    (offset > 0 || data.page.hasMore || data.shops.length >= SHOP_PAGE_SIZE_DEFAULT);

    const envLabel = (data?.env || "unknown").toUpperCase();
  const [isAdding, setIsAdding] = useState(false);

  async function handleAddShop() {
    const name = window.prompt("Enter the new shop name:");
    if (!name || !name.trim()) return;
    
    setIsAdding(true);
    try {
      const res = await fetch("/api/admin/rpc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rpc: "admin_add_shop", payload: { p_name: name.trim() } }),
      });
      const json = await res.json();
      if (!json.ok) {
        alert(`Failed to add shop: ${json.error?.message || "Unknown error"}`);
      } else {
        // Success
        viewerCacheInvalidate(["/api/shops"]);
        // Reload to show the new shop
        await load();
      }
    } catch {
      alert("Network error.");
    } finally {
      setIsAdding(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Unified header */}
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">Shops</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Locations, assigned staff, and owner access across the business.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
            <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
            {envLabel}
          </span>
          <button
            type="button"
            onClick={handleAddShop}
            disabled={isAdding}
            className="rounded-lg bg-[var(--ink)] px-3 py-1.5 text-sm font-medium text-[var(--bg)] hover:opacity-90 disabled:opacity-50"
          >
            {isAdding ? "Adding..." : "+ Add Shop"}
          </button>
        </div>
      </header>

      {state === "loading" ? <ListSkeleton /> : null}

      {state === "error" ? (
        <section className="space-y-3 rounded-xl border border-[var(--danger)]/30 bg-[var(--danger-bg)] p-4" role="alert">
          <p className="text-sm text-[var(--danger)]">
            {data?.error?.message || "Shop list is unavailable."}
          </p>
          <p className="text-sm text-[var(--muted)]">
            Shops are not shown while data cannot be loaded.
          </p>
          <button
            type="button"
            onClick={() => void load()}
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3 py-1.5 text-sm font-medium hover:bg-[var(--bg)]"
          >
            Retry
          </button>
        </section>
      ) : null}

      {state === "ready" && data?.shops ? (
        <>
          {data.shops.length === 0 ? (
            <p className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-6 text-center text-sm text-[var(--muted)]">No shops have been added yet.</p>
          ) : (
            <>
              {/* Desktop table */}
              <div className="hidden overflow-hidden rounded-xl border border-[var(--line)] bg-[var(--card)] shadow-sm md:block">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-[var(--line)] bg-[var(--bg)] text-xs tracking-wide text-[var(--muted)] uppercase">
                    <tr>
                      <th className="px-4 py-3 font-medium">Shop</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium">Assigned staff</th>
                      <th className="px-4 py-3 font-medium">Created</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--line)]">
                    {data.shops.map((shop) => (
                      <tr key={shop.shop_id} className="transition-colors duration-100 hover:bg-[var(--bg)]">
                        <td className="px-4 py-3">
                          <Link href={`/shops/${shop.shop_id}`} className="font-medium text-[var(--ink)]">
                            {shop.name}
                          </Link>
                        </td>
                        <td className="px-4 py-3">
                          <Link href={`/shops/${shop.shop_id}`}>
                            <StatusText status={shop.status} />
                          </Link>
                        </td>
                        <td className="px-4 py-3 tabular-nums text-[var(--muted)]">
                          <Link href={`/shops/${shop.shop_id}`}>
                            {shop.assigned_staff_count}
                          </Link>
                        </td>
                        <td className="px-4 py-3 tabular-nums text-[var(--muted)]">
                          <Link href={`/shops/${shop.shop_id}`}>
                            {formatStaffDate(shop.created_at)}
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile cards */}
              <ul className="space-y-2 md:hidden">
                {data.shops.map((shop) => (
                  <li key={shop.shop_id}>
                    <Link
                      href={`/shops/${shop.shop_id}`}
                      className="block rounded-xl border border-[var(--line)] bg-[var(--card)] p-3.5 shadow-sm transition-colors duration-100 hover:border-[var(--accent)]/30"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-medium text-[var(--ink)]">{shop.name}</p>
                        <StatusText status={shop.status} />
                      </div>
                      <p className="mt-1 text-sm text-[var(--muted)]">
                        {shop.assigned_staff_count} assigned staff
                        <span className="mx-1">·</span>
                        {formatStaffDate(shop.created_at)}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>

              <p className="text-xs text-[var(--muted)]">
                Assigned staff counts exclude Owners (who have access to all shops) and
                terminated accounts. Sorted by shop name.
              </p>
            </>
          )}

          {showPaging ? (
            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                type="button"
                disabled={offset <= 0}
                onClick={() => setOffset(Math.max(0, offset - SHOP_PAGE_SIZE_DEFAULT))}
                className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
              >
                Previous
              </button>
              <p className="text-xs text-[var(--muted)]">
                {data.shops.length === 0
                  ? "No results"
                  : `Showing ${offset + 1}–${offset + data.shops.length}`}
                {data.page.hasMore ? "+" : ""}
              </p>
              <button
                type="button"
                disabled={!data.page.hasMore}
                onClick={() => setOffset(offset + SHOP_PAGE_SIZE_DEFAULT)}
                className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:cursor-not-allowed disabled:opacity-40"
              >
                Next
              </button>
            </div>
          ) : null}
        </>
      ) : null}
    </div>
  );
}
