/**
 * Pure Account Server environment / hosting-channel rules (no secrets).
 * Safe to import from unit tests.
 */

export type AccountServerEnv = "dev" | "prod";

/** Known project refs used only for fail-closed mismatch detection (not secrets). */
export const KNOWN_DEV_PROJECT_REF = "tghzmofkkdsaasvnixps";
export const KNOWN_PROD_PROJECT_REF = "tlsuxbghuhlqntkgtrxt";

export type HostingChannel = "local" | "preview" | "production" | "development";

export function resolveHostingChannel(
  vercelEnv: string | undefined | null,
): HostingChannel {
  const v = (vercelEnv ?? "").trim().toLowerCase();
  if (v === "production") return "production";
  if (v === "preview") return "preview";
  if (v === "development") return "development";
  return "local";
}

/**
 * Pure resolver for Account Server environment + hosting channel rules.
 */
export function resolveAccountServerEnv(input: {
  accountServerEnv: string | undefined | null;
  vercelEnv: string | undefined | null;
  url: string;
}): { ok: true; env: AccountServerEnv } | { ok: false; message: string } {
  const raw = (input.accountServerEnv ?? "").trim().toLowerCase();
  if (!raw) {
    return { ok: false, message: "Missing required environment variable: ACCOUNT_SERVER_ENV" };
  }
  if (raw !== "dev" && raw !== "prod") {
    return {
      ok: false,
      message: `Unsupported ACCOUNT_SERVER_ENV=${raw}. Expected "dev" or "prod".`,
    };
  }
  const env = raw as AccountServerEnv;

  const channel = resolveHostingChannel(input.vercelEnv);

  if (channel === "preview" || channel === "development" || channel === "local") {
    if (env !== "dev") {
      return {
        ok: false,
        message: `Hosting channel "${channel}" must use ACCOUNT_SERVER_ENV=dev (got ${env}).`,
      };
    }
  }
  if (channel === "production") {
    if (env !== "prod") {
      return {
        ok: false,
        message: `Hosting channel "production" must use ACCOUNT_SERVER_ENV=prod (got ${env}).`,
      };
    }
  }

  const url = input.url.trim().toLowerCase();
  if (env === "dev" && url.includes(KNOWN_PROD_PROJECT_REF)) {
    return {
      ok: false,
      message: "ACCOUNT_SERVER_ENV=dev cannot use the known PROD Account Server project.",
    };
  }
  if (env === "prod" && url.includes(KNOWN_DEV_PROJECT_REF)) {
    return {
      ok: false,
      message: "ACCOUNT_SERVER_ENV=prod cannot use the known DEV Account Server project.",
    };
  }

  return { ok: true, env };
}
