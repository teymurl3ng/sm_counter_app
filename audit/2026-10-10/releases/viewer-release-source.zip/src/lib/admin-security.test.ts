import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  buildPrivilegedHeaders,
  classifyRpcFailure,
  classifyProviderFailure,
  isUuid,
  readAuthUserId,
} from "./admin-security";

describe("privileged Account Server headers", () => {
  it("uses opaque secret keys only as apikey", () => {
    assert.deepEqual(buildPrivilegedHeaders("sb_secret_example-123"), {
      apikey: "sb_secret_example-123",
      "Content-Type": "application/json",
    });
  });

  it("uses legacy service-role JWTs as apikey and bearer", () => {
    const jwt = "eyJheader.payload.signature";
    assert.deepEqual(buildPrivilegedHeaders(jwt), {
      apikey: jwt,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    });
  });

  it("rejects publishable and unknown keys", () => {
    assert.throws(() => buildPrivilegedHeaders("sb_publishable_example"));
    assert.throws(() => buildPrivilegedHeaders("not-a-key"));
  });
});

describe("admin security parsing", () => {
  it("validates UUIDs and Auth response IDs", () => {
    const id = "123e4567-e89b-42d3-a456-426614174000";
    assert.equal(isUuid(id), true);
    assert.equal(isUuid("not-a-uuid"), false);
    assert.equal(readAuthUserId({ id }), id);
    assert.equal(readAuthUserId({ id: "bad" }), null);
  });

  it("maps provider failures without exposing their body", () => {
    assert.equal(classifyProviderFailure(409, "anything"), "ALREADY_EXISTS");
    assert.equal(classifyProviderFailure(400, "User already registered"), "ALREADY_EXISTS");
    assert.equal(classifyProviderFailure(403), "FORBIDDEN");
    assert.equal(classifyProviderFailure(429), "RATE_LIMITED");
    assert.equal(classifyProviderFailure(503), "SERVER_ERROR");
  });

  it("maps Postgres codes to stable safe errors", () => {
    assert.deepEqual(classifyRpcFailure('{"code":"P0001","message":"secret database detail"}'), {
      code: "LAST_OWNER",
      status: 409,
      message: "At least one active owner must remain.",
    });
    // c1.5+ standard codes
    assert.equal(classifyRpcFailure('{"code":"42P01"}').code, "NOT_FOUND");
    assert.equal(classifyRpcFailure('{"code":"42P01"}').status, 404);
    assert.equal(classifyRpcFailure('{"code":"22023"}').code, "INVALID_REQUEST");
    assert.equal(classifyRpcFailure('{"code":"22023"}').status, 400);
    // legacy pre-c1.5 codes keep their mapping
    assert.equal(classifyRpcFailure('{"code":"P0002"}').code, "NOT_FOUND");
    assert.equal(classifyRpcFailure('{"code":"P0004"}').code, "INVALID_REQUEST");
    assert.equal(classifyRpcFailure("not json").code, "INTERNAL_ERROR");
  });
});
