import { NextResponse } from "next/server";
import { signOutBestEffort } from "@/lib/account-server";
import { clearViewerSession, readViewerSession } from "@/lib/session";

export const runtime = "nodejs";

export async function POST() {
  const session = await readViewerSession();
  if (session?.accessToken) {
    await signOutBestEffort(session.accessToken);
  }
  await clearViewerSession();
  return NextResponse.json({ ok: true });
}
