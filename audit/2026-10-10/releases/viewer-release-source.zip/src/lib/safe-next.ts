/**
 * Safe same-origin relative path for post-login redirects.
 * Rejects protocol-relative and backslash open redirects.
 */

const ALLOWED_PREFIXES = [
  "/overview",
  "/staff",
  "/shops",
  "/activity",
  "/system",
] as const;

export function safeNextPath(
  raw: string | null | undefined,
  fallback = "/overview",
): string {
  if (raw == null) return fallback;
  const next = raw.trim();
  if (!next.startsWith("/")) return fallback;
  if (next.startsWith("//")) return fallback;
  if (next.includes("\\")) return fallback;
  if (next.includes("://")) return fallback;
  // Disallow encoded tricks that decode to // or \
  try {
    const decoded = decodeURIComponent(next);
    if (decoded.startsWith("//") || decoded.includes("\\") || decoded.includes("://")) {
      return fallback;
    }
  } catch {
    return fallback;
  }

  const pathOnly = next.split(/[?#]/, 1)[0];
  const allowed = ALLOWED_PREFIXES.some(
    (p) => pathOnly === p || pathOnly.startsWith(`${p}/`),
  );
  return allowed ? next : fallback;
}
