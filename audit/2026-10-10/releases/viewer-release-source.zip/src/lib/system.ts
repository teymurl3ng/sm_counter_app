/**
 * System (C0.6) — owner-readable connection, access model, and boundaries.
 * Pure helpers + static copy; no infrastructure secrets.
 */

import { STAFF_ROLES, formatStaffRole } from "./staff-status";

export type ServerHealthStatus = "online" | "unavailable" | "checking";

export type SystemAccountContext = {
  display_name: string;
  username: string;
  role: string;
  role_label: string;
};

export type SystemShopSummary = {
  shops: number;
  active_shops: number;
};

export type SystemViewerMeta = {
  /** Viewer deployment channel (not Account Server env). */
  deployment: string;
  version: string;
  commit: string | null;
};

export type SystemStaticInfo = {
  account_server_env: string;
  account_server_contract: string;
  viewer_access: string;
  roles: ReadonlyArray<{ id: string; label: string }>;
  keep_alive: string;
  keep_alive_note: string;
  limitations: ReadonlyArray<string>;
  system_message: string;
};

export type SystemApiErrorCode =
  | "UNAUTHENTICATED"
  | "UNAUTHORIZED"
  | "UNKNOWN";

export type SystemApiResponse = {
  ok: boolean;
  account_server: {
    env: string;
    contract: string;
    status: "online" | "unavailable";
    ping_ok: boolean;
    /** ISO timestamp from successful ping when available. */
    checked_at: string | null;
  };
  account: SystemAccountContext | null;
  shops: SystemShopSummary | null;
  viewer: SystemViewerMeta;
  static: SystemStaticInfo;
  error: null | { code: SystemApiErrorCode; message: string };
};

export const VIEWER_ACCESS_TEXT = "Owner and Admin";

export const KEEP_ALIVE_SUMMARY =
  "Automatic keep-alive is configured externally through GitHub Actions.";

export const KEEP_ALIVE_NOTE =
  "Live keep-alive history is not displayed in this Viewer.";

export const SYSTEM_MESSAGE =
  "Saaf Milk Admin Viewer is currently connected to the Account Server.";

export const SYSTEM_LIMITATIONS: readonly string[] = [
  "Owner and Admin access only",
  "Account Server identity data only",
  "No ERP, sales, or inventory data",
  "No Google Drive or backup management",
  "No Android device management",
  "No account recovery from the web interface",
  "No live GitHub keep-alive monitoring",
];

/** Frozen Account Server role catalog for presentation. */
export function frozenRoleCatalog(): ReadonlyArray<{ id: string; label: string }> {
  return STAFF_ROLES.map((id) => ({ id, label: formatStaffRole(id) }));
}

export function buildSystemStatic(input: {
  env: string;
  contract: string;
}): SystemStaticInfo {
  return {
    account_server_env: input.env.trim().toLowerCase() || "unknown",
    account_server_contract: input.contract.trim() || "v1.1.0-read-admin",
    viewer_access: VIEWER_ACCESS_TEXT,
    roles: frozenRoleCatalog(),
    keep_alive: KEEP_ALIVE_SUMMARY,
    keep_alive_note: KEEP_ALIVE_NOTE,
    limitations: [...SYSTEM_LIMITATIONS],
    system_message: SYSTEM_MESSAGE,
  };
}

export function formatAccountServerEnvLabel(env: string): string {
  const e = env.trim().toLowerCase();
  if (!e || e === "unknown") return "UNKNOWN";
  return e.toUpperCase();
}

/**
 * Label Viewer hosting separately from Account Server environment.
 * Vercel "production" means the Viewer URL deployment target, not PROD Account Server.
 */
export function formatViewerDeploymentLabel(vercelEnv: string | undefined | null): string {
  const v = (vercelEnv || "").trim().toLowerCase();
  if (v === "production") return "Vercel production URL";
  if (v === "preview") return "Vercel preview";
  if (v === "development") return "Vercel development";
  return "Local";
}

export function mapSafeAccount(profile: {
  display_name?: unknown;
  username?: unknown;
  role?: unknown;
} | null): SystemAccountContext | null {
  if (!profile) return null;
  const display_name =
    typeof profile.display_name === "string" ? profile.display_name.trim() : "";
  const username = typeof profile.username === "string" ? profile.username.trim() : "";
  const role = typeof profile.role === "string" ? profile.role.trim().toLowerCase() : "";
  if (!username || !role) return null;
  return {
    display_name: display_name || username,
    username,
    role,
    role_label: formatStaffRole(role),
  };
}

export function mapShopSummary(overview: {
  shops?: unknown;
  active_shops?: unknown;
} | null): SystemShopSummary | null {
  if (!overview) return null;
  const shops =
    typeof overview.shops === "number" && Number.isFinite(overview.shops)
      ? Math.trunc(overview.shops)
      : null;
  const active_shops =
    typeof overview.active_shops === "number" && Number.isFinite(overview.active_shops)
      ? Math.trunc(overview.active_shops)
      : null;
  if (shops == null || active_shops == null || shops < 0 || active_shops < 0) return null;
  return { shops, active_shops };
}

export function mapHealthStatus(input: {
  pingOk: boolean;
  at?: string | null;
}): {
  status: "online" | "unavailable";
  ping_ok: boolean;
  checked_at: string | null;
} {
  if (!input.pingOk) {
    return { status: "unavailable", ping_ok: false, checked_at: null };
  }
  const at =
    typeof input.at === "string" && input.at.trim() ? input.at.trim() : null;
  return { status: "online", ping_ok: true, checked_at: at };
}

/** Fields that must never appear in System API/UI payloads. */
export const SYSTEM_FORBIDDEN_KEYS = [
  "publishableKey",
  "publishable_key",
  "url",
  "ACCOUNT_SERVER_URL",
  "ACCOUNT_SERVER_PUBLISHABLE_KEY",
  "accessToken",
  "refreshToken",
  "credential",
  "password",
  "jwt",
  "auth_user_id",
  "email",
  "staff_id",
  "business_id",
  "fakeDomain",
] as const;

export function payloadContainsForbiddenKeys(value: unknown): boolean {
  if (value == null || typeof value !== "object") return false;
  const stack: unknown[] = [value];
  while (stack.length) {
    const cur = stack.pop();
    if (cur == null || typeof cur !== "object") continue;
    for (const [k, v] of Object.entries(cur as Record<string, unknown>)) {
      if ((SYSTEM_FORBIDDEN_KEYS as readonly string[]).includes(k)) return true;
      const lower = k.toLowerCase();
      if (
        lower.includes("secret") ||
        lower.includes("token") ||
        lower.includes("password") ||
        lower.includes("credential") ||
        lower.includes("jwt")
      ) {
        return true;
      }
      if (v != null && typeof v === "object") stack.push(v);
    }
  }
  return false;
}

export function shortCommit(sha: string | null | undefined): string | null {
  if (!sha || typeof sha !== "string") return null;
  const t = sha.trim();
  if (t.length < 7) return null;
  return t.slice(0, 7);
}
