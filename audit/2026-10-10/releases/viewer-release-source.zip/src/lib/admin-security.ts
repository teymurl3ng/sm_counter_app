export type ProviderFailureCode =
  | "ALREADY_EXISTS"
  | "FORBIDDEN"
  | "INVALID_INPUT"
  | "NOT_FOUND"
  | "RATE_LIMITED"
  | "SERVER_ERROR"
  | "UNREACHABLE"
  | "UNKNOWN";

export type SafeRpcFailure = {
  code: "FORBIDDEN" | "NOT_FOUND" | "CONFLICT" | "LAST_OWNER" | "TERMINATED" | "INVALID_REQUEST" | "INTERNAL_ERROR";
  status: number;
  message: string;
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const LEGACY_JWT_RE = /^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/;
const SECRET_KEY_RE = /^sb_secret_[A-Za-z0-9_-]+$/;

export function isUuid(value: unknown): value is string {
  return typeof value === "string" && UUID_RE.test(value);
}

export function buildPrivilegedHeaders(adminKey: string): Record<string, string> {
  const key = adminKey.trim();
  if (!SECRET_KEY_RE.test(key) && !LEGACY_JWT_RE.test(key)) {
    throw new Error("Unsupported Account Server admin-key format.");
  }
  const headers: Record<string, string> = {
    apikey: key,
    "Content-Type": "application/json",
  };
  if (LEGACY_JWT_RE.test(key)) {
    headers.Authorization = `Bearer ${key}`;
  }
  return headers;
}

export function classifyProviderFailure(status: number, rawBody = ""): ProviderFailureCode {
  const body = rawBody.toLowerCase();
  if (status === 404) return "NOT_FOUND";
  if (status === 409 || body.includes("already registered") || body.includes("duplicate")) {
    return "ALREADY_EXISTS";
  }
  if (status === 401 || status === 403) return "FORBIDDEN";
  if (status === 400 || status === 422) return "INVALID_INPUT";
  if (status === 429) return "RATE_LIMITED";
  if (status >= 500) return "SERVER_ERROR";
  return "UNKNOWN";
}

export function readAuthUserId(data: unknown): string | null {
  if (!data || typeof data !== "object") return null;
  const id = (data as Record<string, unknown>).id;
  return isUuid(id) ? id : null;
}

export function classifyRpcFailure(rawBody: string): SafeRpcFailure {
  let postgresCode = "";
  try {
    const parsed = JSON.parse(rawBody) as { code?: unknown };
    postgresCode = typeof parsed.code === "string" ? parsed.code : "";
  } catch {
    postgresCode = "";
  }
  switch (postgresCode) {
    case "42501":
      return { code: "FORBIDDEN", status: 403, message: "This operation is not permitted." };
    case "P0001":
      return { code: "LAST_OWNER", status: 409, message: "At least one active owner must remain." };
    // "not found" — c1.5+ raises the standard 42P01 (HTTP 404); P0002/P0005
    // are the pre-c1.5 codes still served until PROD applies the migration.
    case "42P01":
    case "P0002":
    case "P0005":
      return { code: "NOT_FOUND", status: 404, message: "The requested record was not found." };
    case "P0003":
      return { code: "TERMINATED", status: 409, message: "A terminated account cannot be changed." };
    case "23505":
      return { code: "CONFLICT", status: 409, message: "That value is already in use." };
    // invalid request — c1.5+ raises 22023 (HTTP 400); P0004/P0006.. are legacy.
    case "22023":
    case "P0004":
    case "P0006":
    case "P0007":
    case "P0008":
    case "P0009":
    case "P0010":
    case "22P02":
      return { code: "INVALID_REQUEST", status: 400, message: "The request is invalid." };
    default:
      return { code: "INTERNAL_ERROR", status: 500, message: "The operation could not be completed." };
  }
}

export function safeCorrelationId(): string {
  return randomUUID();
}
import { randomUUID } from "crypto";
