import { translateAuditEvent } from "./activity-translate";
import {
  deriveStaffStatus,
  formatStaffRole,
  type StaffStatus,
} from "./staff-status";

export type StaffShop = { id: string; name: string };

export type StaffListItem = {
  staff_id: string;
  username: string;
  display_name: string;
  role: string;
  role_label: string;
  status: StaffStatus;
  active: boolean;
  terminated_at: string | null;
  created_at: string;
  updated_at: string | null;
  shops: StaffShop[];
  shops_label: string;
};

export type StaffDetail = StaffListItem & {
  business_id: string | null;
};

export type StaffActivityItem = {
  id: number | string;
  at: string;
  action: string;
  summary: string;
};

export type ShopOption = { id: string; name: string; active: boolean };

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export const STAFF_PAGE_SIZE_DEFAULT = 25;
export const STAFF_PAGE_SIZE_MAX = 100;
export const STAFF_SEARCH_MAX = 64;

export function isUuid(value: string): boolean {
  return UUID_RE.test(value.trim());
}

function asString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const t = value.trim();
  return t.length ? t : null;
}

function asBool(value: unknown): boolean | null {
  if (typeof value === "boolean") return value;
  return null;
}

function parseShops(raw: unknown): StaffShop[] {
  if (!Array.isArray(raw)) return [];
  const out: StaffShop[] = [];
  for (const item of raw) {
    if (item == null || typeof item !== "object") continue;
    const o = item as Record<string, unknown>;
    const id = asString(o.id) ?? asString(o.shop_id);
    const name = asString(o.name);
    if (!id || !name) continue;
    out.push({ id, name });
  }
  return out;
}

/**
 * Owner covers all active shops via admin_staff_shops_json.
 * Present as "All shops" rather than implying no assignment.
 */
export function formatShopsLabel(role: string, shops: StaffShop[]): string {
  if (role.trim().toLowerCase() === "owner") return "All shops";
  if (shops.length === 0) return "No shop assigned";
  if (shops.length === 1) return shops[0].name;
  if (shops.length <= 3) return shops.map((s) => s.name).join(", ");
  return `${shops.length} shops: ${shops
    .slice(0, 2)
    .map((s) => s.name)
    .join(", ")}…`;
}

/** Browser/local timezone via Intl (never labeled as UTC). */
export function formatStaffDate(iso: string, withTime = false): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  if (withTime) {
    return d.toLocaleString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  }
  return d.toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function mapStaffRow(raw: unknown, requireBusinessId: boolean): StaffListItem | StaffDetail | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;

  // Never accept privileged identity fields into mapped objects
  if ("auth_user_id" in o) {
    // strip by ignoring — do not copy
  }

  const staff_id = asString(o.staff_id);
  const username = asString(o.username);
  const display_name = asString(o.display_name) ?? username;
  const role = asString(o.role);
  const active = asBool(o.active);
  const created_at = asString(o.created_at);
  if (!staff_id || !username || !role || active == null || !created_at) return null;

  const terminated_at = asString(o.terminated_at);
  const updated_at = asString(o.updated_at);
  const shops = parseShops(o.shops);
  const status = deriveStaffStatus({ active, terminated_at });

  const base: StaffListItem = {
    staff_id,
    username,
    display_name: display_name ?? username,
    role: role.toLowerCase(),
    role_label: formatStaffRole(role),
    status,
    active,
    terminated_at,
    created_at,
    updated_at,
    shops,
    shops_label: formatShopsLabel(role, shops),
  };

  if (requireBusinessId) {
    const business_id = asString(o.business_id);
    return { ...base, business_id };
  }
  return base;
}

export function mapStaffListItem(raw: unknown): StaffListItem | null {
  return mapStaffRow(raw, false) as StaffListItem | null;
}

export function mapStaffDetail(raw: unknown): StaffDetail | null {
  const mapped = mapStaffRow(raw, true);
  if (!mapped || !("business_id" in mapped)) return null;
  return mapped as StaffDetail;
}

export function mapStaffList(raw: unknown): StaffListItem[] | null {
  if (!Array.isArray(raw)) return null;
  const out: StaffListItem[] = [];
  for (const row of raw) {
    const item = mapStaffListItem(row);
    if (!item) return null;
    out.push(item);
  }
  return out;
}

export function mapShopOptions(raw: unknown): ShopOption[] | null {
  if (!Array.isArray(raw)) return null;
  const out: ShopOption[] = [];
  for (const row of raw) {
    if (row == null || typeof row !== "object") continue;
    const o = row as Record<string, unknown>;
    const id = asString(o.shop_id) ?? asString(o.id);
    const name = asString(o.name);
    const active = asBool(o.active);
    if (!id || !name || active == null) return null;
    out.push({ id, name, active });
  }
  return out;
}

export function mapStaffActivity(raw: unknown, limit = 8): StaffActivityItem[] {
  if (!Array.isArray(raw)) return [];
  const out: StaffActivityItem[] = [];
  for (const item of raw) {
    if (out.length >= limit) break;
    if (item == null || typeof item !== "object") continue;
    const e = item as Record<string, unknown>;
    const action = asString(e.action);
    const at = asString(e.at);
    if (!action || !at) continue;
    const target = asString(e.target_username);
    const detail =
      e.detail != null && typeof e.detail === "object"
        ? (e.detail as Record<string, unknown>)
        : null;
    const id =
      typeof e.id === "number" || typeof e.id === "string" ? e.id : `${at}:${action}`;
    out.push({
      id,
      at,
      action,
      summary: translateAuditEvent({
        action,
        target_username: target,
        detail,
      }),
    });
  }
  return out;
}

export type StaffListQuery = {
  search: string | null;
  role: string | null;
  status: string | null;
  shopId: string | null;
  limit: number;
  offset: number;
};

export type StaffApiErrorCode =
  | "UNAUTHENTICATED"
  | "UNAUTHORIZED"
  | "SERVER_UNAVAILABLE"
  | "STAFF_UNAVAILABLE"
  | "NOT_FOUND"
  | "INVALID_REQUEST"
  | "UNKNOWN";

export type StaffListApiResponse = {
  ok: boolean;
  env: string;
  contract: string;
  staff: StaffListItem[] | null;
  shopOptions: ShopOption[];
  page: { limit: number; offset: number; hasMore: boolean; count: number };
  query: StaffListQuery;
  error: null | { code: StaffApiErrorCode; message: string };
};

export type StaffDetailApiResponse = {
  ok: boolean;
  env: string;
  contract: string;
  staff: StaffDetail | null;
  recent_activity: StaffActivityItem[];
  error: null | { code: StaffApiErrorCode; message: string };
};

/** Empty-state classification for list UI (not API failures). */
export function classifyStaffEmpty(query: StaffListQuery): "none" | "search" | "filters" {
  if (query.search) return "search";
  if (
    (query.role && query.role !== "all") ||
    (query.status && query.status !== "all") ||
    query.shopId
  ) {
    return "filters";
  }
  return "none";
}
