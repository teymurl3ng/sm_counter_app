"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import {
  KEEP_ALIVE_NOTE,
  KEEP_ALIVE_SUMMARY,
  SYSTEM_MESSAGE,
  SYSTEM_LIMITATIONS,
  VIEWER_ACCESS_TEXT,
  formatAccountServerEnvLabel,
  frozenRoleCatalog,
  type SystemApiResponse,
} from "@/lib/system";
import { VIEWER_TTL, viewerCachedGet, viewerCachePeek } from "@/lib/viewer-cache";

type LoadState = "loading" | "ready" | "error";

const FALLBACK_ROLES = frozenRoleCatalog();
const FALLBACK_LIMITATIONS = [...SYSTEM_LIMITATIONS];

function StatusDot({ online }: { online: boolean }) {
  return (
    <span
      className={`inline-block h-2.5 w-2.5 rounded-full ${
        online ? "bg-[var(--success)]" : "bg-[var(--danger)]"
      }`}
      aria-hidden
    />
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-xl border border-[var(--line)] bg-[var(--card)] p-4 shadow-sm sm:p-5">
      <h2 className="mb-4 text-xs font-semibold tracking-widest text-[var(--muted)] uppercase">
        {title}
      </h2>
      <div className="space-y-2 text-sm">{children}</div>
    </section>
  );
}

function Row({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 border-b border-[var(--line)] py-2.5 last:border-b-0">
      <dt className="text-sm text-[var(--muted)]">{label}</dt>
      <dd className="text-right text-sm font-medium text-[var(--ink)]">{value}</dd>
    </div>
  );
}

function SkeletonBlock() {
  return (
    <div className="space-y-2" aria-busy="true" aria-label="Loading system status">
      <div className="h-4 w-40 animate-pulse rounded bg-[var(--line)]" />
      <div className="h-4 w-56 animate-pulse rounded bg-[var(--line)]" />
      <div className="h-4 w-32 animate-pulse rounded bg-[var(--line)]" />
    </div>
  );
}

export function SystemPanel() {
  const router = useRouter();
  const peeked = viewerCachePeek("system") as SystemApiResponse | null;
  const [state, setState] = useState<LoadState>(peeked && peeked.ok ? "ready" : "loading");
  const [data, setData] = useState<SystemApiResponse | null>(peeked);

  const load = useCallback(async (isCurrent: () => boolean = () => true) => {
    const apply = (status: number, json: SystemApiResponse) => {
      if (!isCurrent()) return;
      if (
        status === 401 ||
        json.error?.code === "UNAUTHENTICATED" ||
        json.error?.code === "UNAUTHORIZED"
      ) {
        router.replace("/login?error=session");
        return;
      }
      setData(json);
      setState(json.ok ? "ready" : "error");
    };
    try {
      const result = await viewerCachedGet({
        key: "system",
        url: "/api/system",
        ttlMs: VIEWER_TTL.system,
        onRevalidated: ({ status, body }) => apply(status, body as SystemApiResponse),
      });
      apply(result.status, result.body as SystemApiResponse);
    } catch {
      if (!isCurrent()) return;
      setData(null);
      setState("error");
    }
  }, [router]);

  useEffect(() => {
    let disposed = false;
    // Subscribe after commit; cleanup fences cache and network completions alike.
    queueMicrotask(() => { if (!disposed) void load(() => !disposed); });
    return () => { disposed = true; };
  }, [load]);

  const staticInfo = data?.static;
  const server = data?.account_server;
  const online = server?.status === "online";
  const healthLoading = state === "loading";
  const envLabel = formatAccountServerEnvLabel(
    server?.env || staticInfo?.account_server_env || "unknown",
  );
  const contract =
    server?.contract ||
    staticInfo?.account_server_contract ||
    "v1.1.0-read-admin";
  const roles = staticInfo?.roles?.length ? staticInfo.roles : FALLBACK_ROLES;
  const limitations = staticInfo?.limitations?.length
    ? staticInfo.limitations
    : FALLBACK_LIMITATIONS;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Unified header */}
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">System</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Connection, access model, and current Viewer boundaries.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
          {envLabel}
        </span>
      </header>

      <div className="grid gap-5 md:grid-cols-2">
        <Section title="Connection">
          {healthLoading ? (
            <SkeletonBlock />
          ) : (
            <dl>
              <Row
                label="Account Server"
                value={
                  <span className="inline-flex items-center gap-2">
                    <StatusDot online={!!online} />
                    {online ? "Online" : "Unavailable"}
                  </span>
                }
              />
              <Row label="Account Server environment" value={envLabel} />
              <Row
                label="Account Server contract"
                value={
                  <span className="font-mono text-xs font-medium">{contract}</span>
                }
              />
              {online && server?.checked_at ? (
                <Row
                  label="Last successful check"
                  value={
                    <time
                      dateTime={server.checked_at}
                      className="tabular-nums font-normal text-[var(--muted)]"
                    >
                      {new Date(server.checked_at).toLocaleString(undefined, {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                        second: "2-digit",
                      })}
                    </time>
                  }
                />
              ) : null}
            </dl>
          )}

          {!healthLoading && !online ? (
            <p className="text-sm text-[var(--danger)]" role="status">
              Account Server unavailable. Local Viewer information below still
              applies.
            </p>
          ) : null}

          <button
            type="button"
            onClick={() => void load()}
            disabled={healthLoading}
            className="mt-3 rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-sm font-medium transition-colors duration-150 hover:bg-[var(--bg)] disabled:opacity-40"
          >
            {healthLoading ? "Checking…" : "Refresh status"}
          </button>
        </Section>

        <Section title="Signed-in account">
          {healthLoading && !data?.account ? (
            <SkeletonBlock />
          ) : data?.account ? (
            <dl>
              <Row label="Name" value={data.account.display_name} />
              <Row label="Username" value={data.account.username} />
              <Row label="Role" value={data.account.role_label} />
            </dl>
          ) : (
            <p className="text-[var(--muted)]">Account context unavailable.</p>
          )}
        </Section>

        <Section title="Access model">
          <dl>
            <Row
              label="Admin Viewer access"
              value={staticInfo?.viewer_access || VIEWER_ACCESS_TEXT}
            />
          </dl>
          <div className="mt-3">
            <p className="mb-2 text-xs font-medium tracking-wide text-[var(--muted)] uppercase">Account roles</p>
            <ul className="flex flex-wrap gap-2">
              {roles.map((r) => (
                <li
                  key={r.id}
                  className="rounded-full border border-[var(--line)] bg-[var(--bg)] px-2.5 py-1 text-xs font-medium text-[var(--ink)]"
                >
                  {r.label}
                </li>
              ))}
            </ul>
          </div>
        </Section>

        <Section title="Shops">
          {healthLoading ? (
            <SkeletonBlock />
          ) : data?.shops ? (
            <dl>
              <Row label="Total shops" value={data.shops.shops} />
              <Row label="Active shops" value={data.shops.active_shops} />
            </dl>
          ) : (
            <p className="text-[var(--muted)]">
              Shop summary is unavailable while the Account Server cannot be
              reached.
            </p>
          )}
        </Section>

        <Section title="Viewer">
          <dl>
            <Row
              label="Viewer deployment"
              value={data?.viewer.deployment || "Local"}
            />
            <Row label="Viewer version" value={data?.viewer.version || "0.1.0"} />
            {data?.viewer.commit ? (
              <Row
                label="Build"
                value={
                  <span className="font-mono text-xs font-medium">
                    {data.viewer.commit}
                  </span>
                }
              />
            ) : null}
          </dl>
          <p className="mt-2 text-xs text-[var(--muted)]">
            Viewer deployment is separate from the Account Server environment
            above.
          </p>
        </Section>

        <Section title="Keep-alive">
          <p className="text-[var(--ink)]">{staticInfo?.keep_alive || KEEP_ALIVE_SUMMARY}</p>
          <p className="mt-1 text-[var(--muted)]">
            {staticInfo?.keep_alive_note || KEEP_ALIVE_NOTE}
          </p>
        </Section>
      </div>

      <Section title="System Status">
        <p className="text-[var(--ink)]">{staticInfo?.system_message || SYSTEM_MESSAGE}</p>
      </Section>

      <Section title="Current limitations">
        <ul className="list-disc space-y-1.5 pl-5 text-[var(--muted)]">
          {limitations.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </Section>

      {state === "error" && !data ? (
        <p className="text-sm text-[var(--danger)]" role="alert">
          Live status could not be loaded. Static Viewer information above still
          applies.
        </p>
      ) : null}
    </div>
  );
}
