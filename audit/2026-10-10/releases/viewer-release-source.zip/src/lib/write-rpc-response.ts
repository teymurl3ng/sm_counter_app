/** SQL void RPCs acknowledge a committed write with HTTP 204 and no JSON. */
const VOID_WRITE_RPCS = new Set([
  "admin_disable_staff",
  "admin_enable_staff",
  "admin_set_role",
  "admin_assign_shop",
  "admin_unassign_shop",
  "admin_record_reset_credential_audit",
]);

export async function readSuccessfulWriteRpcResponse(
  response: Response,
  rpcName: string,
): Promise<unknown> {
  if (response.status === 204 && VOID_WRITE_RPCS.has(rpcName)) return null;
  // Identity/shop-returning writes still require JSON. An absent or malformed
  // result must retain the existing ambiguous-outcome handling.
  return response.json();
}
