import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { generateServerCredential, formatCredentialDisplay } from "./credential";

describe("Credential generator", () => {
  it("generates exactly 15 ASCII digits", () => {
    const cred = generateServerCredential();
    assert.equal(cred.length, 15);
    assert.match(cred, /^\d{15}$/);
  });

  it("can generate many credentials without throwing", () => {
    for (let i = 0; i < 1000; i++) {
      const cred = generateServerCredential();
      assert.equal(cred.length, 15);
    }
  });

  it("formats credential correctly", () => {
    assert.equal(formatCredentialDisplay("123456789012345"), "12345-67890-12345");
    assert.equal(formatCredentialDisplay("000000000000000"), "00000-00000-00000");
  });
});
