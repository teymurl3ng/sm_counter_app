import assert from "node:assert/strict";
import { it } from "node:test";
import { clearViewerCache, setViewerCacheSession, getViewerCacheSession, viewerCacheInvalidate, viewerCachePeek, viewerCachedGet } from "./viewer-cache";
const input = {key: "staff", url: "/api/staff?limit=20", ttlMs: 30_000};
it("invalidates logical keys by their actual request URLs", async () => {
  const original = globalThis.fetch;
  try {
    clearViewerCache(); setViewerCacheSession("alice");
    let calls = 0;
    globalThis.fetch = async () => Response.json({version: ++calls});
    await viewerCachedGet(input);
    viewerCacheInvalidate(["/api/staff"]);
    assert.equal(viewerCachePeek("staff"), null);
    assert.deepEqual((await viewerCachedGet(input)).body, {version: 2});
  } finally { globalThis.fetch = original; clearViewerCache(); }
});
it("a late old-session 401 cannot clear a new session", async () => {
  const original = globalThis.fetch;
  try {
    clearViewerCache(); setViewerCacheSession("alice");
    let finish!: (response: Response) => void;
    globalThis.fetch = () => new Promise(resolve => { finish = resolve; });
    const first = viewerCachedGet(input);
    const joined = viewerCachedGet(input);
    setViewerCacheSession("bob");
    finish(Response.json({error: "expired"}, {status: 401}));
    await Promise.all([first, joined]);
    assert.equal(getViewerCacheSession(), "bob");
  } finally { globalThis.fetch = original; clearViewerCache(); }
});
it("invalidation during a shared request refetches before publishing", async () => {
  const original = globalThis.fetch;
  try {
    clearViewerCache(); setViewerCacheSession("alice");
    let finish!: (response: Response) => void;
    let calls = 0;
    globalThis.fetch = () => ++calls === 1 ? new Promise(resolve => {finish = resolve;}) : Promise.resolve(Response.json({version: 2}));
    const first = viewerCachedGet(input); const joined = viewerCachedGet(input);
    viewerCacheInvalidate(["/api/staff"]);
    finish(Response.json({version: 1}));
    for (const result of await Promise.all([first, joined])) assert.deepEqual(result.body, {version: 2});
    assert.deepEqual(viewerCachePeek("staff"), {version: 2});
  } finally { globalThis.fetch = original; clearViewerCache(); }
});
