import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  deriveShopStatus,
  mapShopActivity,
  mapShopDetail,
  mapShopList,
  mapShopListItem,
} from "./shops";

describe("deriveShopStatus", () => {
  it("maps active/inactive", () => {
    assert.equal(deriveShopStatus(true), "Active");
    assert.equal(deriveShopStatus(false), "Inactive");
  });
});

describe("mapShopList", () => {
  const sample = {
    shop_id: "249b9c78-475d-483d-b252-314dc5784ff9",
    name: "Recovery Shop A",
    active: true,
    created_at: "2026-09-20T08:00:00Z",
    assigned_staff_count: 3,
  };

  it("maps valid shops", () => {
    const list = mapShopList([sample, { ...sample, shop_id: "b0f71866-8e0d-4138-af5e-c18356a9ab45", name: "Recovery Shop B", active: false, assigned_staff_count: 1 }]);
    assert.ok(list);
    assert.equal(list.length, 2);
    assert.equal(list[0].status, "Active");
    assert.equal(list[1].status, "Inactive");
    assert.equal(list[0].assigned_staff_count, 3);
  });

  it("maps empty list", () => {
    assert.deepEqual(mapShopList([]), []);
  });

  it("rejects malformed", () => {
    assert.equal(mapShopList(null), null);
    assert.equal(mapShopListItem({ name: "x" }), null);
  });
});

describe("mapShopDetail", () => {
  const shopId = "249b9c78-475d-483d-b252-314dc5784ff9";
  const ownerId = "11111111-1111-4111-8111-111111111111";
  const cashierId = "22222222-2222-4222-8222-222222222222";

  it("separates owners from assigned staff", () => {
    const d = mapShopDetail({
      shop_id: shopId,
      name: "Recovery Shop A",
      active: true,
      created_at: "2026-09-20T08:00:00Z",
      assigned_staff_count: 1,
      assigned_staff: [
        {
          staff_id: cashierId,
          username: "cash1",
          display_name: "Cash One",
          role: "cashier",
          active: true,
          terminated_at: null,
        },
        // If an owner somehow appears in assigned_staff, drop from assigned list
        {
          staff_id: ownerId,
          username: "own1",
          display_name: "Owner One",
          role: "owner",
          active: true,
          terminated_at: null,
        },
      ],
      owners: [
        {
          staff_id: ownerId,
          username: "own1",
          display_name: "Owner One",
          role: "owner",
          active: true,
          terminated_at: null,
        },
      ],
    });
    assert.ok(d);
    assert.equal(d.assigned_staff.length, 1);
    assert.equal(d.assigned_staff[0].username, "cash1");
    assert.equal(d.owners.length, 1);
    assert.equal(d.owners[0].role_label, "Owner");
    assert.equal(d.assigned_staff[0].status, "Active");
  });

  it("handles no assigned staff", () => {
    const d = mapShopDetail({
      shop_id: shopId,
      name: "Empty Shop",
      active: true,
      created_at: "2026-09-20T08:00:00Z",
      assigned_staff_count: 0,
      assigned_staff: [],
      owners: [
        {
          staff_id: ownerId,
          username: "own1",
          display_name: "Owner One",
          role: "owner",
          active: true,
          terminated_at: null,
        },
      ],
    });
    assert.ok(d);
    assert.equal(d.assigned_staff.length, 0);
    assert.equal(d.owners.length, 1);
  });

  it("maps disabled/terminated staff status", () => {
    const d = mapShopDetail({
      shop_id: shopId,
      name: "Shop",
      active: true,
      created_at: "2026-09-20T08:00:00Z",
      assigned_staff_count: 1,
      assigned_staff: [
        {
          staff_id: cashierId,
          username: "gone",
          display_name: "Gone",
          role: "cashier",
          active: false,
          terminated_at: "2026-09-21T00:00:00Z",
        },
      ],
      owners: [],
    });
    assert.ok(d);
    assert.equal(d.assigned_staff[0].status, "Terminated");
  });
});

describe("mapShopActivity", () => {
  const shopId = "249b9c78-475d-483d-b252-314dc5784ff9";
  const otherId = "b0f71866-8e0d-4138-af5e-c18356a9ab45";

  it("keeps only structured shop_id matches for shop actions", () => {
    const items = mapShopActivity(
      [
        {
          id: 1,
          at: "2026-09-20T10:00:00Z",
          action: "assign_shop",
          target_username: "ali",
          detail: { shop_id: shopId, shop: "Recovery Shop A" },
        },
        {
          id: 2,
          at: "2026-09-20T09:00:00Z",
          action: "assign_shop",
          target_username: "bob",
          detail: { shop_id: otherId, shop: "Recovery Shop B" },
        },
        {
          id: 3,
          at: "2026-09-20T08:00:00Z",
          action: "disable",
          target_username: "ali",
          detail: { staff_id: "x" },
        },
        {
          id: 4,
          at: "2026-09-20T07:00:00Z",
          action: "add_shop",
          target_username: null,
          detail: { shop_id: shopId, name: "Recovery Shop A" },
        },
      ],
      shopId,
      8,
    );
    assert.equal(items.length, 2);
    assert.equal(items[0].action, "assign_shop");
    assert.equal(items[1].action, "add_shop");
  });

  it("does not match on shop name alone", () => {
    const items = mapShopActivity(
      [
        {
          id: 1,
          at: "2026-09-20T10:00:00Z",
          action: "assign_shop",
          target_username: "ali",
          detail: { shop: "Recovery Shop A" },
        },
      ],
      shopId,
    );
    assert.equal(items.length, 0);
  });
});
