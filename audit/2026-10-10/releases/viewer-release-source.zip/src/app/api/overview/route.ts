import { fetchAdminOverview, pingAccountServer } from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { mapAdminOverview, type OverviewApiResponse } from "@/lib/overview";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { safeAccountServerMeta } from "@/lib/safe-meta";
import { clearViewerSession, readViewerSession } from "@/lib/session";

export const runtime = "nodejs";

/**
 * P1.1: useful RPC is primary; ping runs in parallel for health UI only.
 * Successful overview proves reachability even if ping fails transiently.
 */

function baseMeta() {
  return safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });
}

function withTiming(
  body: OverviewApiResponse,
  status: number,
  marks: Parameters<typeof timedJson>[2],
) {
  return timedJson(body, status, marks);
}

export async function GET() {
  const tTotal = nowMs();
  const meta = baseMeta();

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);

  if (!session) {
    const body: OverviewApiResponse = {
      ok: false,
      ...meta,
      server: { status: "unavailable", pingOk: false },
      overview: null,
      error: { code: "UNAUTHENTICATED", message: "Sign in required." },
    };
    return withTiming(body, 401, {
      label: "overview",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const tRpc = nowMs();
  const [overviewResult, ping] = await Promise.all([
    fetchAdminOverview(session.accessToken),
    pingAccountServer(),
  ]);
  const rpcWallMs = elapsedMs(tRpc);

  if (overviewResult.kind === "unauthorized") {
    await clearViewerSession();
    const body: OverviewApiResponse = {
      ok: false,
      ...meta,
      server: { status: ping.ok ? "online" : "unavailable", pingOk: ping.ok },
      overview: null,
      error: {
        code: "UNAUTHORIZED",
        message: "Session is no longer authorized for Overview.",
      },
    };
    return withTiming(body, 401, {
      label: "overview",
      sessionMs,
      pingMs: ping.durationMs,
      rpcMs: overviewResult.durationMs,
      extra: { rpc_wall: rpcWallMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  if (overviewResult.kind === "unreachable") {
    const body: OverviewApiResponse = {
      ok: false,
      ...meta,
      server: { status: "unavailable", pingOk: false },
      overview: null,
      error: {
        code: "SERVER_UNAVAILABLE",
        message: "Account Server could not be reached.",
      },
    };
    return withTiming(body, 503, {
      label: "overview",
      sessionMs,
      pingMs: ping.durationMs,
      rpcMs: overviewResult.durationMs,
      extra: { rpc_wall: rpcWallMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  if (overviewResult.kind !== "ok") {
    const body: OverviewApiResponse = {
      ok: false,
      ...meta,
      // Data RPC failed but we may still know reachability from ping.
      server: { status: ping.ok ? "online" : "unavailable", pingOk: ping.ok },
      overview: null,
      error: {
        code: "OVERVIEW_UNAVAILABLE",
        message: "Overview data is unavailable right now.",
      },
    };
    return withTiming(body, 502, {
      label: "overview",
      sessionMs,
      pingMs: ping.durationMs,
      rpcMs: overviewResult.durationMs,
      extra: { rpc_wall: rpcWallMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  const tMap = nowMs();
  const mapped = mapAdminOverview(overviewResult.data);
  const mapMs = elapsedMs(tMap);
  if (!mapped) {
    const body: OverviewApiResponse = {
      ok: false,
      ...meta,
      server: { status: "online", pingOk: ping.ok },
      overview: null,
      error: {
        code: "OVERVIEW_UNAVAILABLE",
        message: "Overview data is unavailable right now.",
      },
    };
    return withTiming(body, 502, {
      label: "overview",
      sessionMs,
      pingMs: ping.durationMs,
      rpcMs: overviewResult.durationMs,
      mapMs,
      extra: { rpc_wall: rpcWallMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  // Successful data RPC ⇒ online; pingOk is informational (may lag/fail independently).
  const body: OverviewApiResponse = {
    ok: true,
    ...meta,
    server: { status: "online", pingOk: ping.ok },
    overview: mapped,
    error: null,
  };
  return withTiming(body, 200, {
    label: "overview",
    sessionMs,
    pingMs: ping.durationMs,
    rpcMs: overviewResult.durationMs,
    mapMs,
    extra: { rpc_wall: rpcWallMs },
    totalMs: elapsedMs(tTotal),
  });
}
