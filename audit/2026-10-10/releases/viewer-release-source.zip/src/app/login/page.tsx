import { Suspense } from "react";
import { redirect } from "next/navigation";
import { LoginForm } from "./login-form";
import { readViewerSession } from "@/lib/session";
import { getAccountServerConfig } from "@/lib/config";
import { ThemeToggle } from "@/app/theme-toggle";

export default async function LoginPage() {
  const session = await readViewerSession();
  if (session) {
    redirect("/overview");
  }

  let envLabel = "DEV";
  try {
    const cfg = getAccountServerConfig();
    envLabel = cfg.env.toUpperCase();
  } catch {
    /* keep default */
  }

  return (
    <main className="relative mx-auto flex min-h-screen max-w-md flex-col justify-center gap-8 px-6 py-12">
      <div className="absolute right-4 top-4 sm:right-6 sm:top-6">
        <ThemeToggle />
      </div>
      <header className="space-y-3 text-center">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--accent)] shadow-sm">
          <span className="text-lg font-bold text-white">S</span>
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">
            Saaf Milk Admin
          </h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Sign in with your username and server credential.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-xs font-medium text-[var(--accent)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
          {envLabel} Environment
        </span>
      </header>
      <Suspense fallback={<p className="text-sm text-[var(--muted)]">Loading…</p>}>
        <LoginForm />
      </Suspense>
      <p className="text-center text-xs text-[var(--muted)]">
        Secure access for owners and admins.
      </p>
    </main>
  );
}
