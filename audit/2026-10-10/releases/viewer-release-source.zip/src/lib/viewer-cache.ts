/**
 * P1.3 — in-memory authenticated read cache (SWR + single-flight).
 * P1.5.1 — viewerCachePeek for instant paint on soft-nav.
 * Never persists to localStorage/sessionStorage/IndexedDB.
 */

export const VIEWER_TTL = {
  overview: 10_000,
  staffList: 10_000,
  shopsList: 30_000,
  activity: 10_000,
  system: 10_000,
  staffDetail: 10_000,
  shopDetail: 10_000,
} as const;

type CacheEntry = {
  url: string;
  status: number;
  body: unknown;
  fetchedAt: number;
  sessionId: string;
};

let activeSessionId: string | null = null;
let generation = 0;
const store = new Map<string, CacheEntry>();
const inflight = new Map<string, Promise<{ status: number; body: unknown }>>();

export function getViewerCacheSession(): string | null {
  return activeSessionId;
}

/** Bind cache to the signed-in identity. Clears if identity changes. */
export function setViewerCacheSession(sessionId: string): void {
  const id = sessionId.trim().toLowerCase();
  if (!id) return;
  if (activeSessionId && activeSessionId !== id) {
    generation += 1;
    store.clear();
    inflight.clear();
  }
  activeSessionId = id;
}

export function clearViewerCache(): void {
  generation += 1;
  store.clear();
  inflight.clear();
  activeSessionId = null;
}

/** Invalidate cache entries by prefix (e.g. "/api/admin/") */
export function viewerCacheInvalidate(prefixes: string[]): void {
  generation += 1;
  inflight.clear();
  for (const [key, entry] of store) {
    const path = entry.url;
    if (prefixes.some(p => path.startsWith(p))) {
      store.delete(key);
    }
  }
}

/**
 * P1.5.1 — Synchronous cache peek. Returns cached body if a fresh entry
 * exists for the current session, null otherwise. Does NOT fetch or
 * trigger revalidation. Used to skip loading skeletons on soft-nav.
 */
export function viewerCachePeek(key: string): unknown | null {
  const sessionId = activeSessionId;
  if (!sessionId) return null;
  const k = fullKey(key, sessionId);
  const hit = store.get(k);
  if (!hit || hit.sessionId !== sessionId) return null;
  const age = Date.now() - hit.fetchedAt;
  if (age > VIEWER_TTL.overview * 6) return null; // generous upper bound (60s)
  if (isAuthFailure(hit.status)) return null;
  return hit.body;
}

function fullKey(key: string, sessionId: string): string {
  return `${sessionId}::${key}`;
}

function isAuthFailure(status: number): boolean {
  return status === 401 || status === 403;
}

async function networkGet(url: string): Promise<{ status: number; body: unknown }> {
  const res = await fetch(url, { cache: "no-store" });
  const body: unknown = await res.json().catch(() => null);
  return { status: res.status, body };
}

/**
 * GET JSON with memory cache + single-flight + stale-while-revalidate.
 * Never caches 401/403 as success. Auth failures clear the cache.
 */
export async function viewerCachedGet(input: {
  key: string;
  url: string;
  ttlMs: number;
  /** When cache is stale, still return it and refresh in background. */
  onRevalidated?: (result: { status: number; body: unknown; fromCache: false }) => void;
}): Promise<{ status: number; body: unknown; fromCache: boolean }> {
  const sessionId = activeSessionId;
  if (!sessionId) {
    // No bound session — fetch without caching (login edge / race).
    const requestGeneration = generation;
    const fresh = await networkGet(input.url);
    if (activeSessionId || requestGeneration !== generation) return { status: 401, body: null, fromCache: false };
    if (requestGeneration === generation && !activeSessionId && isAuthFailure(fresh.status)) clearViewerCache();
    return { ...fresh, fromCache: false };
  }

  const k = fullKey(input.key, sessionId);
  const now = Date.now();
  const hit = store.get(k);

  if (hit && hit.sessionId === sessionId) {
    const age = now - hit.fetchedAt;
    if (age <= input.ttlMs) {
      return { status: hit.status, body: hit.body, fromCache: true };
    }
    // Stale: return immediately, revalidate once (single-flight).
    void revalidate(k, input.url, sessionId, input.onRevalidated);
    return { status: hit.status, body: hit.body, fromCache: true };
  }

  return fetchAndStore(k, input.url, sessionId);
}

async function revalidate(
  k: string,
  url: string,
  sessionId: string,
  onRevalidated?: (result: { status: number; body: unknown; fromCache: false }) => void,
): Promise<void> {
  const requestGeneration = generation;
  try {
    const result = await fetchAndStore(k, url, sessionId);
    if (requestGeneration === generation && activeSessionId === sessionId) {
      onRevalidated?.({ status: result.status, body: result.body, fromCache: false });
    }
  } catch {
    // Keep stale entry on network failure.
  }
}

async function fetchAndStore(
  k: string,
  url: string,
  sessionId: string,
): Promise<{ status: number; body: unknown; fromCache: boolean }> {
  const existing = inflight.get(k);
  const requestGeneration = generation;
  if (existing) {
    const shared = await existing;
    if (activeSessionId !== sessionId) return { status: 401, body: null, fromCache: false };
    if (requestGeneration !== generation) return fetchAndStore(k, url, sessionId);
    return { ...shared, fromCache: false };
  }

  const pending = networkGet(url).finally(() => {
    if (inflight.get(k) === pending) inflight.delete(k);
  });
  inflight.set(k, pending);
  const fresh = await pending;

  if (activeSessionId !== sessionId) return { status: 401, body: null, fromCache: false };
  if (requestGeneration !== generation) return fetchAndStore(k, url, sessionId);

  if (isAuthFailure(fresh.status)) {
    clearViewerCache();
    return { ...fresh, fromCache: false };
  }

  // Only cache successful JSON payloads (2xx).
  if (fresh.status >= 200 && fresh.status < 300) {
    store.set(k, {
      url,
      status: fresh.status,
      body: fresh.body,
      fetchedAt: Date.now(),
      sessionId,
    });
  }

  return { ...fresh, fromCache: false };
}

/** Test helpers */
export function _viewerCacheSizeForTests(): number {
  return store.size;
}
