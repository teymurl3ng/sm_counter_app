import { NextResponse } from "next/server";
import { fetchAdminListActivity } from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { safeAccountServerMeta } from "@/lib/safe-meta";
import { clearViewerSession, readViewerSession } from "@/lib/session";
import {
  ACTIVITY_PAGE_SIZE_DEFAULT,
  ACTIVITY_PAGE_SIZE_MAX,
  actionsForGroup,
  groupNeedsPostFilter,
  mapActivityList,
  parseActivityQuery,
  parseOptionalAction,
  rpcActionForGroup,
  type ActivityListApiResponse,
} from "@/lib/activity";

export const runtime = "nodejs";

function baseMeta() {
  return safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });
}

function emptyPage(limit: number, offset: number) {
  return { limit, offset, hasMore: false, count: 0 };
}

function fail(
  status: number,
  code: NonNullable<ActivityListApiResponse["error"]>["code"],
  message: string,
  meta: ReturnType<typeof baseMeta>,
  page = emptyPage(ACTIVITY_PAGE_SIZE_DEFAULT, 0),
  filters: ActivityListApiResponse["filters"] = {
    group: "all",
    target: null,
    from: null,
    to: null,
  },
  marks?: Parameters<typeof timedJson>[2],
) {
  const body: ActivityListApiResponse = {
    ok: false,
    ...meta,
    events: null,
    page,
    filters,
    group_post_filtered: false,
    error: { code, message },
  };
  if (marks) return timedJson(body, status, marks);
  return NextResponse.json(body, { status });
}

export async function GET(request: Request) {
  const tTotal = nowMs();
  const meta = baseMeta();
  const url = new URL(request.url);
  const parsed = parseActivityQuery(url);
  if (!parsed.ok) {
    return fail(400, "INVALID_REQUEST", parsed.message, meta);
  }

  const actionOpt = parseOptionalAction(url);
  if (actionOpt && typeof actionOpt === "object" && "error" in actionOpt) {
    return fail(400, "INVALID_REQUEST", actionOpt.error, meta);
  }

  const filters: ActivityListApiResponse["filters"] = {
    group: parsed.group,
    target: parsed.target,
    from: parsed.from,
    to: parsed.to,
  };
  const pageBase = emptyPage(parsed.limit, parsed.offset);

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);
  if (!session) {
    return fail(401, "UNAUTHENTICATED", "Sign in required.", meta, pageBase, filters, {
      label: "activity.list",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const rpcAction =
    typeof actionOpt === "string" ? actionOpt : rpcActionForGroup(parsed.group);

  const postFilter = !actionOpt && groupNeedsPostFilter(parsed.group);

  if (postFilter) {
    const groupActions = actionsForGroup(parsed.group) ?? [];
    const tRpc = nowMs();
    const results = await Promise.all(
      groupActions.map((action) =>
        fetchAdminListActivity(session.accessToken, {
          action,
          targetUsername: parsed.target,
          from: parsed.fromIso,
          to: parsed.toIso,
          limit: ACTIVITY_PAGE_SIZE_MAX,
          offset: 0,
        }),
      ),
    );
    const rpcWallMs = elapsedMs(tRpc);

    if (results.some((r) => r.kind === "unauthorized")) {
      await clearViewerSession();
      return fail(
        401,
        "UNAUTHORIZED",
        "Session is no longer authorized for Activity.",
        meta,
        pageBase,
        filters,
        {
          label: "activity.list.fanout",
          sessionMs,
          rpcMs: rpcWallMs,
          extra: { fanout_n: groupActions.length },
          totalMs: elapsedMs(tTotal),
        },
      );
    }

    if (results.some((r) => r.kind !== "ok")) {
      const unreachable = results.some((r) => r.kind === "unreachable");
      return fail(
        unreachable ? 503 : 502,
        unreachable ? "SERVER_UNAVAILABLE" : "ACTIVITY_UNAVAILABLE",
        unreachable
          ? "Account Server could not be reached."
          : "Activity is unavailable right now.",
        meta,
        pageBase,
        filters,
        {
          label: "activity.list.fanout",
          sessionMs,
          rpcMs: rpcWallMs,
          extra: { fanout_n: groupActions.length },
          totalMs: elapsedMs(tTotal),
        },
      );
    }

    const tMap = nowMs();
    const byId = new Map<string, NonNullable<ReturnType<typeof mapActivityList>>[number]>();
    let anyCapped = false;
    for (const r of results) {
      if (r.kind !== "ok") continue;
      const mapped = mapActivityList(r.data);
      if (!mapped) {
        return fail(
          502,
          "ACTIVITY_UNAVAILABLE",
          "Activity is unavailable right now.",
          meta,
          pageBase,
          filters,
        );
      }
      if (mapped.length >= ACTIVITY_PAGE_SIZE_MAX) anyCapped = true;
      for (const ev of mapped) byId.set(String(ev.id), ev);
    }

    const merged = [...byId.values()].sort((a, b) => {
      const atCmp = b.at.localeCompare(a.at);
      if (atCmp !== 0) return atCmp;
      return String(b.id).localeCompare(String(a.id));
    });
    const sliced = merged.slice(parsed.offset, parsed.offset + parsed.limit);
    const hasMore = merged.length > parsed.offset + parsed.limit || anyCapped;
    const mapMs = elapsedMs(tMap);

    const body: ActivityListApiResponse = {
      ok: true,
      ...meta,
      events: sliced,
      page: {
        limit: parsed.limit,
        offset: parsed.offset,
        hasMore,
        count: sliced.length,
      },
      filters,
      group_post_filtered: true,
      error: null,
    };
    return timedJson(body, 200, {
      label: "activity.list.fanout",
      sessionMs,
      rpcMs: rpcWallMs,
      mapMs,
      extra: { fanout_n: groupActions.length },
      totalMs: elapsedMs(tTotal),
    });
  }

  const result = await fetchAdminListActivity(session.accessToken, {
    action: rpcAction,
    targetUsername: parsed.target,
    from: parsed.fromIso,
    to: parsed.toIso,
    limit: parsed.limit,
    offset: parsed.offset,
  });

  if (result.kind === "unauthorized") {
    await clearViewerSession();
    return fail(
      401,
      "UNAUTHORIZED",
      "Session is no longer authorized for Activity.",
      meta,
      pageBase,
      filters,
      {
        label: "activity.list",
        sessionMs,
        rpcMs: result.durationMs,
        totalMs: elapsedMs(tTotal),
      },
    );
  }

  if (result.kind !== "ok") {
    return fail(
      result.kind === "unreachable" ? 503 : 502,
      result.kind === "unreachable" ? "SERVER_UNAVAILABLE" : "ACTIVITY_UNAVAILABLE",
      result.kind === "unreachable"
        ? "Account Server could not be reached."
        : "Activity is unavailable right now.",
      meta,
      pageBase,
      filters,
      {
        label: "activity.list",
        sessionMs,
        rpcMs: result.durationMs,
        totalMs: elapsedMs(tTotal),
      },
    );
  }

  const tMap = nowMs();
  const events = mapActivityList(result.data);
  const mapMs = elapsedMs(tMap);
  if (!events) {
    return fail(
      502,
      "ACTIVITY_UNAVAILABLE",
      "Activity is unavailable right now.",
      meta,
      pageBase,
      filters,
    );
  }

  const body: ActivityListApiResponse = {
    ok: true,
    ...meta,
    events,
    page: {
      limit: parsed.limit,
      offset: parsed.offset,
      hasMore: events.length >= parsed.limit,
      count: events.length,
    },
    filters,
    group_post_filtered: false,
    error: null,
  };
  return timedJson(body, 200, {
    label: "activity.list",
    sessionMs,
    rpcMs: result.durationMs,
    mapMs,
    totalMs: elapsedMs(tTotal),
  });
}
