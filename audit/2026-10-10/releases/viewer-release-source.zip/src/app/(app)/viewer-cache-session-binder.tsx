"use client";

import { useEffect } from "react";
import { setViewerCacheSession } from "@/lib/viewer-cache";

/** Binds in-memory Viewer cache to the authenticated username (session isolation). */
export function ViewerCacheSessionBinder({ username }: { username: string }) {
  useEffect(() => {
    if (username.trim()) {
      setViewerCacheSession(username);
    }
  }, [username]);
  return null;
}
