import { NextResponse, type NextRequest } from "next/server";

const PROTECTED_PREFIXES = [
  "/overview",
  "/staff",
  "/shops",
  "/activity",
  "/system",
];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some(
    (p) => pathname === p || pathname.startsWith(`${p}/`),
  );
  if (!isProtected) {
    return NextResponse.next();
  }

  const access = request.cookies.get("smav_access")?.value;
  const profile = request.cookies.get("smav_profile")?.value;
  if (!access || !profile) {
    const login = new URL("/login", request.url);
    // Only pass safe relative paths (defense in depth vs open redirect after login).
    if (
      pathname.startsWith("/") &&
      !pathname.startsWith("//") &&
      !pathname.includes("\\")
    ) {
      login.searchParams.set("next", pathname);
    }
    return NextResponse.redirect(login);
  }

  try {
    const parsed = JSON.parse(profile) as { role?: string; active?: boolean };
    if (parsed.active !== true || (parsed.role !== "owner" && parsed.role !== "admin")) {
      const denied = new URL("/login", request.url);
      denied.searchParams.set("error", "denied");
      const res = NextResponse.redirect(denied);
      res.cookies.delete("smav_access");
      res.cookies.delete("smav_refresh");
      res.cookies.delete("smav_profile");
      return res;
    }
  } catch {
    const login = new URL("/login", request.url);
    const res = NextResponse.redirect(login);
    res.cookies.delete("smav_access");
    res.cookies.delete("smav_refresh");
    res.cookies.delete("smav_profile");
    return res;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/overview/:path*", "/staff/:path*", "/shops/:path*", "/activity/:path*", "/system/:path*"],
};
