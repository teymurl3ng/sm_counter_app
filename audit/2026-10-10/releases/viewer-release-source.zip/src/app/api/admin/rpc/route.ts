import { requireMutationContext, parseMutationBody, mutationError, mutationSuccess } from "@/lib/admin-mutation";
import { ALLOWED_WRITE_RPCS, callWriteRpc, type AllowedWriteRpc } from "@/lib/account-server";
import { elapsedMs } from "@/lib/perf";
import { classifyRpcFailure } from "@/lib/admin-security";

export async function POST(request: Request) {
  const reqRes = await requireMutationContext(request);
  if (!reqRes.ok) return reqRes.response;
  const { ctx } = reqRes;

  const body = await parseMutationBody<{ rpc: AllowedWriteRpc; payload: Record<string, unknown> }>(request);
  
  if (!body?.rpc || !(ALLOWED_WRITE_RPCS as readonly string[]).includes(body.rpc)) {
    return mutationError(ctx.meta, "INVALID_REQUEST", "Invalid or missing RPC name.", 400, {
      label: "admin.rpc",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  // Certain DB-only RPCs can be called safely here using the user's JWT
  const rpcRes = await callWriteRpc(ctx.accessToken, body.rpc, body.payload || {});

  if (rpcRes.kind !== "ok") {
    const failure = rpcRes.kind === "unauthorized"
      ? { code: "FORBIDDEN" as const, status: rpcRes.status, message: "This operation is not permitted." }
      : rpcRes.kind === "error"
        ? classifyRpcFailure(rpcRes.body)
        : { code: "SERVER_UNAVAILABLE" as const, status: 503, message: "Account Server could not be reached." };

    return mutationError(ctx.meta, failure.code, failure.message, failure.status, {
      label: `admin.rpc.${body.rpc}`,
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  return mutationSuccess(
    ctx.meta,
    { ok: true, data: rpcRes.data },
    {
      label: `admin.rpc.${body.rpc}`,
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    }
  );
}
