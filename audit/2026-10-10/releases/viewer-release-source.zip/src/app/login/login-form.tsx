"use client";

import { FormEvent, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { safeNextPath } from "@/lib/safe-next";
import { clearViewerCache, setViewerCacheSession } from "@/lib/viewer-cache";

type LoginErrorCode =
  | "INVALID_CREDENTIALS"
  | "DISABLED"
  | "ROLE_DENIED"
  | "NOT_AUTHORIZED"
  | "UNKNOWN"
  | string;

export function LoginForm() {
  const router = useRouter();
  const search = useSearchParams();
  const [username, setUsername] = useState("");
  const [credential, setCredential] = useState("");
  const [showCred, setShowCred] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(
    search.get("error") === "denied"
      ? "This account does not have access to the Admin Viewer."
      : null,
  );
  const [code, setCode] = useState<LoginErrorCode | null>(
    search.get("error") === "denied" ? "ROLE_DENIED" : null,
  );

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    setCode(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, credential }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        code?: LoginErrorCode;
        message?: string;
        user?: { username?: string };
      };
      if (!res.ok || !data.ok) {
        setCode(data.code ?? "INVALID_CREDENTIALS");
        setMessage(data.message ?? "Could not sign in.");
        setCredential("");
        return;
      }
      clearViewerCache();
      if (data.user?.username) {
        setViewerCacheSession(data.user.username);
      } else if (username.trim()) {
        setViewerCacheSession(username.trim());
      }
      router.replace(safeNextPath(search.get("next")));
      router.refresh();
    } catch {
      setCode("UNKNOWN");
      setMessage("Account Server could not be reached.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="flex w-full flex-col gap-5">
      <label className="flex flex-col gap-1.5 text-sm">
        <span className="font-medium text-[var(--ink)]">Username</span>
        <input
          name="username"
          autoComplete="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2.5 text-[var(--ink)] placeholder:text-[var(--muted)]/60"
          required
          minLength={3}
          maxLength={32}
          disabled={loading}
          placeholder="Enter your username"
        />
      </label>

      <label className="flex flex-col gap-1.5 text-sm">
        <span className="font-medium text-[var(--ink)]">Server credential</span>
        <div className="flex gap-2">
          <input
            name="credential"
            type={showCred ? "text" : "password"}
            autoComplete="current-password"
            inputMode="numeric"
            value={credential}
            onChange={(e) => setCredential(e.target.value)}
            className="min-w-0 flex-1 rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 py-2.5 tracking-wide text-[var(--ink)] placeholder:text-[var(--muted)]/60"
            required
            maxLength={32}
            disabled={loading}
            placeholder="Enter server credential"
          />
          <button
            type="button"
            className="rounded-lg border border-[var(--line)] bg-[var(--card)] px-3.5 text-sm font-medium text-[var(--muted)] hover:bg-[var(--bg)]"
            onClick={() => setShowCred((v) => !v)}
            disabled={loading}
            aria-pressed={showCred}
            aria-label={showCred ? "Hide server credential" : "Show server credential"}
          >
            {showCred ? "Hide" : "Show"}
          </button>
        </div>
      </label>

      {message ? (
        <div
          role="alert"
          className="rounded-lg border px-3.5 py-2.5 text-sm"
          style={{
            borderColor: code === "UNKNOWN" ? "var(--warn)" : "var(--danger)",
            color: code === "UNKNOWN" ? "var(--warn)" : "var(--danger)",
            background: code === "UNKNOWN" ? "var(--orange-light)" : "var(--danger-bg)",
          }}
        >
          {message}
        </div>
      ) : null}

      <button
        type="submit"
        disabled={loading}
        className="mt-2 rounded-lg bg-[var(--accent)] px-4 py-3 text-sm font-semibold text-white shadow-sm transition-all duration-150 hover:bg-[var(--accent)]/80 hover:shadow-md active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? "Signing in…" : "Sign in"}
      </button>
    </form>
  );
}
