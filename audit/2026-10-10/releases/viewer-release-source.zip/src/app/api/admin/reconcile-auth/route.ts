import { requireMutationContext, mutationError, mutationSuccess } from "@/lib/admin-mutation";
import { callInternalRpc } from "@/lib/account-server";
import { safeCorrelationId } from "@/lib/admin-security";
import { getAdminKeyConfig, getAccountServerConfig } from "@/lib/config";
import { elapsedMs } from "@/lib/perf";
import { deleteAuthWithRetry, logOperationalFailure, parsePendingReconciliations } from "@/lib/reconciliation";

export async function POST(request: Request) {
  const requestResult = await requireMutationContext(request);
  if (!requestResult.ok) return requestResult.response;
  const { ctx } = requestResult;
  const correlationId = safeCorrelationId();

  if (ctx.profile.role !== "owner") {
    return mutationError(ctx.meta, "FORBIDDEN", "Only owners can run Auth reconciliation.", 403, {
      label: "admin.reconcileAuth",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }
  const adminKeyConfig = getAdminKeyConfig();
  if (!adminKeyConfig) {
    return mutationError(ctx.meta, "ADMIN_KEY_MISSING", "Account administration is unavailable.", 503, {
      label: "admin.reconcileAuth",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const pendingResult = await callInternalRpc(adminKeyConfig.adminKey, "admin_list_auth_reconciliation", {
    p_business_id: ctx.profile.business_id,
    p_limit: 20,
  });
  if (pendingResult.kind !== "ok") {
    logOperationalFailure("list_auth_reconciliation", correlationId, pendingResult.kind);
    return mutationError(ctx.meta, "SERVER_UNAVAILABLE", "Reconciliation records could not be loaded.", 503, {
      label: "admin.reconcileAuth",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const config = getAccountServerConfig();
  const rows = parsePendingReconciliations(pendingResult.data);
  let resolved = 0;
  let pending = 0;
  for (const row of rows) {
    if (row.operation === "reset_audit") {
      const auditResult = await callInternalRpc(adminKeyConfig.adminKey, "admin_reconcile_reset_audit", {
        p_reconciliation_id: row.id,
      });
      if (auditResult.kind === "ok") resolved += 1;
      else pending += 1;
      continue;
    }

    if (row.operation === "create_verify" || row.operation === "create_cleanup") {
      const verification = await callInternalRpc(adminKeyConfig.adminKey, "admin_verify_created_identity", {
        p_reconciliation_id: row.id,
      });
      // This read/reconcile RPC never authorizes automatic identity deletion.
      // Linked identities are recovered; unlinked/unknown identities require owner inspection.
      if (verification.kind === "ok" && verification.data === true) resolved += 1;
      else pending += 1;
      continue;
    }
    const cleanup = await deleteAuthWithRetry(adminKeyConfig.adminKey, config.url, row.auth_user_id);
    const updateResult = await callInternalRpc(adminKeyConfig.adminKey, "admin_update_auth_reconciliation", {
      p_reconciliation_id: row.id,
      p_resolved: cleanup.resolved,
      p_error_code: cleanup.resolved ? null : cleanup.errorCode,
    });
    if (cleanup.resolved && updateResult.kind === "ok") resolved += 1;
    else pending += 1;
  }

  if (pending > 0) {
    return mutationError(ctx.meta, "RECONCILIATION_REQUIRED", "Some Auth cleanup remains pending.", 503, {
      label: "admin.reconcileAuth",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }
  return mutationSuccess(
    ctx.meta,
    { processed: rows.length, resolved },
    { label: "admin.reconcileAuth", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) },
  );
}
