# Saaf Milk Admin Viewer — Performance (P1)

**Product:** Saaf Milk Admin Viewer (`sm-server-view`)  
**Baseline release:** `v1.0.0`  
**P1 release:** `v1.0.1`  
**Date:** 2026-09-21

Supabase / Account Server region was **not** changed (`ap-northeast-1`).

---

## Original architecture

1. Soft nav → dynamic RSC shell (`cookies()` in layout)
2. Client mount → `useEffect` → `GET /api/*` (`cache: "no-store"`)
3. API: **serial** `ping` then useful admin RPC(s)
4. Map JSON (~0ms) → paint

Vercel Functions defaulted to **`iad1`** (Washington, D.C.).

---

## Ping analysis (P1.1)

| Question | Finding |
|---|---|
| Health only? | Yes — `POST /rest/v1/rpc/ping` with publishable key |
| Auth / session init? | No |
| Mutations? | No |
| Required before admin RPC? | No — admin RPCs use the user access token |
| Authorization? | No — role gate is cookie + RPC JWT |

HTTP clients: per-request `fetch` (Node undici may keep-alive within the isolate). No custom pool added.

### Health semantics after P1.1

- **List/detail APIs:** no ping; `unreachable` on the data RPC ⇒ unavailable
- **Overview / System:** `Promise.all([dataRpc, ping])` — successful data ⇒ **online**; `pingOk` is informational and may fail without hiding data

### Detail parallelism

- **Shop detail:** `get_shop` ∥ `list_activity` (filter by URL `shopId`)
- **Staff detail:** `get_staff` then activity (needs `username` from get — documented dependency)

---

## Measurements (Pakistan audit host → Production)

Values are **medians**. Server totals from `Server-Timing`. Wall = full client HTTP time.

### A. Server-side API total (ms)

| Page | Baseline (serial ping, iad1) | After P1.1 (iad1) | After P1.2 (hnd1) |
|---|---|---|---|
| Overview | 860 | 638 | **32** |
| Staff | 883 | 624 | **33** |
| Shops | 871 | 393 | **23** |
| Activity | 449 | 226 | **25** |
| System | 439 | 422 | **30** |
| Staff Detail | (not in first baseline) | 462 | **64** |
| Shop Detail | (not in first baseline) | 442 | **32** |

### B. Client wall time for `/api/*` (ms)

| Page | Baseline | P1.1 iad1 | P1.2 hnd1 |
|---|---|---|---|
| Overview | 1505 | 1208 | **404** |
| Staff | 1459 | 1144 | **414** |
| Shops | 1292 | 831 | **395** |
| Activity | 880 | 684 | **405** |
| System | 1076 | 848 | **405** |

### C. Perceived HTML + API sequential (ms)

| Page | Baseline | P1.1 iad1 | P1.2 hnd1 |
|---|---|---|---|
| Overview | 1335 | 1628* | **843** |
| Staff | 1929 | 1098 | **840** |
| Shops | 1277 | 1200 | **908** |
| Activity | 1363 | 1109 | **831** |
| System | 1368 | 1529* | **856** |

\*P1.1 perceived numbers were noisy (HTML variance); Server-Timing is the reliable P1.1 signal.

### D. Account Server RPC from Vercel

| Path | Typical RPC duration |
|---|---|
| `iad1` → Tokyo | ~200–650ms |
| `hnd1` → Tokyo | **~20–45ms** |

### E. P1.3 warm cache (client memory) — Production browser

Measured on Production after login (Pakistan host). Soft-nav still downloads the RSC shell; data APIs are what the cache removes.

| Condition | `/api/*` network | Soft-nav shell (wall) | Data path |
|---|---|---|---|
| Cold (first visit in tab) | ~1× per page (~260–450ms wall) | ~800–900ms HTML+API (P1.2) | network |
| Warm revisit within TTL | **0** (Overview / Shops / Activity / System confirmed) | ~265–420ms shell only | **memory; ≪200ms after mount** |

TTL: overview/staff/activity/system/details **10s**; shops list **30s**.  
Keys include session username + query string / UUID. Cleared on login, logout, 401/403. Single-flight on concurrent misses. No `localStorage` / `sessionStorage` / IndexedDB.

Unit tests cover session isolation, single-flight, and no-store of 401.

---

## Optimizations applied

1. **P1.1** — Remove blocking ping; parallel Overview/System ping; parallel shop detail  
2. **P1.2** — `vercel.json` `"regions": ["hnd1"]` (Tokyo); reversible  
3. **P1.3** — In-memory SWR + session isolation + single-flight  

### P1.4 (RSC initial data) — **not implemented**

| Factor | Assessment |
|---|---|
| Remaining cold perceived | ~800–900ms (mostly PK↔edge HTML + API hops) |
| Estimated RSC gain | ~one fewer round trip (~300–450ms cold) |
| Complexity / risk | Medium (auth, cache, dual paths) |
| Decision | **Skip for P1** — warm cache + hnd1 already meet “admin feels fast” for revisits; cold floor is geographic to the user, not Tokyo DB |

Hover-prefetch: explicitly skipped in P1.

---

## Instrumentation retained

- `Server-Timing` on API responses (`session`, `ping`, `rpc`, `total`, …)
- `X-Perf-Audit: 1`
- `X-Vercel-Region-Hint` when `VERCEL_REGION` is set

Console `perf …` lines were removed after P1 measurements (noise). Temporary audit scripts were not committed.

---

## Region conclusion

> Is the Viewer now fast enough that migrating Supabase from Tokyo is unnecessary?

**Yes for current C0 usage.** Viewer API work inside Tokyo is ~20–45ms. Remaining latency for a user in Pakistan is primarily **Pakistan ↔ Vercel**, not Tokyo DB. Migrating Supabase would not remove that outer hop and is **not justified** by these measurements.

---

## Security / environment

- Preview remains **DEV**; Production remains **PROD**  
- Account Server unchanged  
- Read-only RPC allowlist unchanged  
- Cache never stores 401/403; cleared on logout / identity change  
