import { fetchAdminOverview, pingAccountServer } from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { mapAdminOverview } from "@/lib/overview";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { clearViewerSession, readViewerSession } from "@/lib/session";
import {
  buildSystemStatic,
  formatViewerDeploymentLabel,
  mapHealthStatus,
  mapSafeAccount,
  mapShopSummary,
  shortCommit,
  type SystemApiResponse,
} from "@/lib/system";

export const runtime = "nodejs";

const VIEWER_VERSION = "1.0.0";

/**
 * P1.1: ping and overview run in parallel.
 * Successful overview ⇒ Account Server online even if ping fails transiently.
 */

function viewerMeta(): SystemApiResponse["viewer"] {
  return {
    deployment: formatViewerDeploymentLabel(process.env.VERCEL_ENV),
    version: VIEWER_VERSION,
    commit: shortCommit(process.env.VERCEL_GIT_COMMIT_SHA),
  };
}

function staticFromConfig(): ReturnType<typeof buildSystemStatic> {
  try {
    const cfg = getAccountServerConfig();
    return buildSystemStatic({ env: cfg.env, contract: cfg.contract });
  } catch {
    return buildSystemStatic({
      env: "unknown",
      contract: "v1.1.0-read-admin",
    });
  }
}

export async function GET() {
  const tTotal = nowMs();
  const staticInfo = staticFromConfig();
  const viewer = viewerMeta();

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);
  if (!session) {
    const body: SystemApiResponse = {
      ok: false,
      account_server: {
        env: staticInfo.account_server_env,
        contract: staticInfo.account_server_contract,
        status: "unavailable",
        ping_ok: false,
        checked_at: null,
      },
      account: null,
      shops: null,
      viewer,
      static: staticInfo,
      error: { code: "UNAUTHENTICATED", message: "Sign in required." },
    };
    return timedJson(body, 401, {
      label: "system",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const account = mapSafeAccount(session.profile);

  const tRpc = nowMs();
  const [ping, overviewResult] = await Promise.all([
    pingAccountServer(),
    fetchAdminOverview(session.accessToken),
  ]);
  const rpcWallMs = elapsedMs(tRpc);

  if (overviewResult.kind === "unauthorized") {
    await clearViewerSession();
    const health = mapHealthStatus({ pingOk: ping.ok, at: ping.at ?? null });
    const body: SystemApiResponse = {
      ok: false,
      account_server: {
        env: staticInfo.account_server_env,
        contract: staticInfo.account_server_contract,
        ...health,
      },
      account,
      shops: null,
      viewer,
      static: staticInfo,
      error: {
        code: "UNAUTHORIZED",
        message: "Session is no longer authorized.",
      },
    };
    return timedJson(body, 401, {
      label: "system",
      sessionMs,
      pingMs: ping.durationMs,
      rpcMs: overviewResult.durationMs,
      extra: { rpc_wall: rpcWallMs },
      totalMs: elapsedMs(tTotal),
    });
  }

  let shops: SystemApiResponse["shops"] = null;
  if (overviewResult.kind === "ok") {
    shops = mapShopSummary(mapAdminOverview(overviewResult.data));
  }

  // Online if data RPC succeeded OR ping succeeded; ping_ok reflects ping alone.
  const dataOnline = overviewResult.kind === "ok";
  const health = mapHealthStatus({
    pingOk: dataOnline || ping.ok,
    at: ping.ok ? (ping.at ?? null) : null,
  });
  // Override status: prefer data success as online
  const account_server: SystemApiResponse["account_server"] = {
    env: staticInfo.account_server_env,
    contract: staticInfo.account_server_contract,
    status: dataOnline || ping.ok ? "online" : "unavailable",
    ping_ok: ping.ok,
    checked_at: ping.ok ? (ping.at ?? null) : null,
  };
  void health;

  const body: SystemApiResponse = {
    ok: true,
    account_server,
    account,
    shops,
    viewer,
    static: staticInfo,
    error: null,
  };
  return timedJson(body, 200, {
    label: "system",
    sessionMs,
    pingMs: ping.durationMs,
    rpcMs: overviewResult.durationMs,
    extra: { rpc_wall: rpcWallMs },
    totalMs: elapsedMs(tTotal),
  });
}
