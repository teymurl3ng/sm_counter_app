import { ALLOWED_VIEWER_ROLES, type AuthOutcome, type SessionProfile } from "./types";

/**
 * Decide Viewer access from Auth + my_profile results.
 * Pure function for unit tests — no I/O.
 */
export function decideViewerAccess(
  authOk: boolean,
  invalidCredentials: boolean,
  profile: SessionProfile | null | undefined,
  networkError?: string,
): AuthOutcome {
  if (networkError) {
    return { kind: "UNKNOWN", message: networkError };
  }
  if (invalidCredentials || !authOk) {
    return { kind: "INVALID_CREDENTIALS" };
  }
  if (profile == null) {
    return { kind: "NOT_AUTHORIZED" };
  }
  if (profile.terminated_at != null) {
    // Should rarely happen after normal terminate (Auth deleted); treat as deny.
    return { kind: "INVALID_CREDENTIALS" };
  }
  if (profile.active !== true) {
    return { kind: "DISABLED", profile };
  }
  if (!ALLOWED_VIEWER_ROLES.has(profile.role)) {
    return { kind: "ROLE_DENIED", profile };
  }
  // Tokens filled by caller
  return {
    kind: "ALLOWED",
    profile,
    accessToken: "",
    refreshToken: null,
    expiresIn: null,
  };
}
