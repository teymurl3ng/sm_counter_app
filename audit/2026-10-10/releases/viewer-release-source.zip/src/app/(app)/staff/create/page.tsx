"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { formatCredentialDisplay } from "@/lib/credential";
import { viewerCacheInvalidate } from "@/lib/viewer-cache";
import { STAFF_ROLES } from "@/lib/staff-status";

export default function CreateStaffPage() {
  const [shops, setShops] = useState<{ shop_id: string; name: string }[]>([]);
  const [loadingShops, setLoadingShops] = useState(true);

  // Form state
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState("operator");
  const [selectedShops, setSelectedShops] = useState<string[]>([]);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [result, setResult] = useState<{ staff_id: string; credential: string } | null>(null);

  useEffect(() => {
    async function loadShops() {
      try {
        const res = await fetch("/api/shops?limit=100");
        const json = await res.json();
        if (json.ok && json.shops) setShops(json.shops);
      } catch {
        // ignore
      } finally {
        setLoadingShops(false);
      }
    }
    void loadShops();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!username.trim() || !displayName.trim()) {
      setError("Username and Display Name are required.");
      return;
    }
    if (role !== "owner" && selectedShops.length === 0) {
      setError("Non-owners must be assigned to at least one shop.");
      return;
    }
    
    setIsSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/create-staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          display_name: displayName.trim(),
          role,
          shop_ids: role === "owner" ? [] : selectedShops,
        }),
      });
      const json = await res.json();
      if (!json.ok) {
        setError(json.error?.message || "Failed to create staff.");
      } else {
        viewerCacheInvalidate(["/api/staff"]);
        setResult({ staff_id: json.staff_id, credential: json.credential });
      }
    } catch {
      setError("Network error.");
    } finally {
      setIsSubmitting(false);
    }
  }

  function toggleShop(id: string) {
    setSelectedShops(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  if (result) {
    return (
      <div className="mx-auto max-w-2xl space-y-6">
        <section className="rounded-xl border border-[var(--success)]/30 bg-[#e6f4ea] p-6 text-center dark:bg-[#1e2e22]">
          <h1 className="text-2xl font-bold text-[#137333] dark:text-[#81c995]">Staff Created Successfully</h1>
          <p className="mt-2 text-sm text-[var(--ink)]">Please provide this temporary credential to the user.</p>
          
          <div className="mt-6 inline-block rounded-xl border-2 border-dashed border-[#137333]/30 bg-white p-6 dark:bg-black/20">
            <p className="font-mono text-3xl font-bold tracking-widest text-[var(--ink)]">
              {formatCredentialDisplay(result.credential)}
            </p>
          </div>
          
          <p className="mt-6 text-sm font-medium text-[var(--danger)]">
            Warning: This credential will never be shown again. Ensure it is copied before leaving this page.
          </p>
          
          <div className="mt-8">
            <Link
              href={`/staff/${result.staff_id}`}
              className="rounded-lg bg-[var(--ink)] px-6 py-2 text-sm font-medium text-[var(--bg)] hover:opacity-90"
            >
              View Profile
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <Link
          href="/staff"
          className="inline-flex items-center gap-1 text-sm font-medium text-[var(--accent)] transition-colors duration-150 hover:text-[#025a8a]"
        >
          ← Back to Staff
        </Link>
      </div>
      
      <header>
        <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">Create Staff</h1>
      </header>

      <form onSubmit={handleSubmit} className="space-y-6 rounded-xl border border-[var(--line)] bg-[var(--card)] p-5">
        {error && (
          <div className="rounded-md bg-[var(--danger-bg)] p-3 text-sm text-[var(--danger)]">
            {error}
          </div>
        )}
        
        <div>
          <label className="mb-1 block text-sm font-medium text-[var(--ink)]">Username</label>
          <input
            type="text"
            required
            value={username}
            onChange={e => setUsername(e.target.value)}
            className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2 text-sm text-[var(--ink)] focus:border-[var(--accent)] focus:outline-none"
            placeholder="e.g. john.doe"
          />
        </div>
        
        <div>
          <label className="mb-1 block text-sm font-medium text-[var(--ink)]">Display Name</label>
          <input
            type="text"
            required
            value={displayName}
            onChange={e => setDisplayName(e.target.value)}
            className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2 text-sm text-[var(--ink)] focus:border-[var(--accent)] focus:outline-none"
            placeholder="e.g. John Doe"
          />
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium text-[var(--ink)]">Role</label>
          <select
            value={role}
            onChange={e => setRole(e.target.value)}
            className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2 text-sm text-[var(--ink)] focus:border-[var(--accent)] focus:outline-none"
          >
            {STAFF_ROLES.map(r => (
              <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
            ))}
          </select>
        </div>

        {role !== "owner" && (
          <div>
            <label className="mb-1 block text-sm font-medium text-[var(--ink)]">Shops (Select at least one)</label>
            {loadingShops ? (
              <p className="text-sm text-[var(--muted)]">Loading shops...</p>
            ) : shops.length === 0 ? (
              <p className="text-sm text-[var(--muted)]">No shops available.</p>
            ) : (
              <div className="max-h-48 overflow-y-auto rounded border border-[var(--line)] p-2">
                {shops.map(s => (
                  <label key={s.shop_id} className="flex items-center gap-2 p-1">
                    <input
                      type="checkbox"
                      checked={selectedShops.includes(s.shop_id)}
                      onChange={() => toggleShop(s.shop_id)}
                      className="rounded border-[var(--line)] text-[var(--accent)]"
                    />
                    <span className="text-sm text-[var(--ink)]">{s.name}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded-lg bg-[var(--ink)] py-2 text-sm font-medium text-[var(--bg)] hover:opacity-90 disabled:opacity-50"
        >
          {isSubmitting ? "Creating..." : "Create Staff Account"}
        </button>
      </form>
    </div>
  );
}
