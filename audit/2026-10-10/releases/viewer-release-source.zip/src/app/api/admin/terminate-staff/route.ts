import { requireMutationContext, parseMutationBody, mutationError, mutationSuccess } from "@/lib/admin-mutation";
import { getAdminKeyConfig, getAccountServerConfig } from "@/lib/config";
import { callWriteRpc } from "@/lib/account-server";
import { classifyRpcFailure, isUuid, safeCorrelationId } from "@/lib/admin-security";
import { validateUsername } from "@/lib/validation";
import { elapsedMs } from "@/lib/perf";
import { deleteAuthWithRetry, logOperationalFailure, recordReconciliation } from "@/lib/reconciliation";

export async function POST(request: Request) {
  const reqRes = await requireMutationContext(request);
  if (!reqRes.ok) return reqRes.response;
  const { ctx } = reqRes;
  const correlationId = safeCorrelationId();

  if (ctx.profile.role !== "owner") {
    return mutationError(ctx.meta, "FORBIDDEN", "Only owners can terminate accounts", 403, {
      label: "admin.terminateStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const body = await parseMutationBody<{ staff_id?: string; confirm_username?: string }>(request);
  const uVal = validateUsername(body?.confirm_username);

  if (!isUuid(body?.staff_id) || !uVal.valid) {
    return mutationError(ctx.meta, "INVALID_REQUEST", uVal.error || "Missing staff_id.", 400, {
      label: "admin.terminateStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const adminKeyCfg = getAdminKeyConfig();
  if (!adminKeyCfg) {
    return mutationError(
      ctx.meta,
      "ADMIN_KEY_MISSING",
      "Account Server Admin Key is not configured for this environment.",
      503,
      { label: "admin.terminateStaff", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) }
    );
  }

  // 1. Call DB RPC (enforces owner-only, last-owner lock, validates confirm_username, does update)
  const rpcRes = await callWriteRpc(ctx.accessToken, "admin_terminate_staff_db", {
    p_staff_id: body.staff_id,
    p_confirm_username: uVal.normalized,
  });

  if (rpcRes.kind !== "ok") {
    // If it's a 403, pass it through. If it's 400 (e.g. from P0001 last owner exception)
    const failure = rpcRes.kind === "unauthorized"
      ? { code: "FORBIDDEN" as const, status: rpcRes.status, message: "This operation is not permitted." }
      : rpcRes.kind === "error"
        ? classifyRpcFailure(rpcRes.body)
        : { code: "SERVER_UNAVAILABLE" as const, status: 503, message: "Account Server could not be reached." };
    return mutationError(ctx.meta, failure.code, failure.message, failure.status, {
      label: "admin.terminateStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    });
  }

  const oldAuthUserId = rpcRes.data as string | null;

  // 2. Delete Auth identity; persist any unresolved cleanup before responding.
  if (oldAuthUserId) {
    const cfg = getAccountServerConfig();
    const cleanup = await deleteAuthWithRetry(adminKeyCfg.adminKey, cfg.url, oldAuthUserId);
    if (!cleanup.resolved) {
      const recorded = await recordReconciliation({
        adminKey: adminKeyCfg.adminKey,
        businessId: ctx.profile.business_id,
        operation: "terminate_cleanup",
        authUserId: oldAuthUserId,
        targetUsername: uVal.normalized,
        performedBy: ctx.profile.staff_id,
        performedByUsername: ctx.profile.username,
        errorCode: cleanup.errorCode,
        correlationId,
      });
      logOperationalFailure("terminate_staff_cleanup", correlationId, recorded ? "PENDING" : "RECORD_FAILED");
      return mutationError(
        ctx.meta,
        recorded ? "RECONCILIATION_REQUIRED" : "INTERNAL_ERROR",
        recorded
          ? "The staff account is revoked, but Auth cleanup still requires reconciliation."
          : "The staff account is revoked, but its cleanup state could not be recorded.",
        503,
        { label: "admin.terminateStaff", sessionMs: ctx.sessionMs, totalMs: elapsedMs(ctx.tTotal) },
      );
    }
  }

  return mutationSuccess(
    ctx.meta,
    { ok: true, staff_id: body.staff_id },
    {
      label: "admin.terminateStaff",
      sessionMs: ctx.sessionMs,
      totalMs: elapsedMs(ctx.tTotal),
    }
  );
}
