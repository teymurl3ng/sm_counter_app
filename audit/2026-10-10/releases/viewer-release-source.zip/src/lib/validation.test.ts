import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { validateUsername, validateDisplayName, validateRole, validateShops } from "./validation";

describe("Validation", () => {
  it("validates username", () => {
    assert.equal(validateUsername("test_user").valid, true);
    assert.equal(validateUsername("test_user").normalized, "test_user");
    assert.equal(validateUsername("Test_User ").normalized, "test_user");
    assert.equal(validateUsername("te").valid, false);
    assert.equal(validateUsername("invalid!").valid, false);
  });

  it("validates display name", () => {
    assert.equal(validateDisplayName("Test Name").valid, true);
    assert.equal(validateDisplayName("Test Name").normalized, "Test Name");
    assert.equal(validateDisplayName(" A").valid, false);
  });

  it("validates role", () => {
    assert.equal(validateRole("admin").valid, true);
    assert.equal(validateRole("cashier").valid, true);
    assert.equal(validateRole("invalid").valid, false);
  });

  it("validates shops", () => {
    assert.equal(validateShops("owner", []).valid, true);
    assert.equal(validateShops("owner", undefined).valid, true);
    assert.equal(validateShops("admin", []).valid, false);
    const shopId = "123e4567-e89b-42d3-a456-426614174000";
    assert.equal(validateShops("admin", [shopId]).valid, true);
    assert.equal(validateShops("admin", ["shop1"]).valid, false);
    assert.equal(validateShops("admin", [shopId, shopId]).valid, false);
    assert.equal(validateShops("admin", "not-an-array").valid, false);
  });
});
