import { fetchAdminListShops } from "@/lib/account-server";
import { getAccountServerConfig } from "@/lib/config";
import { elapsedMs, nowMs } from "@/lib/perf";
import { timedJson } from "@/lib/perf-response";
import { safeAccountServerMeta } from "@/lib/safe-meta";
import { clearViewerSession, readViewerSession } from "@/lib/session";
import {
  mapShopList,
  SHOP_PAGE_SIZE_DEFAULT,
  SHOP_PAGE_SIZE_MAX,
  type ShopListApiResponse,
} from "@/lib/shops";

export const runtime = "nodejs";

function baseMeta() {
  return safeAccountServerMeta(() => {
    const cfg = getAccountServerConfig();
    return { env: cfg.env, contract: cfg.contract };
  });
}

function parsePaging(url: URL):
  | { ok: true; limit: number; offset: number }
  | { ok: false; message: string } {
  let limit = SHOP_PAGE_SIZE_DEFAULT;
  const limitRaw = url.searchParams.get("limit");
  if (limitRaw != null && limitRaw !== "") {
    const n = Number.parseInt(limitRaw, 10);
    if (!Number.isFinite(n)) return { ok: false, message: "Invalid limit." };
    limit = Math.max(1, Math.min(SHOP_PAGE_SIZE_MAX, n));
  }
  let offset = 0;
  const offsetRaw = url.searchParams.get("offset");
  if (offsetRaw != null && offsetRaw !== "") {
    const n = Number.parseInt(offsetRaw, 10);
    if (!Number.isFinite(n) || n < 0) return { ok: false, message: "Invalid offset." };
    offset = Math.min(n, 100_000);
  }
  return { ok: true, limit, offset };
}

export async function GET(request: Request) {
  const tTotal = nowMs();
  const meta = baseMeta();
  const paging = parsePaging(new URL(request.url));
  if (!paging.ok) {
    const body: ShopListApiResponse = {
      ok: false,
      ...meta,
      shops: null,
      page: { limit: SHOP_PAGE_SIZE_DEFAULT, offset: 0, hasMore: false, count: 0 },
      error: { code: "INVALID_REQUEST", message: paging.message },
    };
    return timedJson(body, 400, { label: "shops.list", totalMs: elapsedMs(tTotal) });
  }

  const tSession = nowMs();
  const session = await readViewerSession();
  const sessionMs = elapsedMs(tSession);
  if (!session) {
    const body: ShopListApiResponse = {
      ok: false,
      ...meta,
      shops: null,
      page: {
        limit: paging.limit,
        offset: paging.offset,
        hasMore: false,
        count: 0,
      },
      error: { code: "UNAUTHENTICATED", message: "Sign in required." },
    };
    return timedJson(body, 401, {
      label: "shops.list",
      sessionMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const result = await fetchAdminListShops(
    session.accessToken,
    paging.limit,
    paging.offset,
  );

  if (result.kind === "unauthorized") {
    await clearViewerSession();
    const body: ShopListApiResponse = {
      ok: false,
      ...meta,
      shops: null,
      page: {
        limit: paging.limit,
        offset: paging.offset,
        hasMore: false,
        count: 0,
      },
      error: {
        code: "UNAUTHORIZED",
        message: "Session is no longer authorized for Shops.",
      },
    };
    return timedJson(body, 401, {
      label: "shops.list",
      sessionMs,
      rpcMs: result.durationMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  if (result.kind !== "ok") {
    const body: ShopListApiResponse = {
      ok: false,
      ...meta,
      shops: null,
      page: {
        limit: paging.limit,
        offset: paging.offset,
        hasMore: false,
        count: 0,
      },
      error: {
        code: result.kind === "unreachable" ? "SERVER_UNAVAILABLE" : "SHOPS_UNAVAILABLE",
        message:
          result.kind === "unreachable"
            ? "Account Server could not be reached."
            : "Shop list is unavailable right now.",
      },
    };
    return timedJson(body, result.kind === "unreachable" ? 503 : 502, {
      label: "shops.list",
      sessionMs,
      rpcMs: result.durationMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const tMap = nowMs();
  const shops = mapShopList(result.data);
  const mapMs = elapsedMs(tMap);
  if (!shops) {
    const body: ShopListApiResponse = {
      ok: false,
      ...meta,
      shops: null,
      page: {
        limit: paging.limit,
        offset: paging.offset,
        hasMore: false,
        count: 0,
      },
      error: {
        code: "SHOPS_UNAVAILABLE",
        message: "Shop list is unavailable right now.",
      },
    };
    return timedJson(body, 502, {
      label: "shops.list",
      sessionMs,
      rpcMs: result.durationMs,
      mapMs,
      totalMs: elapsedMs(tTotal),
    });
  }

  const body: ShopListApiResponse = {
    ok: true,
    ...meta,
    shops,
    page: {
      limit: paging.limit,
      offset: paging.offset,
      hasMore: shops.length >= paging.limit,
      count: shops.length,
    },
    error: null,
  };
  return timedJson(body, 200, {
    label: "shops.list",
    sessionMs,
    rpcMs: result.durationMs,
    mapMs,
    totalMs: elapsedMs(tTotal),
  });
}
