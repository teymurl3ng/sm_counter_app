import { Suspense } from "react";
import { StaffListPanel } from "./staff-list-panel";

export default function StaffPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-5xl space-y-6">
          <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] pb-4">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-[var(--ink)]">Staff</h1>
              <p className="mt-1 text-sm text-[var(--muted)]">Loading staff…</p>
            </div>
          </header>
          <div className="space-y-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-14 animate-pulse rounded-xl border border-[var(--line)] bg-[var(--card)]" />
            ))}
          </div>
        </div>
      }
    >
      <StaffListPanel />
    </Suspense>
  );
}
