# Saaf Milk Admin Viewer

Administrative UI for the **Saaf Milk Account Server**.

This product shows identity, staff status, shops, and audit visibility. It is **not** an ERP dashboard.

## Product: C0 reads + C1 write administration (contract `v1.2.0-write-admin`)

**Saaf Milk Admin Viewer — identity visibility (C0) + staff write administration (C1)**

- Separate repository from the Account Server
- Next.js App Router + TypeScript
- Login for **owner** and **admin** only
- Secure httpOnly session cookies
- Features: **Overview**, **Staff**, **Shops**, **Activity**, **System**
- C0: identity/shops/audit reads; C1: create staff, disable/enable, role change, shop assignment, credential reset, termination, Auth reconciliation

Account Server contract: `v1.2.0-write-admin`

## Environments

| Hosting | Account Server |
|---|---|
| Local development | **DEV** |
| Vercel Preview | **DEV** |
| Vercel Production (`https://sm-server-view.vercel.app`) | **PROD** |

Configuration fails closed if `ACCOUNT_SERVER_ENV` is missing or mismatched to the hosting channel.

## Warning — privileged keys

**Never** add a Supabase privileged/admin/`sb_secret_*` key to this project, Vercel, or browser code.

This product uses only:

- Account Server URL
- Publishable/client key
- `ACCOUNT_SERVER_ENV` (`dev` or `prod`)
- Contract label + fake Auth domain

## Local setup

1. Copy `.env.example` → `.env.local` with **DEV** values (`ACCOUNT_SERVER_ENV=dev`).
2. `npm install`
3. `npm run dev`
4. Open http://localhost:3000

## Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Local development (DEV Account Server) |
| `npm run build` | Production build |
| `npm start` | Run production build |
| `npm test` | Unit tests |
| `npm run lint` | ESLint (known tooling issue — see SECURITY-REVIEW.md) |
| `npm run security:scan` | Local secret / dependency checks |

## Auth model (summary)

1. Username + server credential (normalized per Account Server CONTRACT)
2. Password grant against Account Server Auth
3. `my_profile` must be active owner/admin
4. Session stored in httpOnly cookies (`smav_access`, `smav_profile`)
5. Server credential is never persisted after the login request

## Deployment

- **GitHub repo:** `teymurl3ng/sm-server-view` (private)
- **Vercel project:** `mkrc/sm-server-view`
- **Production URL:** https://sm-server-view.vercel.app

Preferred: GitHub App linked so `main` → Production and branches/PRs → Preview (DEV).

If Git auto-deploy is unavailable, release with:

```bash
npx vercel deploy --prod
```

Preview (DEV) check:

```bash
npx vercel deploy
```

See `SECURITY-REVIEW.md` for security architecture and C0.7–C0.8 audit notes.

See `PERFORMANCE.md` for P1 navigation timing and optimization notes.

## Non-goals (C0)

- No staff/shop writes
- No ERP / sales / inventory
- No Google Drive / backup management
- No Android device management
- No account recovery UI

Write administration is a future **C1** phase.

## Related products

| Product | Responsibility |
|---|---|
| Saaf Milk Account Server | Identity source of truth + admin RPCs |
| Saaf Milk Admin Viewer | Human-friendly admin UI: C0 reads + C1 write administration (this repo) |
| Saaf Milk Android ERP | Business operations (separate) |

