import Link from "next/link";
import { redirect } from "next/navigation";
import { readViewerSession } from "@/lib/session";
import { getAccountServerConfig } from "@/lib/config";
import { LogoutButton } from "./logout-button";
import { ViewerCacheSessionBinder } from "./viewer-cache-session-binder";
import { NavHighlight } from "./nav-highlight";
import { ThemeToggle } from "@/app/theme-toggle";

const NAV = [
  { href: "/overview", label: "Overview" },
  { href: "/staff", label: "Staff" },
  { href: "/shops", label: "Shops" },
  { href: "/activity", label: "Activity" },
  { href: "/system", label: "System" },
] as const;

export default async function AppShellLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await readViewerSession();
  if (!session) {
    redirect("/login");
  }
  if (
    session.profile.active !== true ||
    (session.profile.role !== "owner" && session.profile.role !== "admin")
  ) {
    redirect("/login?error=denied");
  }

  let envLabel = "UNKNOWN";
  let contract = "v1.1.0-read-admin";
  try {
    const cfg = getAccountServerConfig();
    envLabel = cfg.env.toUpperCase();
    contract = cfg.contract;
  } catch {
    /* keep UNKNOWN */
  }

  const initials = session.profile.display_name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="min-h-screen md:grid md:grid-cols-[240px_1fr]">
      <ViewerCacheSessionBinder username={session.profile.username} />
      <NavHighlight />
      <aside className="border-b border-[var(--line)] bg-[var(--card)] md:border-b-0 md:border-r">
        <div className="flex flex-col gap-0 p-4 md:min-h-screen">
          {/* Brand */}
          <div className="flex items-center gap-3 px-2 pb-5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[var(--accent)] text-sm font-bold text-white">
              S
            </div>
            <div>
              <p className="text-sm font-semibold text-[var(--ink)]">Saaf Milk</p>
              <p className="text-xs text-[var(--muted)]">Admin Viewer</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex gap-1 overflow-x-auto px-1 pb-4 md:flex-col md:overflow-visible">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="nav-item whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-[var(--muted)] transition-colors duration-150 hover:bg-[var(--accent-light)] hover:text-[var(--accent)]"
                data-active="false"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Divider */}
          <div className="mx-2 border-t border-[var(--line)]" />

          {/* User section */}
          <div className="mt-4 space-y-3 px-2">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--accent-light)] text-xs font-semibold text-[var(--accent)]">
                {initials || "U"}
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-[var(--ink)]">
                  {session.profile.display_name}
                </p>
                <p className="truncate text-xs text-[var(--muted)]">
                  {session.profile.username} · {session.profile.role}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-2.5 py-0.5 text-xs font-medium text-[var(--accent)]">
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                {envLabel}
              </span>
              <span className="text-xs text-[var(--muted)]">{contract}</span>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle className="flex-shrink-0" />
              <LogoutButton />
            </div>
          </div>
        </div>
      </aside>
      <main className="p-6 md:p-8">{children}</main>
    </div>
  );
}
