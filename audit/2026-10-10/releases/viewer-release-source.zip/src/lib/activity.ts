/**
 * Activity (C0.5) — map admin_list_activity into a readable history.
 *
 * Ordering: Account Server returns newest first (`at desc, id desc`).
 * We preserve server order and never re-sort a partial page.
 *
 * Date filters: From/To are calendar dates in the viewer's local timezone,
 * forwarded as ISO timestamps covering that local day
 * (from 00:00:00.000 local → to 23:59:59.999 local).
 */

import {
  isKnownAuditAction,
  translateAuditEvent,
  type AuditDetail,
  type KnownAuditAction,
} from "./activity-translate";
import { formatStaffRole } from "./staff-status";
import { isUuid } from "./staff";

export const ACTIVITY_PAGE_SIZE_DEFAULT = 25;
export const ACTIVITY_PAGE_SIZE_MAX = 100;
export const ACTIVITY_TARGET_MAX = 64;

export type ActivityGroup =
  | "all"
  | "accounts"
  | "roles"
  | "shops"
  | "credentials"
  | "recovery";

export const ACTIVITY_GROUPS: ReadonlyArray<{
  id: ActivityGroup;
  label: string;
  actions: readonly KnownAuditAction[] | null;
}> = [
  { id: "all", label: "All", actions: null },
  {
    id: "accounts",
    label: "Accounts",
    actions: ["create", "disable", "enable", "terminate"],
  },
  { id: "roles", label: "Roles", actions: ["set_role"] },
  {
    id: "shops",
    label: "Shops",
    actions: ["assign_shop", "unassign_shop", "add_shop"],
  },
  {
    id: "credentials",
    label: "Credentials",
    actions: ["reset_server_credential"],
  },
  { id: "recovery", label: "Recovery", actions: ["recover_identity"] },
];

export function isActivityGroup(value: string): value is ActivityGroup {
  return ACTIVITY_GROUPS.some((g) => g.id === value);
}

export function actionsForGroup(group: ActivityGroup): readonly KnownAuditAction[] | null {
  return ACTIVITY_GROUPS.find((g) => g.id === group)?.actions ?? null;
}

export function categoryForAction(action: string): string {
  switch (action) {
    case "create":
    case "disable":
    case "enable":
    case "terminate":
      return "Accounts";
    case "set_role":
      return "Roles";
    case "assign_shop":
    case "unassign_shop":
    case "add_shop":
      return "Shops";
    case "reset_server_credential":
      return "Credentials";
    case "recover_identity":
      return "Recovery";
    default:
      return "Other";
  }
}

/** Keys that must never appear in Viewer-rendered detail. */
const SENSITIVE_DETAIL_KEYS = new Set([
  "password",
  "credential",
  "credentials",
  "server_credential",
  "new_credential",
  "old_credential",
  "pin",
  "server_pin",
  "token",
  "access_token",
  "refresh_token",
  "secret",
  "hash",
  "hashed_password",
  "auth_user_id",
  "email",
  "recovery_credential",
  "new_creds",
  "creds",
]);

/**
 * Whitelist of detail fields permitted for Activity detail UI.
 * Unknown keys are dropped (fail closed).
 */
const SAFE_DETAIL_KEYS = new Set([
  "display_name",
  "role",
  "from",
  "to",
  "shop",
  "name",
  "shop_id",
  "staff_id",
  "shops",
  "terminated_at",
  "staff_restored",
  "shops_restored",
  "auth_recreated",
  "audit_events_restored",
  "from_export",
]);

export type ActivitySafeField = {
  key: string;
  label: string;
  value: string;
};

export type ActivityListItem = {
  id: number | string;
  at: string;
  action: string;
  category: string;
  target_username: string | null;
  summary: string;
  important: boolean;
  staff_id: string | null;
  shop_id: string | null;
  shop_name: string | null;
  safe_fields: ActivitySafeField[];
  suppressed_sensitive: boolean;
};

export type ActivityApiErrorCode =
  | "UNAUTHENTICATED"
  | "UNAUTHORIZED"
  | "SERVER_UNAVAILABLE"
  | "ACTIVITY_UNAVAILABLE"
  | "INVALID_REQUEST"
  | "UNKNOWN";

export type ActivityListApiResponse = {
  ok: boolean;
  env: string;
  contract: string;
  events: ActivityListItem[] | null;
  page: { limit: number; offset: number; hasMore: boolean; count: number };
  filters: {
    group: ActivityGroup;
    target: string | null;
    from: string | null;
    to: string | null;
  };
  /** True when group filter required client post-filter (multi-action groups). */
  group_post_filtered: boolean;
  error: null | { code: ActivityApiErrorCode; message: string };
};

function asString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const t = value.trim();
  return t.length ? t : null;
}

function asId(value: unknown): number | string | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) return value.trim();
  return null;
}

function asNonNegInt(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value) && value >= 0) {
    return Math.trunc(value);
  }
  if (typeof value === "string" && /^\d+$/.test(value)) {
    return Number.parseInt(value, 10);
  }
  return null;
}

function asBool(value: unknown): boolean | null {
  if (typeof value === "boolean") return value;
  return null;
}

function detailObject(detail: unknown): Record<string, unknown> | null {
  if (detail == null || typeof detail !== "object" || Array.isArray(detail)) return null;
  return detail as Record<string, unknown>;
}

export function detailHasSensitiveKeys(detail: AuditDetail): boolean {
  if (!detail || typeof detail !== "object") return false;
  for (const key of Object.keys(detail)) {
    const lower = key.toLowerCase();
    if (SENSITIVE_DETAIL_KEYS.has(lower)) return true;
    if (
      lower.includes("password") ||
      lower.includes("credential") ||
      lower.includes("secret") ||
      lower.includes("token") ||
      lower.includes("hash")
    ) {
      return true;
    }
  }
  return false;
}

function fieldLabel(key: string): string {
  const map: Record<string, string> = {
    display_name: "Display name",
    role: "Role",
    from: "Previous role",
    to: "New role",
    shop: "Shop",
    name: "Name",
    shop_id: "Shop ID",
    staff_id: "Staff ID",
    shops: "Shops",
    terminated_at: "Terminated at",
    staff_restored: "Staff restored",
    shops_restored: "Shops restored",
    auth_recreated: "Auth accounts recreated",
    audit_events_restored: "Audit events restored",
    from_export: "From export",
  };
  return map[key] ?? key;
}

function formatSafeValue(key: string, value: unknown): string | null {
  if (value == null) return null;

  if (key === "from" || key === "to" || key === "role") {
    const s = asString(value);
    return s ? formatStaffRole(s) : null;
  }

  if (key === "from_export") {
    const b = asBool(value);
    if (b == null) return null;
    return b ? "Yes" : "No";
  }

  if (
    key === "staff_restored" ||
    key === "shops_restored" ||
    key === "auth_recreated" ||
    key === "audit_events_restored"
  ) {
    const n = asNonNegInt(value);
    return n == null ? null : String(n);
  }

  if (key === "shops") {
    if (!Array.isArray(value)) return null;
    const names = value
      .map((v) => asString(v))
      .filter((v): v is string => v != null);
    return names.length ? names.join(", ") : null;
  }

  if (key === "shop_id" || key === "staff_id") {
    const s = asString(value);
    if (!s || !isUuid(s)) return null;
    return s;
  }

  if (typeof value === "string") {
    const t = value.trim();
    return t.length ? t : null;
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    return String(value);
  }

  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }

  return null;
}

/**
 * Extract only whitelisted, non-sensitive detail fields for display.
 * Credential-like keys are suppressed even if somehow listed.
 */
export function extractSafeDetailFields(detail: AuditDetail): {
  fields: ActivitySafeField[];
  suppressed_sensitive: boolean;
} {
  const obj = detailObject(detail);
  if (!obj) return { fields: [], suppressed_sensitive: false };

  const suppressed_sensitive = detailHasSensitiveKeys(obj);
  const fields: ActivitySafeField[] = [];

  for (const key of Object.keys(obj)) {
    const lower = key.toLowerCase();
    if (SENSITIVE_DETAIL_KEYS.has(lower)) continue;
    if (
      lower.includes("password") ||
      lower.includes("credential") ||
      lower.includes("secret") ||
      lower.includes("token") ||
      lower.includes("hash")
    ) {
      continue;
    }
    if (!SAFE_DETAIL_KEYS.has(key)) continue;

    const formatted = formatSafeValue(key, obj[key]);
    if (formatted == null) continue;
    fields.push({ key, label: fieldLabel(key), value: formatted });
  }

  return { fields, suppressed_sensitive };
}

export function mapActivityEvent(raw: unknown): ActivityListItem | null {
  if (raw == null || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const id = asId(o.id);
  const at = asString(o.at);
  const action = asString(o.action);
  if (id == null || !at || !action) return null;

  const target_username = asString(o.target_username);
  const detail = detailObject(o.detail);
  const { fields, suppressed_sensitive } = extractSafeDetailFields(detail);

  const staffRaw = detail ? asString(detail.staff_id) : null;
  const shopRaw = detail ? asString(detail.shop_id) : null;
  const staff_id = staffRaw && isUuid(staffRaw) ? staffRaw : null;
  const shop_id = shopRaw && isUuid(shopRaw) ? shopRaw : null;
  const shop_name =
    (detail ? asString(detail.shop) : null) ??
    (detail ? asString(detail.name) : null);

  return {
    id,
    at,
    action,
    category: categoryForAction(action),
    target_username,
    summary: translateAuditEvent({
      action,
      target_username,
      detail,
    }),
    important: action === "recover_identity",
    staff_id,
    shop_id,
    shop_name,
    safe_fields: fields,
    suppressed_sensitive,
  };
}

/**
 * Map RPC array. Returns null on malformed payload (fail closed).
 * Preserves server order (newest first).
 */
export function mapActivityList(raw: unknown): ActivityListItem[] | null {
  if (!Array.isArray(raw)) return null;
  const out: ActivityListItem[] = [];
  for (const row of raw) {
    const mapped = mapActivityEvent(row);
    if (!mapped) return null;
    out.push(mapped);
  }
  return out;
}

/** Filter mapped events to a group’s actions (for multi-action groups). */
export function filterEventsByGroup(
  events: ActivityListItem[],
  group: ActivityGroup,
): ActivityListItem[] {
  const actions = actionsForGroup(group);
  if (!actions) return events;
  const set = new Set<string>(actions);
  return events.filter((e) => set.has(e.action));
}

/**
 * Resolve which single `p_action` to send to the RPC.
 * Multi-action groups return null (caller post-filters).
 */
export function rpcActionForGroup(group: ActivityGroup): string | null {
  const actions = actionsForGroup(group);
  if (!actions) return null;
  if (actions.length === 1) return actions[0];
  return null;
}

export function groupNeedsPostFilter(group: ActivityGroup): boolean {
  const actions = actionsForGroup(group);
  return actions != null && actions.length > 1;
}

/** YYYY-MM-DD only. */
export function isValidDateInput(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split("-").map((n) => Number.parseInt(n, 10));
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

/**
 * Convert a local calendar date (YYYY-MM-DD) to ISO bounds for the RPC.
 * `bound: "start"` → local midnight; `bound: "end"` → local end of day.
 */
export function localDateToIsoBound(
  dateStr: string,
  bound: "start" | "end",
  now: Date = new Date(),
): string | null {
  if (!isValidDateInput(dateStr)) return null;
  const [y, m, d] = dateStr.split("-").map((n) => Number.parseInt(n, 10));
  // Interpret as local calendar date using the host's timezone offset at that day.
  const local = new Date(y, m - 1, d, bound === "start" ? 0 : 23, bound === "start" ? 0 : 59, bound === "start" ? 0 : 59, bound === "start" ? 0 : 999);
  if (Number.isNaN(local.getTime())) return null;
  // Touch `now` so callers can inject clocks in tests without unused-param lint.
  void now;
  return local.toISOString();
}

export type ParsedActivityQuery =
  | {
      ok: true;
      group: ActivityGroup;
      target: string | null;
      from: string | null;
      to: string | null;
      fromIso: string | null;
      toIso: string | null;
      limit: number;
      offset: number;
    }
  | { ok: false; message: string };

export function parseActivityQuery(url: URL): ParsedActivityQuery {
  let group: ActivityGroup = "all";
  const groupRaw = url.searchParams.get("group");
  if (groupRaw != null && groupRaw !== "") {
    const g = groupRaw.trim().toLowerCase();
    if (!isActivityGroup(g)) return { ok: false, message: "Invalid activity group." };
    group = g;
  }

  // Optional exact action override (must be known).
  const actionRaw = url.searchParams.get("action");
  if (actionRaw != null && actionRaw !== "") {
    const a = actionRaw.trim().toLowerCase();
    if (!isKnownAuditAction(a)) return { ok: false, message: "Unsupported action filter." };
    // Map single action onto the matching group for UI consistency when possible.
    // Still filter server-side by exact action via rpcAction override in route.
  }

  let target: string | null = null;
  const targetRaw = url.searchParams.get("target");
  if (targetRaw != null && targetRaw !== "") {
    const t = targetRaw.trim();
    if (t.length > ACTIVITY_TARGET_MAX) {
      return { ok: false, message: "Target username is too long." };
    }
    if (t.length > 0) target = t;
  }

  let from: string | null = null;
  let to: string | null = null;
  const fromRaw = url.searchParams.get("from");
  const toRaw = url.searchParams.get("to");
  if (fromRaw != null && fromRaw !== "") {
    if (!isValidDateInput(fromRaw.trim())) {
      return { ok: false, message: "Invalid from date." };
    }
    from = fromRaw.trim();
  }
  if (toRaw != null && toRaw !== "") {
    if (!isValidDateInput(toRaw.trim())) {
      return { ok: false, message: "Invalid to date." };
    }
    to = toRaw.trim();
  }
  if (from && to && from > to) {
    return { ok: false, message: "From date must be on or before To date." };
  }

  let limit = ACTIVITY_PAGE_SIZE_DEFAULT;
  const limitRaw = url.searchParams.get("limit");
  if (limitRaw != null && limitRaw !== "") {
    const n = Number.parseInt(limitRaw, 10);
    if (!Number.isFinite(n)) return { ok: false, message: "Invalid limit." };
    limit = Math.max(1, Math.min(ACTIVITY_PAGE_SIZE_MAX, n));
  }

  let offset = 0;
  const offsetRaw = url.searchParams.get("offset");
  if (offsetRaw != null && offsetRaw !== "") {
    const n = Number.parseInt(offsetRaw, 10);
    if (!Number.isFinite(n) || n < 0) return { ok: false, message: "Invalid offset." };
    offset = Math.min(n, 100_000);
  }

  const fromIso = from ? localDateToIsoBound(from, "start") : null;
  const toIso = to ? localDateToIsoBound(to, "end") : null;

  return {
    ok: true,
    group,
    target,
    from,
    to,
    fromIso,
    toIso,
    limit,
    offset,
  };
}

/** Exact single-action from query, if present and valid. */
export function parseOptionalAction(url: URL): string | null | { error: string } {
  const actionRaw = url.searchParams.get("action");
  if (actionRaw == null || actionRaw === "") return null;
  const a = actionRaw.trim().toLowerCase();
  if (!isKnownAuditAction(a)) return { error: "Unsupported action filter." };
  return a;
}
