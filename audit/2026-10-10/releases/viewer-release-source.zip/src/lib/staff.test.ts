import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  classifyStaffEmpty,
  formatShopsLabel,
  formatStaffDate,
  isUuid,
  mapStaffDetail,
  mapStaffList,
  mapStaffListItem,
} from "./staff";
import { deriveStaffStatus, formatStaffRole } from "./staff-status";

describe("deriveStaffStatus", () => {
  it("maps active", () => {
    assert.equal(deriveStaffStatus({ active: true, terminated_at: null }), "Active");
  });
  it("maps disabled", () => {
    assert.equal(deriveStaffStatus({ active: false, terminated_at: null }), "Disabled");
  });
  it("maps terminated", () => {
    assert.equal(
      deriveStaffStatus({ active: false, terminated_at: "2026-09-20T00:00:00Z" }),
      "Terminated",
    );
  });
  it("terminated wins over active=true inconsistency", () => {
    assert.equal(
      deriveStaffStatus({ active: true, terminated_at: "2026-09-20T00:00:00Z" }),
      "Terminated",
    );
  });
});

describe("formatStaffRole", () => {
  it("capitalizes frozen roles", () => {
    assert.equal(formatStaffRole("owner"), "Owner");
    assert.equal(formatStaffRole("CASHIER"), "Cashier");
  });
});

describe("formatShopsLabel", () => {
  it("shows All shops for owners", () => {
    assert.equal(formatShopsLabel("owner", []), "All shops");
    assert.equal(
      formatShopsLabel("owner", [{ id: "1", name: "A" }]),
      "All shops",
    );
  });
  it("formats ordinary assignments", () => {
    assert.equal(formatShopsLabel("cashier", []), "No shop assigned");
    assert.equal(
      formatShopsLabel("cashier", [{ id: "1", name: "Shop 1" }]),
      "Shop 1",
    );
    assert.equal(
      formatShopsLabel("admin", [
        { id: "1", name: "A" },
        { id: "2", name: "B" },
      ]),
      "A, B",
    );
  });
});

describe("mapStaffList", () => {
  const sample = {
    staff_id: "11111111-1111-4111-8111-111111111111",
    username: "ali",
    display_name: "Ali",
    role: "cashier",
    active: true,
    terminated_at: null,
    created_at: "2026-09-20T10:00:00Z",
    updated_at: "2026-09-20T11:00:00Z",
    shops: [{ id: "22222222-2222-4222-8222-222222222222", name: "Shop 1" }],
  };

  it("maps a valid list", () => {
    const list = mapStaffList([sample]);
    assert.ok(list);
    assert.equal(list.length, 1);
    assert.equal(list[0].status, "Active");
    assert.equal(list[0].role_label, "Cashier");
    assert.equal(list[0].shops_label, "Shop 1");
    assert.ok(!("auth_user_id" in list[0]));
  });

  it("maps empty list", () => {
    assert.deepEqual(mapStaffList([]), []);
  });

  it("rejects malformed response", () => {
    assert.equal(mapStaffList(null), null);
    assert.equal(mapStaffList({}), null);
    assert.equal(mapStaffList([{ username: "x" }]), null);
  });

  it("maps disabled and terminated", () => {
    const disabled = mapStaffListItem({
      ...sample,
      active: false,
      terminated_at: null,
    });
    assert.equal(disabled?.status, "Disabled");
    const term = mapStaffListItem({
      ...sample,
      active: false,
      terminated_at: "2026-01-01T00:00:00Z",
    });
    assert.equal(term?.status, "Terminated");
  });
});

describe("mapStaffDetail", () => {
  it("maps owner with All shops", () => {
    const d = mapStaffDetail({
      staff_id: "11111111-1111-4111-8111-111111111111",
      username: "owner1",
      display_name: "Owner One",
      role: "owner",
      active: true,
      terminated_at: null,
      created_at: "2026-09-01T00:00:00Z",
      updated_at: null,
      business_id: "33333333-3333-4333-8333-333333333333",
      shops: [
        { id: "a", name: "Recovery Shop A" },
        { id: "b", name: "Recovery Shop B" },
      ],
    });
    assert.ok(d);
    assert.equal(d.shops_label, "All shops");
    assert.equal(d.role_label, "Owner");
  });

  it("maps terminated detail", () => {
    const d = mapStaffDetail({
      staff_id: "11111111-1111-4111-8111-111111111111",
      username: "gone",
      display_name: "Gone",
      role: "operator",
      active: false,
      terminated_at: "2026-09-10T12:00:00Z",
      created_at: "2026-01-01T00:00:00Z",
      updated_at: "2026-09-10T12:00:00Z",
      business_id: "33333333-3333-4333-8333-333333333333",
      shops: [],
    });
    assert.ok(d);
    assert.equal(d.status, "Terminated");
  });
});

describe("isUuid", () => {
  it("validates staff ids", () => {
    assert.equal(isUuid("11111111-1111-4111-8111-111111111111"), true);
    assert.equal(isUuid("not-a-uuid"), false);
    assert.equal(isUuid(""), false);
  });
});

describe("classifyStaffEmpty", () => {
  it("differentiates empty causes", () => {
    assert.equal(
      classifyStaffEmpty({
        search: null,
        role: null,
        status: null,
        shopId: null,
        limit: 25,
        offset: 0,
      }),
      "none",
    );
    assert.equal(
      classifyStaffEmpty({
        search: "zzz",
        role: null,
        status: null,
        shopId: null,
        limit: 25,
        offset: 0,
      }),
      "search",
    );
    assert.equal(
      classifyStaffEmpty({
        search: null,
        role: "cashier",
        status: "disabled",
        shopId: null,
        limit: 25,
        offset: 0,
      }),
      "filters",
    );
  });
});

describe("formatStaffDate", () => {
  it("produces a non-ISO readable date", () => {
    const label = formatStaffDate("2026-09-20T11:43:27.519432+00:00");
    assert.ok(label.length > 0);
    assert.equal(label.includes("T11:43"), false);
  });
});
