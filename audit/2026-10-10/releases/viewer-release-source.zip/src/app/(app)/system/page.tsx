import { SystemPanel } from "./system-panel";

export default function SystemPage() {
  return <SystemPanel />;
}
