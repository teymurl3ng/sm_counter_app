/** Safe Account Server meta for API responses when config cannot load. */
export type AccountServerMeta = {
  env: "dev" | "prod" | "unknown";
  contract: string;
};

/**
 * Prefer live config. On failure, label env as unknown (never silently claim
 * DEV or PROD).
 */
export function safeAccountServerMeta(
  load: () => { env: "dev" | "prod"; contract: string },
): AccountServerMeta {
  try {
    const cfg = load();
    return { env: cfg.env, contract: cfg.contract };
  } catch {
    return { env: "unknown", contract: "v1.1.0-read-admin" };
  }
}
