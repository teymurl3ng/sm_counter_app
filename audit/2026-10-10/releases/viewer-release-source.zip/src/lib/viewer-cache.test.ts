import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  clearViewerCache,
  setViewerCacheSession,
  viewerCachedGet,
  _viewerCacheSizeForTests,
  VIEWER_TTL,
} from "./viewer-cache";

describe("viewer-cache", () => {
  it("isolates sessions and clears on identity change", async () => {
    clearViewerCache();
    setViewerCacheSession("alice");
    // Mock fetch
    const original = globalThis.fetch;
    let calls = 0;
    globalThis.fetch = (async () => {
      calls += 1;
      return new Response(JSON.stringify({ ok: true, n: calls }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }) as typeof fetch;

    try {
      const a1 = await viewerCachedGet({
        key: "overview",
        url: "/api/overview",
        ttlMs: VIEWER_TTL.overview,
      });
      const a2 = await viewerCachedGet({
        key: "overview",
        url: "/api/overview",
        ttlMs: VIEWER_TTL.overview,
      });
      assert.equal(a2.fromCache, true);
      assert.equal(calls, 1);

      setViewerCacheSession("bob");
      assert.equal(_viewerCacheSizeForTests(), 0);
      const b1 = await viewerCachedGet({
        key: "overview",
        url: "/api/overview",
        ttlMs: VIEWER_TTL.overview,
      });
      assert.equal(b1.fromCache, false);
      assert.equal(calls, 2);
      void a1;
    } finally {
      globalThis.fetch = original;
      clearViewerCache();
    }
  });

  it("single-flights concurrent misses", async () => {
    clearViewerCache();
    setViewerCacheSession("carol");
    const original = globalThis.fetch;
    let calls = 0;
    globalThis.fetch = (async () => {
      calls += 1;
      await new Promise((r) => setTimeout(r, 30));
      return new Response(JSON.stringify({ ok: true }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }) as typeof fetch;

    try {
      const [x, y] = await Promise.all([
        viewerCachedGet({ key: "staff?q=1", url: "/api/staff", ttlMs: 10_000 }),
        viewerCachedGet({ key: "staff?q=1", url: "/api/staff", ttlMs: 10_000 }),
      ]);
      assert.equal(calls, 1);
      assert.equal(x.fromCache, false);
      assert.equal(y.fromCache, false);
    } finally {
      globalThis.fetch = original;
      clearViewerCache();
    }
  });

  it("clears cache on 401 and does not store it", async () => {
    clearViewerCache();
    setViewerCacheSession("dave");
    const original = globalThis.fetch;
    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ ok: false }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      })) as typeof fetch;

    try {
      await viewerCachedGet({ key: "x", url: "/api/x", ttlMs: 10_000 });
      assert.equal(_viewerCacheSizeForTests(), 0);
    } finally {
      globalThis.fetch = original;
      clearViewerCache();
    }
  });
});
